// Linux software-rasterised preview of the menu (for pixel comparison with the reference)
#include "imgui.h"
#include "menu.h"
#include "res.h"
#include <vector>
#include <map>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <string>

struct Tex { int w, h; std::vector<float> px; }; // RGBA float 0..1
static std::map<ImU64, Tex> texs;
static ImU64 nextId = 1;
static int W, H;
static std::vector<float> fb; // RGB float

static void sample(const Tex& t, float u, float v, float out[4])
{
    float x = u * t.w - 0.5f, y = v * t.h - 0.5f;
    int x0 = (int)floorf(x), y0 = (int)floorf(y); float fx = x - x0, fy = y - y0;
    for (int c = 0; c < 4; ++c) out[c] = 0;
    for (int j = 0; j < 2; ++j) for (int i = 0; i < 2; ++i) {
        int xx = x0 + i, yy = y0 + j; xx = xx < 0 ? 0 : (xx >= t.w ? t.w - 1 : xx); yy = yy < 0 ? 0 : (yy >= t.h ? t.h - 1 : yy);
        float wgt = (i ? fx : 1 - fx) * (j ? fy : 1 - fy);
        const float* p = &t.px[(yy * t.w + xx) * 4];
        for (int c = 0; c < 4; ++c) out[c] += p[c] * wgt;
    }
}
static ImU64 blurId = 0;
static void blurFB()
{
    // gaussian blur of framebuffer into texture blurId (sigma ~ 8 px)
    Tex& t = texs[blurId]; t.w = W; t.h = H; t.px.assign(W * H * 4, 1.0f);
    std::vector<float> tmp(W * H * 3), src = fb;
    const int Rr = 16; float sigma = 7.0f; float k[2 * Rr + 1]; float ks = 0;
    for (int i = -Rr; i <= Rr; ++i) { k[i + Rr] = expf(-(i * i) / (2 * sigma * sigma)); ks += k[i + Rr]; }
    for (int i = 0; i < 2 * Rr + 1; ++i) k[i] /= ks;
    for (int y = 0; y < H; ++y) for (int x = 0; x < W; ++x) for (int c = 0; c < 3; ++c) {
        float s = 0; for (int i = -Rr; i <= Rr; ++i) { int xx = x + i; xx = xx < 0 ? 0 : (xx >= W ? W - 1 : xx); s += src[(y * W + xx) * 3 + c] * k[i + Rr]; }
        tmp[(y * W + x) * 3 + c] = s; }
    for (int y = 0; y < H; ++y) for (int x = 0; x < W; ++x) for (int c = 0; c < 3; ++c) {
        float s = 0; for (int i = -Rr; i <= Rr; ++i) { int yy = y + i; yy = yy < 0 ? 0 : (yy >= H ? H - 1 : yy); s += tmp[(yy * W + x) * 3 + c] * k[i + Rr]; }
        t.px[(y * W + x) * 4 + c] = s; }
}
static void blurCb(const ImDrawList*, const ImDrawCmd*) { blurFB(); }

static void raster(ImDrawData* dd)
{
    for (ImTextureData* td : *dd->Textures) {
        if (getenv("DBG3D") && td->Width == 480 && td->Status == ImTextureStatus_WantCreate) { long s = 0; for (int i = 3; i < 480 * 924 * 4; i += 4) s += ((unsigned char*)td->GetPixels())[i]; printf("create alpha %ld fmt %d bpp %d\n", s, (int)td->Format, td->BytesPerPixel); }
        if (td->Status == ImTextureStatus_WantCreate || td->Status == ImTextureStatus_WantUpdates) {
            ImU64 id = td->TexID ? (ImU64)td->TexID : nextId++;
            Tex& t = texs[id]; t.w = td->Width; t.h = td->Height; t.px.resize(t.w * t.h * 4);
            for (int i = 0; i < t.w * t.h; ++i) {
                if (td->Format == ImTextureFormat_RGBA32) { const unsigned char* p = (const unsigned char*)td->GetPixels() + i * 4; for (int c = 0; c < 4; ++c) t.px[i * 4 + c] = p[c] / 255.f; }
                else { unsigned char a = ((const unsigned char*)td->GetPixels())[i]; t.px[i*4]=t.px[i*4+1]=t.px[i*4+2]=1; t.px[i*4+3]=a/255.f; }
            }
            td->SetTexID((ImTextureID)id); td->SetStatus(ImTextureStatus_OK);
        } else if (td->Status == ImTextureStatus_WantDestroy) { td->SetStatus(ImTextureStatus_Destroyed); }
    }
    for (ImDrawList* dl : dd->CmdLists) {
        for (ImDrawCmd& cmd : dl->CmdBuffer) {
            if (cmd.UserCallback) { if (cmd.UserCallback != ImDrawCallback_ResetRenderState) cmd.UserCallback(dl, &cmd); continue; }
            Tex* tex = nullptr; auto it = texs.find((ImU64)cmd.GetTexID()); if (it != texs.end()) tex = &it->second;
            if (getenv("DBG3D") && !tex) printf("null tex id %llu elems %u\n", (unsigned long long)cmd.GetTexID(), cmd.ElemCount);
            int cx0 = (int)fmaxf(0, cmd.ClipRect.x), cy0 = (int)fmaxf(0, cmd.ClipRect.y), cx1 = (int)fminf(W, cmd.ClipRect.z), cy1 = (int)fminf(H, cmd.ClipRect.w);
            for (unsigned e = 0; e < cmd.ElemCount; e += 3) {
                const ImDrawVert* V[3]; for (int k = 0; k < 3; ++k) V[k] = &dl->VtxBuffer[dl->IdxBuffer[cmd.IdxOffset + e + k] + cmd.VtxOffset];
                float x0 = V[0]->pos.x, y0 = V[0]->pos.y, x1 = V[1]->pos.x, y1 = V[1]->pos.y, x2 = V[2]->pos.x, y2 = V[2]->pos.y;
                float area = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0); if (fabsf(area) < 1e-9f) continue;
                int bx0 = (int)floorf(fminf(x0, fminf(x1, x2))), bx1 = (int)ceilf(fmaxf(x0, fmaxf(x1, x2)));
                int by0 = (int)floorf(fminf(y0, fminf(y1, y2))), by1 = (int)ceilf(fmaxf(y0, fmaxf(y1, y2)));
                if (bx0 < cx0) bx0 = cx0; if (by0 < cy0) by0 = cy0; if (bx1 > cx1) bx1 = cx1; if (by1 > cy1) by1 = cy1;
                for (int y = by0; y < by1; ++y) for (int x = bx0; x < bx1; ++x) {
                    float px = x + 0.5f, py = y + 0.5f;
                    float w0 = ((x1 - px) * (y2 - py) - (x2 - px) * (y1 - py)) / area;
                    float w1 = ((x2 - px) * (y0 - py) - (x0 - px) * (y2 - py)) / area;
                    float w2 = 1 - w0 - w1;
                    if (w0 < -1e-6f || w1 < -1e-6f || w2 < -1e-6f) continue;
                    float col[4];
                    for (int c = 0; c < 4; ++c) {
                        float a = ((V[0]->col >> (8 * c)) & 0xFF) / 255.f, b = ((V[1]->col >> (8 * c)) & 0xFF) / 255.f, d = ((V[2]->col >> (8 * c)) & 0xFF) / 255.f;
                        col[c] = a * w0 + b * w1 + d * w2;
                    }
                    if (tex) { float u = V[0]->uv.x * w0 + V[1]->uv.x * w1 + V[2]->uv.x * w2, v = V[0]->uv.y * w0 + V[1]->uv.y * w1 + V[2]->uv.y * w2; float s[4]; sample(*tex, u, v, s); for (int c = 0; c < 4; ++c) col[c] *= s[c]; }
                    float* d = &fb[(y * W + x) * 3]; for (int c = 0; c < 3; ++c) d[c] = d[c] * (1 - col[3]) + col[c] * col[3];
                }
            }
        }
    }
}

int main(int argc, char** argv)
{
    const char* bg = argc > 1 ? argv[1] : "bg.rgb"; W = 1196; H = 802;
    float mx = argc > 2 ? atof(argv[2]) : 716, my = argc > 3 ? atof(argv[3]) : 440;
    int limiters = argc > 4 ? atoi(argv[4]) : 1;
    const char* out = argc > 5 ? argv[5] : "out.rgb";
    fb.resize(W * H * 3);
    FILE* f = fopen(bg, "rb"); std::vector<unsigned char> raw(W * H * 3); fread(raw.data(), 1, raw.size(), f); fclose(f);
    for (size_t i = 0; i < raw.size(); ++i) fb[i] = raw[i] / 255.f;
    ImGui::CreateContext(); ImGuiIO& io = ImGui::GetIO();
    io.BackendFlags |= ImGuiBackendFlags_RendererHasTextures; io.DisplaySize = ImVec2(W, H); io.IniFilename = nullptr;
    Menu_LoadFonts();
    // avatar + blur textures
    ImU64 av = nextId++; { Tex& t = texs[av]; t.w = avatar_w; t.h = avatar_h; t.px.resize(t.w * t.h * 4); for (int i = 0; i < t.w * t.h * 4; ++i) t.px[i] = avatar_rgba[i] / 255.f; }
    ImU64 lgid = nextId++; { Tex& t = texs[lgid]; t.w = logo_w; t.h = logo_h; t.px.resize(t.w * t.h * 4); for (int i = 0; i < t.w * t.h * 4; ++i) t.px[i] = logo_rgba[i] / 255.f; }
    blurId = nextId++; texs[blurId] = Tex{ 1, 1, std::vector<float>(4, 0) };
    ImU64 sdid = nextId++; { Tex& t = texs[sdid]; t.w = soldier_w; t.h = soldier_h; t.px.resize(t.w * t.h * 4); for (int i = 0; i < t.w * t.h * 4; ++i) t.px[i] = soldier_rgba[i] / 255.f; }
    MenuPlatform mp; mp.soldierTex = (ImTextureID)sdid; mp.avatarTex = (ImTextureID)av; mp.logoTex = (ImTextureID)lgid; mp.blurTex = (ImTextureID)blurId; mp.blurCallback = blurCb; Menu_SetPlatform(mp);
    Menu_SetPos(167, 52); if (getenv("NOMENU")) Menu_Toggle(); if (getenv("TAB")) Menu_DebugSetTab(atoi(getenv("TAB")), getenv("GRP") ? atoi(getenv("GRP")) : 0); Menu_Debug3DSync(true); if (getenv("MAT")) Menu_DebugModel(atoi(getenv("MAT")), getenv("YAW") ? (float)atof(getenv("YAW")) : 0.0f, getenv("SKEL") != nullptr); if (getenv("DPI")) Menu_SetDpiScale((float)atof(getenv("DPI")));
    if (getenv("SIMBLUR")) {
        std::vector<float> g = fb;
        for (int y = 40; y < 680; ++y) for (int x = 150; x < 990; ++x) { int sx = (x - 150) * 150 / 840; for (int c = 0; c < 3; ++c) fb[(y*W+x)*3+c] = g[(y*W+sx)*3+c]; }
        blurFB(); Tex& bt = texs[blurId];
        for (int y = 52; y < 664; ++y) for (int x = 167; x < 965; ++x) for (int c = 0; c < 3; ++c) fb[(y*W+x)*3+c] = bt.px[(y*W+x)*4+c];
    }
    for (int frame = 0; frame < 120; ++frame) {
        io.DeltaTime = 1.0f / 60.0f; io.AddMousePosEvent(mx, my);
        if (limiters == 2) io.AddMouseButtonEvent(0, frame == 30);
        if (limiters == 4) { if (frame >= 50) io.AddMousePosEvent(atof(getenv("MX2")), atof(getenv("MY2"))); io.AddMouseButtonEvent(0, frame == 30 || frame == 60); }
        if (limiters == 5) { io.AddMouseButtonEvent(0, frame >= 30 && frame < (getenv("REL") ? 90 : 1000)); if (frame >= 40) { float t = fminf(1.0f, (frame - 40) / 30.0f); io.AddMousePosEvent(mx + (atof(getenv("MX2")) - mx) * t, my + (atof(getenv("MY2")) - my) * t); } }
        if (limiters == 3) { io.AddMouseButtonEvent(0, frame == 30); if (frame == 50) io.AddMousePosEvent(mx, my + 52); }
        ImGui::NewFrame();
        if (frame == 1 && limiters == 1) Menu_DebugOpenLimiters();
        if (getenv("XH")) Menu_SetGameKeys(false, frame == 100, getenv("XHW") != nullptr, false, false, false, false);
        Menu_Frame(io.DeltaTime);
        ImGui::Render();
        int snapF = getenv("SNAP") ? atoi(getenv("SNAP")) : 119;
        if (frame == snapF) { raster(ImGui::GetDrawData()); break; }
        if (false) raster(ImGui::GetDrawData());
        else { // still need to process textures
            ImDrawData* dd = ImGui::GetDrawData();
            for (ImTextureData* td : *dd->Textures) if (td->Status != ImTextureStatus_OK && td->Status != ImTextureStatus_Destroyed) {
                // create via raster path with no commands
            }
            std::vector<ImDrawList*> saved(dd->CmdLists.begin(), dd->CmdLists.end());
            dd->CmdLists.resize(0); std::vector<float> keep = fb; raster(dd); fb = keep;
        }
    }
    f = fopen(out, "wb"); for (size_t i = 0; i < raw.size(); ++i) { float v = fb[i]; raw[i] = (unsigned char)(fminf(1, fmaxf(0, v)) * 255 + 0.5f); } fwrite(raw.data(), 1, raw.size(), f); fclose(f);
    return 0;
}
