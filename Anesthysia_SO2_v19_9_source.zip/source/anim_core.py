# ---------------- quaternion helpers (x y z w)
def qmul(a, b):
    ax, ay, az, aw = a; bx, by, bz, bw = b
    return np.array([aw * bx + ax * bw + ay * bz - az * by, aw * by - ax * bz + ay * bw + az * bx, aw * bz + ax * by - ay * bx + az * bw, aw * bw - ax * bx - ay * by - az * bz])
def qconj(a): return np.array([-a[0], -a[1], -a[2], a[3]])
def qrot(q, v): return qmul(qmul(q, np.array([v[0], v[1], v[2], 0.0])), qconj(q))[:3]
def qfrom_m(m):
    t = np.trace(m)
    if t > 0: s = np.sqrt(t + 1) * 2; return np.array([(m[2, 1] - m[1, 2]) / s, (m[0, 2] - m[2, 0]) / s, (m[1, 0] - m[0, 1]) / s, 0.25 * s])
    i = np.argmax(np.diag(m)); j, k = (i + 1) % 3, (i + 2) % 3
    s = np.sqrt(1 + m[i, i] - m[j, j] - m[k, k]) * 2; q = np.zeros(4)
    q[i] = 0.25 * s; q[j] = (m[j, i] + m[i, j]) / s; q[k] = (m[k, i] + m[i, k]) / s; q[3] = (m[k, j] - m[j, k]) / s; return q
def swing(a, b):
    a = a / np.linalg.norm(a); b = b / np.linalg.norm(b); c = np.cross(a, b); d = a @ b
    q = np.array([c[0], c[1], c[2], 1 + d]); return q / np.linalg.norm(q)
def slerp(a, b, t):
    if a @ b < 0: b = -b
    q = a * (1 - t) + b * t; return q / np.linalg.norm(q)
# ---------------- source clips
def loadClip(path):
    d = open(path, 'rb').read(); l = struct.unpack('<I', d[12:16])[0]; j = json.loads(d[20:20 + l])
    off = 20 + l; bl = struct.unpack('<I', d[off:off + 4])[0]; B = d[off + 8:off + 8 + bl]
    def acc(i):
        a = j['accessors'][i]; bv = j['bufferViews'][a['bufferView']]
        n = {'SCALAR': 1, 'VEC3': 3, 'VEC4': 4}[a['type']]
        return np.frombuffer(B, np.float32, a['count'] * n, bv.get('byteOffset', 0) + a.get('byteOffset', 0)).reshape(a['count'], n)
    nodes = j['nodes']; parent = {}
    for i, n in enumerate(nodes):
        for c in n.get('children', []): parent[c] = i
    a = j['animations'][0]; ch = {}
    for c in a['channels']:
        s = a['samplers'][c['sampler']]; ch[(c['target']['node'], c['target']['path'])] = (acc(s['input'])[:, 0], acc(s['output']))
    dur = max(v[0][-1] for v in ch.values())
    return dict(nodes=nodes, parent=parent, ch=ch, dur=dur, name={n.get('name'): i for i, n in enumerate(nodes)})
def sampleCh(c, t):
    ts, vs = c; i = np.searchsorted(ts, t) - 1; i = int(np.clip(i, 0, len(ts) - 2)); u = float(np.clip((t - ts[i]) / max(1e-6, ts[i + 1] - ts[i]), 0, 1))
    if vs.shape[1] == 4: return slerp(vs[i].astype(float), vs[i + 1].astype(float), u)
    return vs[i] * (1 - u) + vs[i + 1] * u
def worldPose(C, t):
    W = {}
    def get(i):
        if i in W: return W[i]
        n = C['nodes'][i]
        tr = np.array(n.get('translation', [0, 0, 0]), float); ro = np.array(n.get('rotation', [0, 0, 0, 1]), float)
        if (i, 'translation') in C['ch']: tr = sampleCh(C['ch'][(i, 'translation')], t).astype(float)
        if (i, 'rotation') in C['ch']: ro = sampleCh(C['ch'][(i, 'rotation')], t)
        if i in C['parent']:
            pq, pp = get(C['parent'][i]); W[i] = (qmul(pq, ro), pp + qrot(pq, tr))
        else: W[i] = (ro, tr)
        return W[i]
    return {nm: get(i) for nm, i in C['name'].items()}
REF = worldPose(loadClip('/data/anim/F_idle.glb'), 0.0)
# frame conversion K (source -> mesh space)
def basis(up, left):
    up = up / np.linalg.norm(up); left = left - up * (left @ up); left /= np.linalg.norm(left); fw = np.cross(left, up)
    return np.stack([left, up, fw], 1)
Bs = basis(REF['Head'][1] - REF['Hips'][1], REF['LeftUpLeg'][1] - REF['RightUpLeg'][1])
Bt = basis(np.array([0, 1.0, 0]), np.array([1.0, 0, 0]))
K = Bt @ Bs.T; qK = qfrom_m(K)
print('toe forward check (should be +z):', K @ (REF['LeftToe_End'][1] - REF['LeftFoot'][1]))
scale = REST[0][1] / REF['Hips'][1][1]
Wq = [swing(TIP[i] - REST[i], K @ (REF[b[4]][1] - REF[b[3]][1])) for i, b in enumerate(BONES)]
FPS = 20
def clipFrames(path, t0=0.0, t1=None):
    C = loadClip(path); t1 = C['dur'] if t1 is None else t1
    out = []
    for t in np.arange(t0, t1, 1.0 / FPS):
        A = worldPose(C, t); Gq = []
        for i, b in enumerate(BONES):
            d = qmul(A[b[3]][0], qconj(REF[b[3]][0]))         # world delta (source)
            dK = qmul(qmul(qK, d), qconj(qK))
            Gq.append(qmul(dK, Wq[i]) / 1.0)
        root = K @ (A['Hips'][1] - REF['Hips'][1]) * scale
        out.append((np.array(Gq), root))
    return out
def fk(Gq, root):
    pos = np.zeros((NB, 3))
    for i in range(NB):
        if PAR[i] < 0: pos[i] = REST[i] + root
        else: p = PAR[i]; pos[i] = pos[p] + qrot(Gq[p], REST[i] - REST[p])
    # keep the lowest foot on the ground
    fy = min(pos[BI['foot_l']][1] + qrot(Gq[BI['foot_l']], REST[BI['ball_l']] - REST[BI['foot_l']])[1] * 0 , pos[BI['foot_r']][1])
    return pos, REST[BI['foot_l']][1] - fy
seq = [('F_idle.glb', 0, 5.0)] + [('F_%03d.glb' % i, 0, None) for i in (3, 1, 5, 2, 8, 4, 6, 9, 7)]
clips = []
for nm, a, b in seq:
    fr = clipFrames('/data/anim/' + nm, a, b)
    roots = np.array([r for _, r in fr]); m = roots.mean(0); m[1] = 0
    clips.append([(g, r - m) for g, r in fr]); print(nm, len(fr), 'frames')
# concatenate with crossfades
XF = int(0.5 * FPS)
tl = list(clips[0])
for c in clips[1:]:
    for k in range(XF):
        u = (k + 1) / (XF + 1); u = u * u * (3 - 2 * u)
        g0, r0 = tl[-XF + k]; g1, r1 = c[k]
        tl[-XF + k] = (np.array([slerp(g0[i], g1[i], u) for i in range(NB)]), r0 * (1 - u) + r1 * u)
    tl += c[XF:]
for k in range(XF):     # loop seam
    u = (k + 1) / (XF + 1); u = u * u * (3 - 2 * u)
    g0, r0 = tl[-XF + k]; g1, r1 = tl[k]
    tl[-XF + k] = (np.array([slerp(g0[i], g1[i], u) for i in range(NB)]), r0 * (1 - u) + r1 * u)
tl = tl[:-0] if False else tl
NF = len(tl); print('total frames', NF, NF / FPS, 's')
FR = np.zeros((NF, NB, 7))
for f_, (g, r) in enumerate(tl):
    pos, dy = fk(g, r)
    pos[:, 1] += dy
    for i in range(NB):
        q_ = g[i] / np.linalg.norm(g[i])
        if q_[3] < 0: q_ = -q_
        FR[f_, i, :4] = q_; FR[f_, i, 4:] = pos[i]
