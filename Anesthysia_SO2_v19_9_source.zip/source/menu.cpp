// Neverlose-style menu replica (Rage tab) - Dear ImGui draw-list implementation
#define IMGUI_DEFINE_MATH_OPERATORS
#include <algorithm>
#include "menu.h"
#include "imgui_internal.h"
#include "res.h"
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>
#include <unordered_map>
#include <vector>
#include <string>
#include <thread>
#include <mutex>
#include <condition_variable>
#include "model3d.h"
#include "font_loader.h"
#include "wicons.h"
#include "esp_assets.h"
#include "killfx_tex.h"
#include "font_momo.h"

// ---------------------------------------------------------------- fonts / platform
static ImFont* F_MED  = nullptr;   // Inter Medium
static ImFont* F_SEMI = nullptr;   // Inter SemiBold
static ImFont* F_XB   = nullptr;   // Inter ExtraBold (logo)
static ImFont* F_BOLD = nullptr;   // Noto Sans Bold
static ImFont* F_ICON = nullptr;
static ImFont* F_VERD = nullptr;   // Verdana (ESP font option)
static ImFont* F_SPIX = nullptr;   // smallest_pixel-7 (ESP pixel font option)
static ImFont* F_NR = nullptr; static ImFont* F_NM = nullptr; static ImFont* F_NSB = nullptr;   // Noto Sans Regular / Medium / SemiBold (loader)
static ImFont* F_CON = nullptr;   // Consolas (text watermark), loaded from the system fonts folder
static ImFont* F_SIG  = nullptr;   // Momo Signature (sidebar logo text)
static ImFont* F_PIX  = nullptr;   // ProggyClean (pixel font, crosshair watermark)   // Font Awesome 6 Solid
static MenuPlatform g_plat;

void Menu_LoadFonts()
{
    ImGuiIO& io = ImGui::GetIO();
    ImFontConfig cfg; cfg.FontDataOwnedByAtlas = false; cfg.OversampleH = 2; cfg.OversampleV = 1; cfg.PixelSnapH = false;
    F_MED  = io.Fonts->AddFontFromMemoryTTF((void*)font_medium_data,    font_medium_size,    14.0f, &cfg);
    F_SEMI = io.Fonts->AddFontFromMemoryTTF((void*)font_semibold_data,  font_semibold_size,  14.0f, &cfg);
    F_BOLD = io.Fonts->AddFontFromMemoryTTF((void*)font_bold_data,      font_bold_size,      14.0f, &cfg);
    F_XB   = io.Fonts->AddFontFromMemoryTTF((void*)font_extrabold_data, font_extrabold_size, 14.0f, &cfg);
    F_ICON = io.Fonts->AddFontFromMemoryTTF((void*)font_fa_data,        font_fa_size,        14.0f, &cfg);
    F_VERD = io.Fonts->AddFontFromMemoryTTF((void*)FONT_VERDANA, (int)sizeof(FONT_VERDANA), 13.0f, &cfg);
    { ImFontConfig pc = cfg; pc.OversampleH = 1; pc.PixelSnapH = true; F_SPIX = io.Fonts->AddFontFromMemoryTTF((void*)FONT_SPIX, (int)sizeof(FONT_SPIX), 10.0f, &pc); }
    F_NR = io.Fonts->AddFontFromMemoryTTF((void*)font_notor_data, font_notor_size, 16.0f, &cfg);
    F_NM = io.Fonts->AddFontFromMemoryTTF((void*)font_notom_data, font_notom_size, 16.0f, &cfg);
    F_NSB = io.Fonts->AddFontFromMemoryTTF((void*)font_notosb_data, font_notosb_size, 16.0f, &cfg);
    F_SIG = io.Fonts->AddFontFromMemoryTTF((void*)font_momo_data, font_momo_size, 24.0f, &cfg);
    {   // console font for the text watermark: Consolas -> Lucida Console -> (preview) Liberation Mono
        static const char* paths[] = { "C:\\Windows\\Fonts\\consola.ttf", "C:\\Windows\\Fonts\\lucon.ttf", "/usr/share/fonts/liberation-mono/LiberationMono-Regular.ttf" };
        ImFontConfig fc; fc.OversampleH = 2; fc.OversampleV = 1;
        for (const char* p : paths) { FILE* f = fopen(p, "rb"); if (!f) continue; fclose(f); F_CON = io.Fonts->AddFontFromFileTTF(p, 14.0f, &fc); if (F_CON) break; }
    }
    F_PIX  = io.Fonts->AddFontDefault();
}
void Menu_SetPlatform(const MenuPlatform& p) { g_plat = p; }

// ---------------------------------------------------------------- tuning (pixel-matched to reference)
static const float MENU_W = 798.0f, MENU_H = 612.0f, MENU_ROUND = 9.0f;
static ImU32 ACCENT = 0x9BB1E0;          // theme colour (editable in the Debug window)
static const ImU32 ACCENT_DEFAULT = 0x9BB1E0;
static const float BG_ALPHA = 0.95f;
static const float POPUP_ALPHA = 0.74f;  // profile popup opacity (blurred content behind stays visible)   // menu background opacity (rest = blurred game behind)

// ---------------------------------------------------------------- state
static bool  g_open = true;
static int   g_boot = 2;            // 0 waiting for the hotkey, 1 loading, 2 done (the preview harness starts at 2)
static float g_openA = 0.0f;           // 0..1 open animation
static ImVec2 g_pos(167, 52), g_posTarget(167, 52);
static bool  g_posInit = false;
static bool  g_dragging = false; static ImVec2 g_dragOff;
static float g_dt = 0.016f;
static ImVec2 O;                         // current menu origin
static ImDrawList* DL = nullptr;
static float g_scale = 1.0f;
static ImVec2 g_snapO;                   // menu origin used for screen-space text snapping
static float g_dpi = 1.0f, g_dpiTarget = 1.0f;  // DPI scale (animated)
static int   g_dpiIdx = 1;
// local-space pixel snap only at 100% (scaled text is snapped once, in screen space, by AddTextCrisp)
static float SnapL(float v) { return g_dpi == 1.0f ? floorf(v + 0.5f) : v; }
static float TextBake() { return floorf(g_dpi * 20.0f + 0.5f) / 20.0f; }
// draw text rasterised at the final (scaled) size, then shrink back to local space -> crisp after the global DPI transform
static void AddTextCrisp(ImFont* f, float size, ImVec2 pos, ImU32 col, const char* t, const ImVec4* clip = nullptr)
{
    if ((col & IM_COL32_A_MASK) == 0 || !t || !t[0]) return;
    float b = TextBake();
    // snap the final on-screen position to whole pixels
    if (g_dpi != 1.0f) {
        ImVec2 fp = g_snapO + (pos - g_snapO) * g_dpi;
        fp = ImVec2(floorf(fp.x + 0.5f), floorf(fp.y + 0.5f));
        pos = g_snapO + (fp - g_snapO) / g_dpi;
    }
    // clip rect (local space) -> bake space around pos, so culling/fine clipping match the shrunk result
    ImVec4 cr = DL->_CmdHeader.ClipRect;
    if (clip) { cr.x = ImMax(cr.x, clip->x); cr.y = ImMax(cr.y, clip->y); cr.z = ImMin(cr.z, clip->z); cr.w = ImMin(cr.w, clip->w); }
    cr = ImVec4(pos.x + (cr.x - pos.x) * b, pos.y + (cr.y - pos.y) * b, pos.x + (cr.z - pos.x) * b, pos.y + (cr.w - pos.y) * b);
    int v0 = DL->VtxBuffer.Size;
    f->RenderText(DL, size * b, pos, col, cr, t, nullptr, 0.0f, clip ? ImDrawTextFlags_CpuFineClip : ImDrawTextFlags_None);
    if (b != 1.0f) { ImDrawVert* v = DL->VtxBuffer.Data; for (int i = v0; i < DL->VtxBuffer.Size; ++i) v[i].pos = pos + (v[i].pos - pos) / b; }
}

struct InputState { ImVec2 m; bool click = false, down = false, release = false, rclick = false; } IN;
static bool    g_hotAny = false;
static ImGuiID g_active = 0;
static bool g_wantMouse = false, g_wantMousePrev = false;
static ImRect g_backdrop; static bool g_backdropVisible = false; static float g_backdropAlpha = 0.0f;
float Menu_GetBackdropAlpha() { return g_backdropAlpha; }
static ImRect g_popRect; static bool g_popVisible = false;
static ImRect g_barRect; static float g_barA = 0.0f; static bool g_barBlur = false;   // bottom-centre bar (opens the menu)
bool Menu_GetBarBackdrop(float* x, float* y, float* w, float* h, float* r)
{
    if (!g_barBlur) return false;
    *x = g_barRect.Min.x; *y = g_barRect.Min.y; *w = g_barRect.GetWidth(); *h = g_barRect.GetHeight(); *r = g_barRect.GetHeight() * 0.5f; return true;
}
bool Menu_GetPopupBackdrop(float* x, float* y, float* w, float* h, float* r)
{
    if (!g_popVisible || !Menu_IsVisible()) return false;
    *x = g_popRect.Min.x; *y = g_popRect.Min.y; *w = g_popRect.GetWidth(); *h = g_popRect.GetHeight(); *r = 10.0f * g_dpi; return true;
}
static ImRect g_animBlurRect; static float g_animBlur = 0.0f;
bool Menu_GetAnimBlur(float* t, float* x0, float* y0, float* x1, float* y1)
{
    if (!Menu_IsVisible() || g_animBlur < 0.01f) return false;
    *t = g_animBlur; *x0 = g_animBlurRect.Min.x; *y0 = g_animBlurRect.Min.y; *x1 = g_animBlurRect.Max.x; *y1 = g_animBlurRect.Max.y;
    return true;
}

enum OvType { OV_NONE, OV_LIMITERS, OV_COMBO, OV_PROFILE, OV_COLOR, OV_FOVPOP, OV_ESPITEMS, OV_SKINS, OV_AIRSTRAFE, OV_HITSOUND, OV_CONFIG, OV_IDEBUG, OV_FLYHACK };
struct Overlay { OvType type = OV_NONE; ImGuiID id = 0; bool open = false; float a = 0.0f; ImRect rect; ImRect opener; };
static Overlay g_ov;
static bool g_blockMain = false;         // mouse is over an overlay -> main layer ignores it
static ImRect g_ovRectPrev;
static bool g_inOverlay = false;          // drawing inside a popup: widgets use the overlay input layer
static Overlay g_ovParent;                 // popup that opened the colour picker (stays visible under it)
static bool g_hasParent = false; static ImRect g_parentRect;

struct BlurRange { int v0, v1; };
static std::vector<BlurRange> g_blurRanges;

// ---------------------------------------------------------------- settings
// colour value: solid or 2-stop gradient, with alpha
struct Col {
    ImU32 c[2]; float a[2] = { 1.0f, 1.0f }; bool grad = false; bool overlay = false;
    Col(ImU32 x = 0xFFFFFF) { c[0] = c[1] = x; }
    Col(ImU32 x, ImU32 y) { c[0] = x; c[1] = y; grad = true; }
};
struct Settings {
    bool  enabled = false, silentAim = false, autoFire = false, refineShot = false;
    float fov = 145.0f;
    bool  hitboxes[6] = { false, false, false, false, false, false };
    float extrapolation = 12.0f, hitChance = 100.0f, minDamage = 100.0f;
    bool  quickStop = false, quickScope = false;
    int   history = 3;
    bool  delayShot[3] = { false, false, false };
    bool  oT3 = false, oT4 = false, oT5 = false, oT6 = false;  // OTHER rows whose labels are hidden in the reference
    bool  g2Enabled = false;
    int   legMovement = 0;
    // limiters
    bool  smooth = false; float nearTarget = 0.62f, curve = 0.35f; int removeSpread = 0; bool freestanding = false;
    float aimFov = 0.842f, aimSpeed = 0.396f, reactionTime = 0.455f, killDelay = 0.475f, maxWalls = 1.0f, backtrack = 0.931f;
    bool  selftrack = false;
    int   config = 0, weapon = 0;
    Col   fovCol = Col(0xFFFFFF);
    bool  showFov = false; float fovFill = 0.15f, fovThick = 0.1f, fovGlow = 0.45f;
} S;

// pages: 0 = Aimbot, 1 = Visuals > Players, 2 = Visuals > World
static int   g_tab = 0, g_plGroup = 0;
static int   g_shownPage = 0;
static float g_pageFade = 1.0f;
static int   PageKey() { return g_tab * 10 + (g_tab == 1 ? g_plGroup : 0); }
struct PlayerCfg {
    bool  enabled = false, arrow = false, sounds = false, soul = false, glow = false;
    Col   arrowCol = 0xFCFEFF, soundsCol = 0xFF6E98, soulCol = 0x6172F3, glowCol = 0xC8C7E5;
    int   model[5] = { 0, 0, 0, 0, 0 };
    Col   modelCol[5] = { 0x96AEFD, 0x5BEEFA, 0xD6DCE1, 0xB7B9BF, 0x9090A4 };
};
static PlayerCfg PL[2];
struct WorldCfg {
    bool  unlockSpec[3] = { false, false, false };
    bool  visualRecoil[2] = { false, false };
    bool  radar = false, killfeed = false, inaccuracy = false;
    Col   inaccuracyCol = 0x76787A;
    int   scopeOverlay = 0;
    bool  grenTraj = false, grenProx = false, impacts = false;
    Col   impactsCol = Col(0xC998AE, 0xAA96C2);
} WD;
struct ProjCfg {   // Combat > Projectiles
    bool  enabled = false, trajectory = false, bounces = false, radius = false;
    bool  types[4] = { false, false, false, false };
    Col   trajCol = Col(0x51A5C1), radiusCol = Col(0xFF6E98);
    bool  helper = false, autoThrow = false;
    float strength = 100.0f;
    int   throwMode = 0;
} PJ;
struct MiscCfg {   // Common > Miscellaneous
    // movement
    bool  bhop = false, airStrafe = false, jumpBug = false, noFall = false, quickStop = false, strafeAssist = false, edgeJump = false, slowWalk = false, fastLadder = false;
    bool  asOpt[6] = { false, true, false, false, false, false };   // Air Strafe popup: Avoid Collisions .. Stop On Key Release
    bool  asSubtick = false; float asTurn = 0.65f;
    // features
    bool  quickSwitch = false, superToss = false, antiAfk = false, unlockLoadout = false, hitSound = false, autoBuy = false, autoGrenade = false, autoAccept = false;
    int   hsEvent[4] = { -1, -1, -1, -1 };   // Hit Sound popup: sound per event (headshot, body, kill, 4th icon), -1 none
    bool  logEv[4] = { false, false, false, false };
    Col   logCol = Col(0xD2ECEC);
    float idManip = 0.5f; bool idLimiters = false;   // Interactive Debug popup
    bool  flyAntiViol = false; float flySpeed = 0.5f, flyCrouch = 0.5f;   // Flyhack popup
} MS;
static const char* GREN_ITEMS[]    = { "HE Grenade", "Flashbang", "Smoke", "Molotov" };
static const char* THROW_ITEMS[]   = { "Left Click", "Right Click", "Jump Throw" };
static const char* MODEL_ITEMS[]  = { "Disabled", "Flat", "Glow", "Glow Outline", "Glass", "Wireframe", "Waterflow", "Galaxy",
                                       "Damascus", "Glitter", "Lightning", "Fire", "Star Nest", "Dissolve", "Ghost", "Hologram", "Rainbow", "Pulse", "Crystal", "Reaver", "Singularity", "Enchanted", "Hex Shield", "Gold", "Active Camo", "Lava", "Liquid Metal", "Aurora", "Recon", "Viper", "Omen", "Galaxy Wireframe" };
static const char* SPEC_ITEMS[]    = { "Perspective", "Enemies", "Teammates" };
static const char* RECOIL_ITEMS[]  = { "No Shake", "No Recoil" };
static const char* SCOPEOV_ITEMS[] = { "Default", "Static", "Dynamic", "Remove" };

// Labels that are covered by the popup in the reference screenshot are left empty on purpose.
// Fill them in here if you know them.
static const char* OTHER_HIDDEN_LABELS[5] = { "", "", "", "", "" };  // OTHER rows 3..7
static const char* GROUP2_HEADER = "";                               // header of the second right group
static const char* GROUP2_ROW0   = "";                               // first row of the second right group

static const char* HITBOX_ITEMS[]   = { "Head", "Chest", "Stomach", "Arms", "Legs", "Feet" };
static const char* HISTORY_ITEMS[]  = { "Off", "Low", "Medium", "High" };
static const char* DELAY_ITEMS[]    = { "On Peek", "Lethal", "Unscoped" };
static const char* LEG_ITEMS[]      = { "Off", "Slide", "Walk" };
static const char* SPREAD_ITEMS[]   = { "Off", "Seed", "Full" };
static const char* WEAPON_ITEMS[]   = { "Global", "Pistols", "Heavy Pistols", "SMG", "Rifles", "Shotguns", "Auto Snipers", "Scout", "AWP" };

// ---------------------------------------------------------------- helpers
static inline ImU32 C(ImU32 rgb, float a = 1.0f)
{
    int ai = (int)(a * 255.0f + 0.5f); if (ai < 0) ai = 0; if (ai > 255) ai = 255;
    return IM_COL32((rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF, ai);
}
static inline ImU32 Mix(ImU32 a, ImU32 b, float t)
{
    if (t < 0) t = 0; if (t > 1) t = 1;
    int r = (int)(((a >> 16) & 0xFF) + (((int)((b >> 16) & 0xFF) - (int)((a >> 16) & 0xFF)) * t));
    int g = (int)(((a >> 8) & 0xFF) + (((int)((b >> 8) & 0xFF) - (int)((a >> 8) & 0xFF)) * t));
    int bl = (int)((a & 0xFF) + (((int)(b & 0xFF) - (int)(a & 0xFF)) * t));
    return (ImU32)((r << 16) | (g << 8) | bl);
}
static inline ImVec2 P(float x, float y) { return ImVec2(O.x + x, O.y + y); }
static inline ImRect R(float x0, float y0, float x1, float y1) { return ImRect(P(x0, y0), P(x1, y1)); }
static inline float Sat(float v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }
static inline float EaseOutCubic(float t) { t = Sat(t); return 1 - powf(1 - t, 3); }
static inline float EaseInOut(float t) { t = Sat(t); return t < 0.5f ? 4 * t * t * t : 1 - powf(-2 * t + 2, 3) / 2; }

static std::unordered_map<ImGuiID, float> g_anim;
static float Anim(ImGuiID id, float target, float speed = 16.0f, float init = -1.0f)
{
    auto it = g_anim.find(id);
    if (it == g_anim.end()) it = g_anim.emplace(id, init < 0 ? target : init).first;
    float& v = it->second;
    v += (target - v) * (1.0f - expf(-speed * g_dt));
    if (fabsf(target - v) < 0.0005f) v = target;
    return v;
}
static ImGuiID Id(const char* s, int n = 0) { return ImHashStr(s, 0, (ImGuiID)n * 2654435761u + 7); }
static float AnimS(const char* key, float target, float speed = 16.0f, int n = 0) { return Anim(Id(key, n), target, speed); }

static bool Hover(const ImRect& r, ImGuiID id, bool overlayLayer = false)
{
    if (g_active && g_active != id) return false;
    if (!overlayLayer && !g_inOverlay && g_blockMain) return false;
    if (g_dragging) return false;
    if (r.Contains(IN.m)) { g_hotAny = true; return true; }
    return false;
}

// text: (x, cy) = left x, vertical centre of capital letters (Inter cap height = 0.727 em)
// sizes are given in em pixels (like CSS / Photoshop); ImGui sizes are ascent-descent heights
static float K(ImFont* f) { return f == F_XB ? 1.2099f : (f == F_ICON ? 1.0f : 1.362f); }
static float Ascent(ImFont* f, float sz) { return f->GetFontBaked(sz * K(f))->Ascent; }
static ImVec2 TextSize(ImFont* f, float sz, const char* t) { return f->CalcTextSizeA(sz * K(f), FLT_MAX, 0.0f, t); }
static void Text(ImFont* f, float sz, ImVec2 p, float cy_abs, ImU32 col, const char* t, const ImVec4* clip = nullptr)
{
    float y = cy_abs - Ascent(f, sz) + sz * (f == F_XB ? 0.727f : 0.714f) * 0.5f;
    AddTextCrisp(f, sz * K(f), ImVec2(SnapL(p.x), SnapL(y)), col, t, clip);
}
static void TextL(ImFont* f, float sz, float x, float cy, ImU32 col, const char* t) { Text(f, sz, P(x, 0), O.y + cy, col, t); }
static void Icon(const char* utf8, float sz, ImVec2 c, ImU32 col)
{
    unsigned int cp = 0; ImTextCharFromUtf8(&cp, utf8, nullptr);
    ImFontGlyph* g = F_ICON->GetFontBaked(sz)->FindGlyph((ImWchar)cp);
    if (!g) return;
    ImVec2 gc((g->X0 + g->X1) * 0.5f, (g->Y0 + g->Y1) * 0.5f);
    AddTextCrisp(F_ICON, sz, ImVec2(SnapL(c.x - gc.x), SnapL(c.y - gc.y)), col, utf8);
}
static void Chevron(ImVec2 c, float w, float h, ImU32 col, float rot01 /*0 = down, 1 = up*/, float th = 1.5f)
{
    float hh = h * (1.0f - 2.0f * rot01);
    ImVec2 pts[3] = { ImVec2(c.x - w * 0.5f, c.y - hh * 0.5f), ImVec2(c.x, c.y + hh * 0.5f), ImVec2(c.x + w * 0.5f, c.y - hh * 0.5f) };
    DL->AddPolyline(pts, 3, col, 0, th);
}
static void ChevronRight(ImVec2 c, float w, float h, ImU32 col, float th = 1.6f)
{
    ImVec2 pts[3] = { ImVec2(c.x - w * 0.5f, c.y - h * 0.5f), ImVec2(c.x + w * 0.5f, c.y), ImVec2(c.x - w * 0.5f, c.y + h * 0.5f) };
    DL->AddPolyline(pts, 3, col, 0, th);
}
static void Shadow(ImRect r, float rounding, float size, float strength, ImVec2 off = ImVec2(0, 0))
{
    const int N = (int)size;
    for (int i = N; i >= 1; --i) {
        float t = (float)i / size;               // 0 inner .. 1 outer
        float a = strength * (1.0f / size) * 2.2f * (1.0f - t) ;
        ImRect e(r.Min - ImVec2((float)i, (float)i) + off, r.Max + ImVec2((float)i, (float)i) + off);
        DL->AddRectFilled(e.Min, e.Max, C(0x000000, a), rounding + i);
    }
}
static void ShadowRing(ImRect r, float rounding, float size, float strength, ImVec2 off = ImVec2(0, 0))
{
    const int N = (int)size;
    for (int i = 1; i <= N; ++i) {
        float acc = 0.0f;
        for (int k = i; k <= N; ++k) acc += strength * (1.0f / size) * 2.2f * (1.0f - (float)k / size);
        float e = i - 1.0f;   // first ring overlaps the menu edge -> no see-through seam at any scale
        DL->AddRect(r.Min - ImVec2(e, e) + off, r.Max + ImVec2(e, e) + off, C(0x000000, acc), rounding + e, 0, 1.25f);
    }
}
// Blurred backdrop behind a rect (acrylic): blur everything drawn so far, then draw it clipped/rounded.
static void Backdrop(const ImRect& r, float rounding, float alpha)
{
    if (!g_plat.blurCallback || !g_plat.blurTex || alpha <= 0.01f) return;
    DL->AddCallback(g_plat.blurCallback, nullptr);
    DL->AddCallback(ImDrawCallback_ResetRenderState, nullptr);
    int v0 = DL->VtxBuffer.Size;
    DL->AddImageRounded(ImTextureRef(g_plat.blurTex), r.Min, r.Max, ImVec2(0, 0), ImVec2(1, 1), C(0xFFFFFF, alpha), rounding);
    g_blurRanges.push_back({ v0, DL->VtxBuffer.Size });
}

static void FadeVerts(int v0, float a)
{
    if (a >= 0.999f) return;
    ImDrawVert* vv = DL->VtxBuffer.Data;
    for (int i = v0; i < DL->VtxBuffer.Size; ++i) {
        ImU32 col = vv[i].col; int a8 = (int)(((col >> IM_COL32_A_SHIFT) & 0xFF) * Sat(a));
        vv[i].col = (col & ~IM_COL32_A_MASK) | ((ImU32)a8 << IM_COL32_A_SHIFT);
    }
}
// ---------------------------------------------------------------- widgets
static void Toggle(const char* key, bool* v, float right, float cy, bool disabled = false)
{
    ImGuiID id = Id(key);
    ImRect r(P(right - 34, cy - 10), P(right, cy + 10));
    ImRect hit(r.Min - ImVec2(4, 4), r.Max + ImVec2(4, 4));
    bool hov = Hover(hit, id) && !disabled;
    if (hov && IN.click) *v = !*v;
    float dis = Anim(id + 2, disabled ? 1.0f : 0.0f, 12.0f);
    int vtx0 = DL->VtxBuffer.Size;
    float t = Anim(id, *v ? 1.0f : 0.0f, 14.0f);
    float h = Anim(id + 1, hov ? 1.0f : 0.0f, 18.0f);
    float e = EaseInOut(t);
    ImU32 track = Mix(0x06090F, ACCENT, e);
    DL->AddRectFilled(r.Min, r.Max, C(track), 10.0f);
    if (e < 0.999f) DL->AddRect(r.Min, r.Max, C(0x12151B, (1 - e) * 1.0f), 10.0f, 0, 1.0f);
    float kx = ImLerp(r.Min.x + 10.0f, r.Max.x - 10.0f, e);
    ImU32 knob = Mix(Mix(0x7D8890, 0xFFFFFF, e), 0xFFFFFF, h * 0.18f);
    DL->AddCircleFilled(ImVec2(kx, r.GetCenter().y), 8.0f, C(knob), 32);
    if (dis > 0.001f) {   // inactive look: fade the whole control
        ImDrawVert* vv = DL->VtxBuffer.Data;
        for (int i = vtx0; i < DL->VtxBuffer.Size; ++i) {
            ImU32 col = vv[i].col; int a8 = (int)(((col >> IM_COL32_A_SHIFT) & 0xFF) * (1.0f - 0.6f * dis));
            vv[i].col = (col & ~IM_COL32_A_MASK) | ((ImU32)a8 << IM_COL32_A_SHIFT);
        }
    }
}
static bool Dots(const char* key, float right, float cy, bool active, bool disabled = false)
{
    ImGuiID id = Id(key);
    ImRect r(P(right - 22, cy - 11.5f), P(right, cy + 12.5f));
    bool hov = Hover(r, id) && !disabled;
    bool clicked = hov && IN.click;
    float a = Anim(id, (hov || active) ? 1.0f : 0.0f, 16.0f);
    float dis = Anim(id + 2, disabled ? 1.0f : 0.0f, 12.0f);
    if (a > 0.003f) DL->AddRectFilled(r.Min, r.Max, C(0x29282F, a), 4.0f);
    ImU32 dc = C(Mix(Mix(0xC9C9D0, 0xE6E5EC, a), 0x4A4A50, dis));
    ImVec2 c = r.GetCenter();
    for (int i = -1; i <= 1; ++i) DL->AddCircleFilled(ImVec2(c.x + i * 4.0f, c.y), 1.45f, dc, 12);
    return clicked;
}
static void Slider(const char* key, float* v, float vmin, float vmax, const char* fmt, float x, float cy, float w, bool valueBox = true)
{
    ImGuiID id = Id(key);
    ImRect track(P(x, cy - 2.5f), P(x + w, cy + 2.5f));
    ImRect hit(P(x - 6, cy - 9), P(x + w + 6, cy + 9));
    bool hov = Hover(hit, id);
    if (hov && IN.click) g_active = id;
    if (g_active == id) {
        g_hotAny = true;
        float t = Sat((IN.m.x - track.Min.x) / w);
        *v = vmin + t * (vmax - vmin);
        if (fmt && strstr(fmt, "%d")) *v = floorf(*v + 0.5f);
        if (!IN.down) g_active = 0;
    }
    float tt = Sat((*v - vmin) / (vmax - vmin));
    float td = Anim(id, tt, 22.0f);
    float hk = Anim(id + 1, (hov || g_active == id) ? 1.0f : 0.0f, 16.0f);
    float kx = track.Min.x + td * w;
    DL->AddRectFilled(track.Min, track.Max, C(0x1C1D26), 3.0f);
    DL->AddRectFilled(track.Min, ImVec2(ImMax(kx, track.Min.x + 3), track.Max.y), C(ACCENT), 3.0f);
    float kr = 6.0f + hk * 0.6f;
    DL->AddCircleFilled(ImVec2(kx, track.GetCenter().y), kr + 1.0f, C(0x000000, 0.18f), 24);
    DL->AddCircleFilled(ImVec2(kx, track.GetCenter().y), kr, C(0xFFFFFF), 24);
    if (valueBox) {
        char buf[32]; snprintf(buf, sizeof buf, fmt, (int)(*v + 0.5f));
        ImVec2 ts = TextSize(F_MED, 10.25f, buf);
        float bw = Anim(id + 2, floorf(ts.x + 13.0f), 20.0f);
        ImRect b(P(x + w + 45 - bw, cy - 11.5f), P(x + w + 45, cy + 11.5f));
        DL->AddRectFilled(b.Min, b.Max, C(0x1A1A25), 3.0f);
        DL->AddRect(b.Min, b.Max, C(0x1E1D29), 3.0f);
        Text(F_MED, 10.25f, ImVec2(b.GetCenter().x - ts.x * 0.5f, 0), b.GetCenter().y, C(Mix(0xB4B3BC, 0xDCDBE2, hk)), buf);
    }
}
// thin popup slider (no knob)
static void BarSlider(const char* key, float* v, float x, float cy, float w, bool rowHover)
{
    ImGuiID id = Id(key);
    ImRect track(P(x, cy - 2.5f), P(x + w, cy + 2.5f));
    ImRect hit(P(x - 4, cy - 9), P(x + w + 4, cy + 9));
    bool hov = Hover(hit, id, true);
    if (hov && IN.click) g_active = id;
    if (g_active == id) { g_hotAny = true; *v = Sat((IN.m.x - track.Min.x) / w); if (!IN.down) g_active = 0; }
    float td = Anim(id, *v, 22.0f);
    float hk = Anim(id + 1, (hov || g_active == id || rowHover) ? 1.0f : 0.0f, 14.0f);
    DL->AddRectFilled(track.Min, track.Max, C(0x1B1D26), 3.0f);
    float fx = track.Min.x + td * w;
    if (fx > track.Min.x + 1) DL->AddRectFilled(track.Min, ImVec2(fx, track.Max.y), C(Mix(ACCENT, Mix(ACCENT, 0xFFFFFF, 0.12f), hk * 0.5f)), 3.0f);
}

// combo box (closed state); returns true when clicked
static bool ComboBox(const char* key, ImRect b, const char* text, bool placeholder, ImU32 bg, ImU32 border, ImU32 txtCol, float txtSize, ImFont* f, float chevronRight, bool clipText)
{
    ImGuiID id = Id(key);
    bool hov = Hover(b, id);
    bool open = g_ov.type == OV_COMBO && g_ov.id == id && g_ov.open;
    float h = Anim(id, (hov || open) ? 1.0f : 0.0f, 16.0f);
    float o = Anim(id + 3, open ? 1.0f : 0.0f, 14.0f);
    DL->AddRectFilled(b.Min, b.Max, C(Mix(bg, Mix(bg, 0xFFFFFF, 0.04f), h)), 4.0f);
    if (border) DL->AddRect(b.Min, b.Max, C(Mix(border, Mix(border, 0xFFFFFF, 0.08f), h)), 4.0f);
    ImU32 tc = placeholder ? Mix(txtCol, 0x000000, 0.18f) : txtCol;
    tc = Mix(tc, 0xFFFFFF, h * 0.12f);
    ImVec4 clip(b.Min.x, b.Min.y, b.Max.x - (chevronRight + 12), b.Max.y);
    Text(f, txtSize, ImVec2(b.Min.x + 7, 0), b.GetCenter().y, C(tc), text, clipText ? &clip : nullptr);
    Chevron(ImVec2(b.Max.x - chevronRight, b.GetCenter().y + 0.5f), 8.0f, 4.0f, C(Mix(0x9E9EA5, 0xD0D0D6, h)), EaseInOut(o), 1.5f);
    return hov && IN.click;
}

// ---------------------------------------------------------------- overlays
struct ComboDesc { const char** items; int count; int* sel; bool* multi; ImRect box; const int* map = nullptr; int maxVis = 0; const bool* off = nullptr; };   // off: disabled rows   // map: list row -> value (click the selected one again = 0)
static std::unordered_map<ImGuiID, ComboDesc> g_combos;
static Col* g_cpOverlayFor = nullptr;
static bool g_plXray = false;           // players preview: show "Behind Walls" chams

static void OpenOverlay(OvType t, ImGuiID id, ImRect opener)
{
    if (g_ov.open && g_ov.type == t && g_ov.id == id) { g_ov.open = false; return; }
    g_ov.type = t; g_ov.id = id; g_ov.open = true; g_ov.a = 0.0f; g_ov.opener = opener;
}
static std::string JoinSel(const char** items, int n, const bool* sel)
{
    std::string s;
    for (int i = 0; i < n; ++i) if (sel[i]) { if (!s.empty()) s += ", "; s += items[i]; }
    return s;
}
static void ComboRow(const char* key, ImRect b, const char** items, int n, int* sel, bool* multi, ImU32 bg = 0x191A25, ImU32 border = 0x1F1F29)
{
    ImGuiID id = Id(key);
    std::string txt = multi ? JoinSel(items, n, multi) : std::string(sel && *sel >= 0 && *sel < n ? items[*sel] : "");
    bool ph = multi && txt.empty();
    if (ph) txt = "Select";
    if (ComboBox(key, b, txt.c_str(), ph, bg, border, 0xBFBEC5, 12.6f, F_MED, 10.0f, true) && n > 0)
        OpenOverlay(OV_COMBO, id, b);
    g_combos[id] = { items, n, sel, multi, b };
}
// chams: no "Disabled" row (click the selected material again to turn it off), opens down, scrolls
static const int CHAMS_MAP[] = { 0, 1, 2, 4, 5, 31, 6, 7, 9, 10, 11, 12, 13, 15, 16, 18, 26, 27, 28, 29, 30 };   // Disabled, Flat, Glow, Glass, Waterflow, Galaxy, Glitter .. Dissolve, Hologram .. Singularity (no Ghost)
static void ChamsRow(const char* key, ImRect b, const char** items, int n, int* sel)
{
    ImGuiID id = Id(key);
    if (ComboBox(key, b, (*sel >= 0 && *sel < n) ? items[*sel] : "", false, 0x191A25, 0x1F1F29, 0xBFBEC5, 12.6f, F_MED, 10.0f, true))
        OpenOverlay(OV_COMBO, id, b);
    g_combos[id] = { items, IM_ARRAYSIZE(CHAMS_MAP), sel, nullptr, b, CHAMS_MAP, 6 };
}

// ---------------------------------------------------------------- layout pieces
static void SectionHeader(float x, float cy, const char* t) { if (*t) TextL(F_MED, 10.0f, x, cy + 0.5f, C(0x4F5057), t); }
static void Card(float x0, float y0, float x1, int rows)
{
    float y1 = y0 + rows * 39.0f;
    ImRect r = R(x0, y0, x1, y1 + 1);
    DL->AddRectFilled(r.Min, r.Max, C(0x14131A), 7.0f);
    for (int i = 0; i < rows; ++i) {   // row hover highlight
        ImRect rr = R(x0 + 1, y0 + 39.0f * i + (i == 0 ? 1.0f : 0.0f), x1 - 1, y0 + 39.0f * (i + 1) + (i == rows - 1 ? 0.0f : 1.0f));
        bool hov = !g_blockMain && !g_dragging && g_active == 0 && rr.Contains(IN.m);
        float h = Anim(Id("cardrow", g_shownPage * 100003 + (int)x0 * 131 + (int)y0 * 7 + i), hov ? 1.0f : 0.0f, 16.0f);
        if (h > 0.003f) {
            ImDrawFlags fl = rows == 1 ? 0 : (i == 0 ? ImDrawFlags_RoundCornersTop : (i == rows - 1 ? ImDrawFlags_RoundCornersBottom : ImDrawFlags_RoundCornersNone));
            DL->AddRectFilled(rr.Min, rr.Max, C(0x1B1A21, h), 6.0f, fl);
        }
    }
    DL->AddRect(r.Min, r.Max, C(0x1A1920), 7.0f, 0, 1.0f);
    for (int i = 1; i < rows; ++i) {
        float y = y0 + 39.0f * i;
        DL->AddLine(P(x0 + 15, y + 0.5f), P(x1 - 15, y + 0.5f), C(0x1B1A21), 1.0f);
    }
}
static float RowCY(float y0, int i) { return y0 + 39.0f * i + 20.0f; }
static void Label(float x, float cy, const char* t, bool dim = false) { if (*t) TextL(F_MED, 12.65f, x, cy + 0.5f, C(dim ? 0x747478 : 0xCDCCD4), t); }
// row with a chevron that opens a sub page
static void NavRow(const char* key, float x0, float x1, float lx, float cy, const char* name)
{
    ImRect rr = R(x0 + 1, cy - 19, x1 - 1, cy + 19);
    ImGuiID id = Id(key);
    bool hov = Hover(rr, id);
    float h = Anim(id, hov ? 1.0f : 0.0f, 14.0f);
    TextL(F_MED, 12.6f, lx, cy, C(Mix(0xC3C5CC, 0xE6E7EB, h)), name);
    ChevronRight(P(x1 - 25 + h * 2.0f, cy), 4.5f, 9.0f, C(Mix(0xC0C2C8, 0xFFFFFF, h)), 1.7f);
}
static std::unordered_map<ImGuiID, struct Col*> g_swatches;
static std::unordered_map<ImGuiID, bool> g_swNoGrad;
static void Swatch(const char* key, Col* col, float cx, float cy, bool allowGrad = true);
// keys that differ per player group (Enemies / Teammates) so animations stay separate
static const char* GK(const char* s)
{
    static char buf[16][48]; static int n = 0;
    char* b = buf[n++ & 15]; snprintf(b, 48, "%s#%d", s, g_plGroup); return b;
}

static void DrawSidebar()
{
    {   // logo text: Momo Signature in the theme colour, centred over the sidebar, with a very faint glow
        const char* t = "Anesthysia";
        const float sz = 25.0f;
        ImVec2 ts = F_SIG->CalcTextSizeA(sz, FLT_MAX, 0.0f, t);
        ImVec2 p = P(floorf((170.0f - ts.x) * 0.5f), floorf(28.0f - ts.y * 0.5f));
        for (int ring = 1; ring <= 3; ++ring) {   // glow: 3 rings of 12 copies, each almost transparent
            float r = 1.3f * ring, a = 0.022f / ring;
            for (int i = 0; i < 12; ++i) {
                float ang = i * IM_PI / 6.0f;
                AddTextCrisp(F_SIG, sz, p + ImVec2(cosf(ang) * r, sinf(ang) * r), C(ACCENT, a), t);
            }
        }
        AddTextCrisp(F_SIG, sz, p, C(Mix(ACCENT, 0xFFFFFF, 0.12f)), t);
    }
    DL->AddLine(P(9, 55.5f), P(159, 55.5f), C(0x12141A));

    // COMBAT: Aimbot, Projectiles
    // COMMON: Visuals (Players / World), Inventory, Miscellaneous
    // tabs: 0 Aimbot, 4 Projectiles, 1 Players, 2 World, 3 Inventory, 5 Miscellaneous
    // Visuals expands into its sub items (animated); the items below slide down
    float ex  = AnimS("vis_expand", (g_tab == 1 || g_tab == 2) ? 1.0f : 0.0f, 13.0f);
    float shiftV = 74.0f * ex, shift = shiftV;
    const float visCY = 209.0f;
    SectionHeader(19, 73.5f, "COMBAT");
    SectionHeader(19, 181.5f, "COMMON");
    // custom: 0 = font icon, 1 = Misc grid icon, 2 = aim ring + dot
    auto item = [&](int n, const char* icon, int custom, const char* name, float cy, float icx, float tx, float bx0,
                    bool sel, float half, float isz, bool enabled) -> bool {
        ImRect r = R(bx0, cy - 16, 159, cy + 16);
        ImGuiID id = Id("tab", n);
        bool hov = enabled && Hover(r, id);
        float h = Anim(id, hov ? 1.0f : 0.0f, 14.0f);
        float s = Anim(id + 1, sel ? 1.0f : 0.0f, 12.0f);
        if (s > 0.003f) DL->AddRectFilled(r.Min, r.Max, C(0x222329, s), 5.0f);
        if (h > 0.003f && !sel) DL->AddRectFilled(r.Min, r.Max, C(0x222329, h * 0.35f * (1.0f - s)), 5.0f);
        ImU32 tc = Mix(Mix(Mix(0x75777B, 0x9FA1A6, h), 0xBDBFC4, half), 0xD9DBDF, s);
        ImU32 ic = Mix(Mix(Mix(0x84868C, 0xA9ABB0, h), 0xB0B2B7, half), Mix(ACCENT, 0xA9ABB0, 0.3f), s);
        ImVec2 ic_c = P(icx, cy);
        if (custom == 0) Icon(icon, isz, ic_c, C(ic));
        else if (custom == 2) {   // aim (bullseye): outer ring, inner ring, centre dot
            DL->AddCircle(ic_c, 6.3f, C(ic), 40, 1.5f);
            DL->AddCircle(ic_c, 3.5f, C(ic), 28, 1.4f);
            DL->AddCircleFilled(ic_c, 1.15f, C(ic), 12);
        } else {
            ImRect q(ic_c - ImVec2(5.5f, 5.5f), ic_c + ImVec2(5.5f, 5.5f));
            DL->AddRectFilled(q.Min, q.Max, C(ic), 2.0f);
            ImU32 bgc = C(0x0A0C12);
            DL->AddRectFilled(ImVec2(q.Min.x + 2, q.Min.y + 2.2f), ImVec2(q.Min.x + 5.0f, q.Min.y + 4.8f), bgc, 0.5f);
            DL->AddRectFilled(ImVec2(q.Min.x + 6.2f, q.Min.y + 3.0f), ImVec2(q.Max.x - 2, q.Min.y + 4.0f), bgc);
            DL->AddRectFilled(ImVec2(q.Min.x + 2, q.Min.y + 7.0f), ImVec2(q.Min.x + 4.8f, q.Min.y + 8.0f), bgc);
            DL->AddRectFilled(ImVec2(q.Min.x + 6.0f, q.Min.y + 6.2f), ImVec2(q.Max.x - 2, q.Min.y + 8.8f), bgc, 0.5f);
        }
        TextL(F_MED, 13.1f, tx, cy, C(tc), name);
        return hov && IN.click;
    };
    auto go = [&](int t) { if (g_tab != t) { g_tab = t; if (g_ov.open && g_ov.type != OV_PROFILE) g_ov.open = false; } };
    // ---- COMBAT
    if (item(0,  "\xef\x81\x9b", 0, "Aimbot",      101.0f, 26, 44, 9, g_tab == 0, 0.0f, 12.5f, true)) go(0);   // crosshairs f05b
    if (item(12, "\xef\x84\xb5", 0, "Projectiles", 138.0f, 26, 44, 9, g_tab == 4, 0.0f, 12.5f, true)) go(4);   // rocket f135
    // ---- COMMON
    if (item(1, "\xef\x80\xbe", 0, "Visuals", visCY, 26, 44, 9, false, 0.0f, 13.0f, true)) { if (g_tab != 1 && g_tab != 2) go(1); }  // image f03e
    if (ex > 0.003f) {   // Visuals sub items
        int v0 = DL->VtxBuffer.Size;
        DL->PushClipRect(P(0, visCY + 17), P(170, visCY + 17 + shiftV), true);
        float dy = -(1.0f - ex) * 12.0f;
        bool en = ex > 0.6f;
        if (item(10, "\xef\x80\x87", 0, "Players", visCY + 37.0f + dy, 41, 59, 24, g_tab == 1, 0.0f, 11.5f, en)) go(1);   // user f007
        if (item(11, "\xef\x95\xbd", 0, "World",   visCY + 74.0f + dy, 41, 59, 24, g_tab == 2, 0.0f, 12.0f, en)) go(2);   // earth-americas f57d
        DL->PopClipRect();
        FadeVerts(v0, ex);
    }
    if (item(2, "\xef\x97\xbd", 0, "Inventory",   246.0f + shift, 26, 44, 9, g_tab == 3, 0.0f, 13.0f, true)) go(3);   // layer-group f5fd
    if (item(3, "",             1, "Miscellaneous", 283.0f + shift, 26, 44, 9, g_tab == 5, 0.0f, 13.0f, true)) go(5);

    // profile
    DL->AddLine(P(9, 557.5f), P(159, 557.5f), C(0x13151B));
    ImRect pr = R(9, 560, 159, 610);
    bool ph = Hover(pr, Id("profile")) || (g_ov.type == OV_PROFILE && g_ov.open);
    if (Hover(pr, Id("profile")) && IN.click) OpenOverlay(OV_PROFILE, Id("profile"), pr);
    {
        float bg = AnimS("profilebg", ph ? 1.0f : 0.0f, 14.0f);
        if (bg > 0.003f) DL->AddRectFilled(pr.Min, pr.Max, C(0x171820, bg * 0.9f), 6.0f);
    }
    float pa = AnimS("profile", ph ? 1.0f : 0.0f, 14.0f);
    if (g_plat.avatarTex) DL->AddImageRounded(ImTextureRef(g_plat.avatarTex), P(13, 567), P(49, 603), ImVec2(0, 0), ImVec2(1, 1), C(0xFFFFFF), 18.0f);
    else DL->AddCircleFilled(P(31, 585), 17, C(0x2A2A30), 32);
    {
        const char* nick = "Afraid";
        float nsz = 13.0f, nw = TextSize(F_MED, nsz, nick).x, maxw = 84.0f;
        if (nw > maxw) nsz *= maxw / nw;
        TextL(F_MED, nsz, 59, 577.5f, C(Mix(0xD2D4D8, 0xF0F1F3, pa)), nick);
    }
    TextL(F_MED, 10.75f, 60, 596.0f, C(0x515359), "7 days left");
    ChevronRight(P(150 + pa * 1.5f, 584.5f), 4.5f, 9.0f, C(Mix(0xB8BABE, 0xE5E6E8, pa)), 1.6f);
}

static const char* CfgActiveName();
static void CfgSaveActive();
static void DrawTopbar()
{
    DL->AddLine(P(170, 55.5f), P(797, 55.5f), C(0x16161C));
    // config group: [save | name v]
    ImRect g = R(180, 13, 379, 43);
    DL->AddRectFilled(g.Min, g.Max, C(0x0C0E12), 4.0f);
    ImRect sv = R(180, 13, 215, 43);
    bool sh = Hover(sv, Id("save"));
    static float saveFlash = 0.0f;
    if (sh && IN.click) { saveFlash = 1.0f; CfgSaveActive(); }
    saveFlash = ImMax(0.0f, saveFlash - g_dt * 2.5f);
    float sa = AnimS("save", sh ? 1.0f : 0.0f, 16.0f);
    DL->AddRectFilled(sv.Min, sv.Max, C(Mix(0x0F1017, 0x171821, sa)), 4.0f, ImDrawFlags_RoundCornersLeft);
    DL->AddRect(g.Min, g.Max, C(0x14161A), 4.0f);
    DL->AddLine(P(215.5f, 14), P(215.5f, 42), C(0x17181F));
    Icon("\xef\x83\x87", 13.0f, P(197.5f, 28.5f), C(Mix(Mix(0xD9D8DD, 0xFFFFFF, sa), ACCENT, saveFlash)));  // floppy f0c7
    {
        ImRect cb = R(216, 14, 378, 42);
        ImGuiID id = Id("cfg");
        bool hov = Hover(cb, id);
        bool open = g_ov.type == OV_CONFIG && g_ov.open;
        float h = Anim(id, (hov || open) ? 1.0f : 0.0f, 16.0f);
        float o = Anim(id + 3, open ? 1.0f : 0.0f, 14.0f);
        ImVec4 clip(P(229, 0).x, P(0, 14).y, P(348, 0).x, P(0, 42).y);
        Text(F_MED, 12.75f, P(229, 0), O.y + 28.5f, C(Mix(0xA4A5AC, 0xD5D6DB, h)), CfgActiveName(), &clip);
        Chevron(P(361, 29), 8.0f, 4.0f, C(Mix(0x9E9EA3, 0xD0D0D6, h)), EaseInOut(o));
        if (hov && IN.click) OpenOverlay(OV_CONFIG, id, R(180, 13, 379, 43));
    }
    float wpa = AnimS("weapon_vis", g_tab == 0 ? 1.0f : 0.0f, 14.0f);   // weapon selector only on the Aimbot page
    if (wpa > 0.003f) {
        int wv0 = DL->VtxBuffer.Size;
        ImRect b = R(394, 13, 480, 43);
        ImGuiID id = Id("weapon");
        bool hov = g_tab == 0 && Hover(b, id);
        bool open = g_ov.type == OV_COMBO && g_ov.id == id && g_ov.open;
        float h = Anim(id, (hov || open) ? 1.0f : 0.0f, 16.0f);
        float o = Anim(id + 3, open ? 1.0f : 0.0f, 14.0f);
        DL->AddRectFilled(b.Min, b.Max, C(Mix(0x0E1015, 0x14161C, h)), 4.0f);
        DL->AddRect(b.Min, b.Max, C(0x17171C), 4.0f);
        TextL(F_MED, 13.0f, 406, 28.5f, C(Mix(0xA09FA4, 0xD5D6DB, h)), WEAPON_ITEMS[S.weapon]);
        float tw = TextSize(F_MED, 13.0f, WEAPON_ITEMS[S.weapon]).x;
        float bw = ImMax(86.0f, tw + 12 + 30);
        (void)bw;
        Chevron(P(462, 29), 8.0f, 4.0f, C(Mix(0x9B9DA2, 0xD0D0D6, h)), EaseInOut(o));
        if (hov && IN.click) OpenOverlay(OV_COMBO, id, b);
        g_combos[id] = { WEAPON_ITEMS, IM_ARRAYSIZE(WEAPON_ITEMS), &S.weapon, nullptr, b };
        FadeVerts(wv0, wpa);
    }
    // search
    ImRect sr = R(758, 15, 782, 40);
    bool srh = Hover(sr, Id("search"));
    float sa2 = AnimS("search", srh ? 1.0f : 0.0f, 16.0f);
    ImU32 scol = C(Mix(0xA0A2A8, 0xE2E3E6, sa2));
    ImVec2 c = P(769.0f, 26.0f);
    DL->AddCircle(c, 4.6f, scol, 24, 1.7f);
    DL->AddLine(c + ImVec2(3.4f, 3.4f), c + ImVec2(7.2f, 7.2f), scol, 1.9f);
}

static void DrawRage()
{
    // ---- MAIN
    const float L0 = 180, L1 = 481, LR = 466, LX = 195;
    SectionHeader(195, 73.5f, "MAIN");
    Card(L0, 85, L1, 6);
    float y = 85;
    Label(LX, RowCY(y, 0), "Enabled");
    {
        bool act = (g_ov.type == OV_FOVPOP && g_ov.open) || (g_hasParent && g_ovParent.type == OV_FOVPOP && g_ov.type == OV_COLOR && g_ov.open);
        if (Dots("fovpop", 427, RowCY(y, 0), act)) OpenOverlay(OV_FOVPOP, Id("fovpop"), R(405, RowCY(y, 0) - 11.5f, 427, RowCY(y, 0) + 12.5f));
    }
    Toggle("enabled", &S.enabled, LR, RowCY(y, 0));
    Label(LX, RowCY(y, 1), "Silent Aim");   Toggle("silent", &S.silentAim, LR, RowCY(y, 1));
    Label(LX, RowCY(y, 2), "Automatic Fire"); Toggle("autofire", &S.autoFire, LR, RowCY(y, 2));
    {   // Smooth: inactive while Silent Aim is on
        bool off = S.silentAim;
        float dis = AnimS("smooth_dis", off ? 1.0f : 0.0f, 12.0f);
        TextL(F_MED, 12.65f, LX, RowCY(y, 3) + 0.5f, C(Mix(0xCDCCD4, 0x5A5A60, dis)), "Smooth");
        if (off && g_ov.type == OV_LIMITERS) g_ov.open = false;
        bool act = g_ov.type == OV_LIMITERS && g_ov.open;
        if (Dots("limiters", 427, RowCY(y, 3), act, off)) OpenOverlay(OV_LIMITERS, Id("limiters"), R(405, RowCY(y, 3) - 11.5f, 427, RowCY(y, 3) + 12.5f));
        Toggle("smooth", &S.smooth, LR, RowCY(y, 3), off);
    }
    Label(LX, RowCY(y, 4), "Refine Shot");  Toggle("refine", &S.refineShot, LR, RowCY(y, 4));
    Label(LX, RowCY(y, 5), "Field of View"); Slider("fov", &S.fov, 0, 180, "%d\xc2\xb0", 331, RowCY(y, 5), 90);

    // ---- SELECTION
    SectionHeader(194, 344.5f, "SELECTION");
    y = 356;
    Card(L0, y, L1, 6);
    Label(LX, RowCY(y, 0), "Hitboxes");
    ComboRow("hitboxes", R(331, RowCY(y, 0) - 12, 466, RowCY(y, 0) + 12), HITBOX_ITEMS, 6, nullptr, S.hitboxes);
    Label(LX, RowCY(y, 1), "Extrapolation"); Slider("extrap", &S.extrapolation, 0, 18, "%d", 331, RowCY(y, 1), 90);
    Label(LX, RowCY(y, 2), "Hit Chance");    Dots("hc_dots", 324, RowCY(y, 2), false); Slider("hc", &S.hitChance, 0, 100, "%d%%", 331, RowCY(y, 2), 90);
    Label(LX, RowCY(y, 3), "Min Damage");    Slider("mindmg", &S.minDamage, 0, 104, "%d", 331, RowCY(y, 3), 90);
    Label(LX, RowCY(y, 4), "Quick Stop");    Dots("qs_dots", 427, RowCY(y, 4), false); Toggle("quickstop", &S.quickStop, LR, RowCY(y, 4));
    Label(LX, RowCY(y, 5), "Quick Scope");   Toggle("quickscope", &S.quickScope, LR, RowCY(y, 5));

    // ---- OTHER
    const float R0 = 491, R1 = 787, RR = 772, RX = 506;
    SectionHeader(505, 73.5f, "OTHER");
    y = 85;
    Card(R0, y, R1, 6);
    Label(RX, RowCY(y, 0), "History");
    ComboRow("history", R(640, RowCY(y, 0) - 12, 772, RowCY(y, 0) + 12), HISTORY_ITEMS, 4, &S.history, nullptr);
    Label(RX, RowCY(y, 1), "Delay Shot");
    Dots("ds_dots", 633, RowCY(y, 1), false);
    ComboRow("delayshot", R(640, RowCY(y, 1) - 12, 772, RowCY(y, 1) + 12), DELAY_ITEMS, 3, nullptr, S.delayShot);
    Label(RX, RowCY(y, 2), "Remove Spread");
    ComboRow("rspread", R(640, RowCY(y, 2) - 12, 772, RowCY(y, 2) + 12), SPREAD_ITEMS, 3, &S.removeSpread, nullptr);
    Label(RX, RowCY(y, 3), "Quick Peek Assist"); Toggle("o3", &S.oT3, RR, RowCY(y, 3));
    Label(RX, RowCY(y, 4), "Power Shot"); Dots("o4_dots", 733, RowCY(y, 4), false); Toggle("o4", &S.oT4, RR, RowCY(y, 4));
    {   // Back Camera: inactive while Silent Aim is on
        float dis = AnimS("backcam_dis", S.silentAim ? 1.0f : 0.0f, 12.0f);
        TextL(F_MED, 12.65f, RX, RowCY(y, 5) + 0.5f, C(Mix(0xCDCCD4, 0x5A5A60, dis)), "Back Camera");
        Toggle("o5", &S.oT5, RR, RowCY(y, 5), S.silentAim);
    }

    // ---- second right group
    SectionHeader(505, 384.5f - 39.0f, "ANTI AIM");
    y = 396 - 39;
    Card(R0, y, R1, 6);
    {   // Anti Aim Enabled: inactive while Silent Aim is off
        bool off = !S.silentAim;
        float dis = AnimS("aa_dis", off ? 1.0f : 0.0f, 12.0f);
        TextL(F_MED, 12.65f, RX, RowCY(y, 0) + 0.5f, C(Mix(0xCDCCD4, 0x5A5A60, dis)), "Enabled");
        Dots("g2_dots", 733, RowCY(y, 0), false, off);
        Toggle("g2en", &S.g2Enabled, RR, RowCY(y, 0), off);
    }
    Label(RX, RowCY(y, 1), "Leg Movement");
    ComboRow("legmove", R(640, RowCY(y, 1) - 12, 772, RowCY(y, 1) + 12), LEG_ITEMS, 3, &S.legMovement, nullptr);
    const char* nav[3] = { "Pitch", "Yaw", "Camera Override" };
    for (int i = 0; i < 3; ++i) {
        float cy = RowCY(y, 2 + i);
        ImRect rr = R(R0 + 1, cy - 19, R1 - 1, cy + 19);
        ImGuiID id = Id("nav", i);
        bool hov = Hover(rr, id);
        float h = Anim(id, hov ? 1.0f : 0.0f, 14.0f);
        TextL(F_MED, 12.6f, RX, cy, C(Mix(0xC3C5CC, 0xE6E7EB, h)), nav[i]);
        ChevronRight(P(762 + h * 2.0f, cy), 4.5f, 9.0f, C(Mix(0xC0C2C8, 0xFFFFFF, h)), 1.7f);
    }
    Label(RX, RowCY(y, 5), "Freestanding"); Toggle("freestand", &S.freestanding, RR, RowCY(y, 5));
}

// ---- Visuals > Players
// ---- ESP preview: real 3D model (software rasterised on a worker thread) + ESP overlay
struct EC { float a[4], b[4]; bool grad; };        // ESP colour: solid or gradient
struct EspPrevCfg {
    bool  box = false, name = false, health = false, armor = false, weapon = false, weaponIcon = false, distance = false, flags = false, skeleton = false, headDot = false;
    EC    boxCol = { { 1, 1, 1, 1 }, { 0.62f, 0.66f, 1.0f, 1 }, false }, nameCol = { { 1, 1, 1, 1 }, { 0.75f, 0.78f, 0.86f, 1 }, false };
    EC    healthCol = { { 0.45f, 0.92f, 0.42f, 1 }, { 0.93f, 0.33f, 0.30f, 1 }, false }, armorCol = { { 0.36f, 0.62f, 1.0f, 1 }, { 0.60f, 0.40f, 1.0f, 1 }, false };
    EC    weaponCol = { { 0.86f, 0.86f, 0.90f, 1 }, { 0.55f, 0.56f, 0.62f, 1 }, false }, iconCol = { { 0.92f, 0.92f, 0.95f, 1 }, { 0.55f, 0.58f, 0.68f, 1 }, false };
    EC    distCol = { { 0.72f, 0.72f, 0.78f, 1 }, { 0.5f, 0.5f, 0.56f, 1 }, false }, flagsCol = { { 1.0f, 0.78f, 0.36f, 1 }, { 1.0f, 0.45f, 0.30f, 1 }, false };
    EC    skelCol = { { 1, 1, 1, 0.9f }, { 0.55f, 0.6f, 1.0f, 0.9f }, false }, headCol = { { 1.0f, 0.36f, 0.36f, 1 }, { 1.0f, 0.7f, 0.3f, 1 }, false };
    int   hp = 100, ap = 100, weaponIdx = 1;
    bool  hpAnim = true, idleAnim = true, avatar = false;
    int   model = 1;                      // preview model: 0 default, 1 Standoff 2 (Enemies = CT Michael + M4, Teammates = T Scrap + AKR)
    int   boxType = 0;                    // 0 default, 1 corner, 2 3D
    EC    inv[10];                        // invisible (behind walls) colours, same order as the Debug list
    int   font = 2;                       // 0 default, 1 Verdana, 2 pixel
    float nameSize = 13.5f;
    int   nameFont = 2, nameCase = 0;     // name element: font 0 default 1 Verdana 2 pixel 3 console, case 0 default 1 upper 2 lower
    bool  flag[15] = { true, false, false, true, false, false, false, false, false, false, false, false, true, false, false };
    bool  readiness = false, wBomb = false, wDefuser = false, wTaser = false, hitboxes = false;
};
static EspPrevCfg EP;
static const char* FLAG_NAMES[15] = { "Unarmored", "Defuser", "Blind", "Scoped", "Reload", "Immunity", "Slowed", "Vulnerable", "Bomb", "Hostage", "Defuse", "Pin Pulled", "Money", "Order Priority", "Delay" };
static const char* FLAG_TEXT[15]  = { "HK", "KIT", "BLIND", "ZOOM", "RELOAD", "IMMUNE", "SLOW", "VULN", "C4", "HOSTAGE", "DEFUSING", "PIN", "$4750", "PRIO", "DELAY" };
static const char* NAME_FONTS[4] = { "Default", "Verdana", "Pixel", "Console" };
static const char* NAME_CASES[3] = { "Default", "Uppercase", "Lowercase" };
static Col g_nameCP;                       // proxy for the ESP element colour picker: [0] visible, [1] behind walls
static int g_espCPIdx = -1;                // EspCols index edited by the picker (-1 none)
static ImGuiID g_rcloseId = 0;             // picker closed by this frame's right click (toggle, don't reopen)
static int   g_espSide[8] = { 0, 2, 1, 1, 1, 1, 3, 0 };     // name, hp, armor, weapon, icon, distance, flags, avatar -> 0 top 1 bottom 2 left 3 right
static float g_espOrd[8]  = { 0, 0, 0, 1, 2, 3, 0, 1 };
static ImRect g_espHit[8]; static bool g_espHitOk[8];
static bool  g_avAttach = true;   // avatar glued to the start of the name (same line)
static int   g_espDrag = -1; static ImVec2 g_espGrab; static ImRect g_espBox;
static EC* EspCols(EspPrevCfg& e, int i);
static EC* EspCols(EspPrevCfg& e, int i) { EC* c[10] = { &e.boxCol, &e.nameCol, &e.healthCol, &e.armorCol, &e.weaponCol, &e.iconCol, &e.distCol, &e.flagsCol, &e.skelCol, &e.headCol }; return c[i]; }
static bool EspPickerOpen() { return g_ov.type == OV_COLOR && g_espCPIdx >= 0 && g_ov.id == Id("esp_cp", g_espCPIdx); }
static void OpenEspPicker(int ci, ImRect opener, bool keepParent)   // right click on an ESP element / ESP Items chip
{
    ImGuiID cid = Id("esp_cp", ci);
    if (cid == g_rcloseId) { g_rcloseId = 0; return; }
    auto toCol = [](const float* f, ImU32& c, float& a) { c = ((ImU32)(ImSaturate(f[0]) * 255 + 0.5f) << 16) | ((ImU32)(ImSaturate(f[1]) * 255 + 0.5f) << 8) | (ImU32)(ImSaturate(f[2]) * 255 + 0.5f); a = f[3]; };
    toCol(EspCols(EP, ci)->a, g_nameCP.c[0], g_nameCP.a[0]); toCol(EP.inv[ci].a, g_nameCP.c[1], g_nameCP.a[1]); g_nameCP.grad = false;
    g_espCPIdx = ci;
    g_swatches[cid] = &g_nameCP; g_swNoGrad[cid] = true;
    if (!keepParent) g_hasParent = false;
    OpenOverlay(OV_COLOR, cid, opener);
}
static void SyncEspPicker()   // picker -> ESP colours
{
    if (!EspPickerOpen()) return;
    auto toF = [](ImU32 c, float a, float* f) { f[0] = ((c >> 16) & 0xFF) / 255.0f; f[1] = ((c >> 8) & 0xFF) / 255.0f; f[2] = (c & 0xFF) / 255.0f; f[3] = a; };
    toF(g_nameCP.c[0], g_nameCP.a[0], EspCols(EP, g_espCPIdx)->a); toF(g_nameCP.c[1], g_nameCP.a[1], EP.inv[g_espCPIdx].a);
}
static void EspInitInv()
{   // default invisible palette: cooler / dimmer versions of the visible colours
    static const float iv[10][4] = { { 0.62f, 0.66f, 1.0f, 1 }, { 0.78f, 0.80f, 0.90f, 1 }, { 0.45f, 0.92f, 0.42f, 0.8f }, { 0.36f, 0.62f, 1.0f, 0.8f },
                                     { 0.70f, 0.72f, 0.82f, 1 }, { 0.70f, 0.74f, 0.88f, 1 }, { 0.60f, 0.62f, 0.72f, 1 }, { 0.95f, 0.62f, 0.40f, 1 },
                                     { 0.62f, 0.66f, 1.0f, 0.9f }, { 1.0f, 0.62f, 0.30f, 1 } };
    for (int i = 0; i < 10; ++i) { EC& d = EP.inv[i]; const EC& v = *EspCols(EP, i); for (int q = 0; q < 4; ++q) { d.a[q] = iv[i][q]; d.b[q] = v.b[q]; } d.grad = false; }
}
static bool g_espInvInit = (EspInitInv(), true);
static float g_animT = -1.0f;
static ImTextureData* g_avTex = nullptr;    // avatar next to the name
static ImFont* EF(ImFont* def) { return EP.font == 1 ? F_VERD : (EP.font == 2 ? F_SPIX : def); }
static ImFont* FontBy(int f, ImFont* def) { return f == 1 ? F_VERD : (f == 2 ? F_SPIX : (f == 3 ? F_PIX : def)); }
static float SizeBy(int f, float sz) { return f == 2 ? ImMax(8.0f, roundf(sz * 10.0f / 13.0f)) : (f == 1 ? sz * 0.93f : (f == 3 ? 13.0f : sz)); }
static float ES(float sz) { return EP.font == 2 ? ImMax(8.0f, roundf(sz * 10.0f / 13.0f)) : (EP.font == 1 ? sz * 0.93f : sz); }   // debug: fixed animation time
static const int MDL_W = 480, MDL_H = 924;           // render buffer (2x the 240x462 preview rect)
static ImTextureData* g_mdlTex = nullptr;
static ImTextureData* g_wiTex = nullptr;     // weapon icon atlas
static std::mutex g_mdlMx; static std::condition_variable g_mdlCv;
static bool g_mdlJob = false, g_mdlReady = false, g_mdlBusy = false, g_mdlSync = false, g_mdlHave = false;
static M3DSettings g_mdlJobS, g_mdlReqS, g_mdlShownS, g_mdlDoneS;
static M3DOut g_mdlDoneO, g_mdlShownO;
static std::vector<uint8_t> g_mdlDone;
static double g_mdlReqT = -1.0;
static float g_mdlYaw = 0.0f, g_mdlVel = 0.0f;
void Menu_Debug3DSync(bool on) { g_mdlSync = on; }
static bool SameS(const M3DSettings& a, const M3DSettings& b)
{
    return a.yaw == b.yaw && a.pitch == b.pitch && a.mat == b.mat && !memcmp(a.col, b.col, sizeof a.col) && a.halo == b.halo && a.overlay == b.overlay &&
           !memcmp(a.haloCol, b.haloCol, sizeof a.haloCol) && a.time == b.time && a.bright == b.bright && a.anim == b.anim && a.model == b.model && a.rag == b.rag && a.ragA == b.ragA && a.look == b.look;
}
static void MdlWorker()
{
    std::vector<uint8_t> buf(MDL_W * MDL_H * 4);
    for (;;) {
        M3DSettings js;
        { std::unique_lock<std::mutex> lk(g_mdlMx); g_mdlCv.wait(lk, [] { return g_mdlJob; }); js = g_mdlJobS; g_mdlJob = false; }
        M3DOut o; M3D_Render(buf.data(), MDL_W, MDL_H, js, &o);
        std::lock_guard<std::mutex> lk(g_mdlMx);
        g_mdlDone.swap(buf); if (buf.size() != g_mdlDone.size()) buf.resize(g_mdlDone.size());
        g_mdlDoneS = js; g_mdlDoneO = o; g_mdlReady = true; g_mdlBusy = false;
    }
}
static void KfxLoadTex();
static void MdlUpdate(const M3DSettings& want, bool animated)
{
    if (!g_mdlTex) {
        M3D_Init();
        g_mdlTex = IM_NEW(ImTextureData)();
        g_mdlTex->Create(ImTextureFormat_RGBA32, MDL_W, MDL_H);
        memset(g_mdlTex->Pixels, 0, MDL_W * MDL_H * 4);
        ImGui::RegisterUserTexture(g_mdlTex);
        g_mdlDone.resize(MDL_W * MDL_H * 4);
        if (!g_mdlSync) std::thread(MdlWorker).detach();
        KfxLoadTex();
        int w, h; unsigned char* px = M3D_DecodeImage(WI_PNG, (int)sizeof(WI_PNG), &w, &h, 1);
        if (px) {
            g_wiTex = IM_NEW(ImTextureData)();
            g_wiTex->Create(ImTextureFormat_RGBA32, w, h);
            unsigned char* d = (unsigned char*)g_wiTex->Pixels;
            for (int i = 0; i < w * h; ++i) { d[i * 4] = d[i * 4 + 1] = d[i * 4 + 2] = 255; d[i * 4 + 3] = px[i]; }
            M3D_FreeImage(px);
            ImGui::RegisterUserTexture(g_wiTex);
        }
        px = M3D_DecodeImage(AV_PNG, (int)sizeof(AV_PNG), &w, &h, 4);
        if (px) {
            g_avTex = IM_NEW(ImTextureData)();
            g_avTex->Create(ImTextureFormat_RGBA32, w, h);
            memcpy(g_avTex->Pixels, px, w * h * 4);
            M3D_FreeImage(px);
            ImGui::RegisterUserTexture(g_avTex);
        }
    }
    double now = ImGui::GetTime();
    bool need = !g_mdlHave || !SameS(want, g_mdlReqS);
    if (animated && need && g_mdlHave && now - g_mdlReqT < 1.0 / 45.0 && want.mat == g_mdlReqS.mat) need = false;   // animated materials: ~45 fps
    bool fresh = false;
    if (g_mdlSync) {
        if (need) { M3D_Render(g_mdlDone.data(), MDL_W, MDL_H, want, &g_mdlDoneO); g_mdlDoneS = want; g_mdlReqS = want; g_mdlReqT = now; g_mdlHave = true; fresh = true; }
    } else {
        std::lock_guard<std::mutex> lk(g_mdlMx);
        if (need && !g_mdlBusy) { g_mdlJobS = want; g_mdlJob = true; g_mdlBusy = true; g_mdlReqS = want; g_mdlReqT = now; g_mdlHave = true; g_mdlCv.notify_one(); }
        if (g_mdlReady) { g_mdlReady = false; fresh = true; }
    }
    if (fresh) {
        if (!g_mdlSync) g_mdlMx.lock();
        memcpy(g_mdlTex->Pixels, g_mdlDone.data(), MDL_W * MDL_H * 4);
        g_mdlShownS = g_mdlDoneS; g_mdlShownO = g_mdlDoneO;
        if (!g_mdlSync) g_mdlMx.unlock();
        if (g_mdlTex->Status == ImTextureStatus_OK) {
            ImTextureRect r = { 0, 0, (unsigned short)MDL_W, (unsigned short)MDL_H };
            g_mdlTex->Updates.resize(0); g_mdlTex->Updates.push_back(r); g_mdlTex->UpdateRect = r; g_mdlTex->UsedRect = r;
            g_mdlTex->SetStatus(ImTextureStatus_WantUpdates);
        }
    }
}
static void ColF(float* d, const Col& c) { d[0] = ((c.c[0] >> 16) & 0xFF) / 255.0f; d[1] = ((c.c[0] >> 8) & 0xFF) / 255.0f; d[2] = (c.c[0] & 0xFF) / 255.0f; d[3] = c.a[0]; }
static ImU32 CF(const float* c, float a = 1.0f) { return IM_COL32((int)(c[0] * 255 + 0.5f), (int)(c[1] * 255 + 0.5f), (int)(c[2] * 255 + 0.5f), (int)(ImClamp(c[3] * a, 0.0f, 1.0f) * 255 + 0.5f)); }
static void OutlinedText(ImFont* f, float sz, ImVec2 pos, ImU32 col, const char* t)
{
    ImU32 sh = IM_COL32(0, 0, 0, (int)(((col >> IM_COL32_A_SHIFT) & 0xFF) * 0.85f));
    for (int k = 0; k < 4; ++k) DL->AddText(f, sz, pos + ImVec2(k == 0 ? -1.0f : (k == 1 ? 1.0f : 0.0f), k == 2 ? -1.0f : (k == 3 ? 1.0f : 0.0f)), sh, t);
    DL->AddText(f, sz, pos, col, t);
}
static void DrawEspPreview(PlayerCfg& p);
struct FpvCfg { bool enabled = false; int chams = 0; float col[4] = { 0.36f, 0.62f, 1.0f, 1.0f }; float off[3] = { 0, 0, 0 }; float fov = 62.0f; };
static FpvCfg FPV;
static void LoaderSkip(float t);
void Menu_DebugModel(int mat, float yaw, bool skel) { for (auto& p : PL) { p.enabled = true; p.model[0] = mat; p.glow = getenv("GLOW") != nullptr; p.modelCol[0].overlay = getenv("OVL") != nullptr; } g_mdlYaw = yaw; EP.skeleton = skel; if (getenv("ANIM")) g_animT = (float)atof(getenv("ANIM")); if (getenv("NOANIM")) EP.idleAnim = false; if (getenv("AVATAR")) EP.avatar = true; if (getenv("EFONT")) EP.font = atoi(getenv("EFONT")); if (getenv("NSZ")) EP.nameSize = (float)atof(getenv("NSZ")); if (getenv("XRAY")) g_plXray = true; if (getenv("BOXT")) EP.boxType = atoi(getenv("BOXT")); if (getenv("MODEL")) EP.model = atoi(getenv("MODEL")); if (getenv("ESPALL")) { EP.box = EP.name = EP.health = EP.armor = EP.weapon = EP.weaponIcon = EP.distance = EP.flags = EP.avatar = true; if (getenv("ESPALL2")) { EP.skeleton = EP.hitboxes = EP.readiness = EP.wBomb = EP.wDefuser = EP.wTaser = true; for (bool& b : EP.flag) b = true; } } if (const char* es = getenv("ESIDE")) for (int i = 0; i < 8 && es[i]; ++i) g_espSide[i] = es[i] - '0'; if (getenv("XMAT")) for (auto& p : PL) p.model[1] = atoi(getenv("XMAT")); if (getenv("FPV")) { FPV.enabled = true; FPV.chams = atoi(getenv("FPV")); } if (getenv("MCOL")) for (auto& p : PL) p.modelCol[0] = Col((ImU32)strtoul(getenv("MCOL"), nullptr, 16));  if (getenv("LOADT")) { Menu_RequireLoader(); Menu_StartLoader(getenv("LOADDBG") != nullptr); LoaderSkip((float)atof(getenv("LOADT"))); } }
// ---- death preview: ragdoll + Kill Effect (GhostHitEffect / CFXR2 Souls Escape, re-created from the Unity particle systems)
static bool  g_dead = false;          // players preview: ragdoll playing
static float g_deadT = 0.0f, g_deadAnim = -1.0f, g_deadA = 0.0f, g_spawnA = 1.0f, g_deadFix = -1.0f;
static const float DEAD_FADE0 = 2.9f, DEAD_END = 3.3f;
static bool g_killReq = false;
static void Menu_PreviewKill() { g_killReq = true; }
static ImTextureData* g_kfxTex[3] = { nullptr, nullptr, nullptr };   // ghost trail, inv spike, cloud blur
struct KPart { int sys; float p[3], v[3], age, life, size, rot, a0, force, seed; float hx[48], hy[48], ht[48]; int nh; };
struct KFx {
    bool on = false; float t = 0; ImVec2 org; float U = 30.0f; float col[3] = { 0.38f, 0.45f, 0.95f };
    unsigned rng = 1; float acc[6] = { 0, 0, 0, 0, 0, 0 }; int alive[6] = { 0, 0, 0, 0, 0, 0 };
    std::vector<KPart> ps;
} g_kfx;
static float KRand() { g_kfx.rng = g_kfx.rng * 1664525u + 1013904223u; return ((g_kfx.rng >> 8) & 0xFFFFFF) / 16777216.0f; }
static float KR(float a, float b) { return a + (b - a) * KRand(); }
static void KDirSphere(float* d) { float z = KR(-1, 1), a = KR(0, 6.2832f), r = sqrtf(ImMax(0.0f, 1 - z * z)); d[0] = r * cosf(a); d[1] = z; d[2] = r * sinf(a); }
static void KDirCone(float* d, float ang) { float c = cosf(ang * 3.14159f / 180.0f), z = KR(c, 1), a = KR(0, 6.2832f), r = sqrtf(ImMax(0.0f, 1 - z * z)); d[0] = r * cosf(a); d[1] = z; d[2] = r * sinf(a); }   // around +Y (up)
// cyan -> blue -> purple (CFXR2 gradient), tinted by the user colour
static void KGrad(float t, float* o)
{
    static const float T[5] = { 0, 0.25f, 0.5f, 0.70f, 0.85f };
    static const float K[5][3] = { { 0.65f, 0.97f, 1 }, { 0.65f, 0.97f, 1 }, { 0.51f, 0.55f, 1 }, { 0.75f, 0.21f, 1 }, { 0.75f, 0.21f, 1 } };
    t = ImClamp(t, 0.0f, 1.0f); int i = 0; while (i < 3 && t > T[i + 1]) ++i;
    float u = ImClamp((t - T[i]) / (T[i + 1] - T[i]), 0.0f, 1.0f);
    static const float REF[3] = { 0.51f, 0.55f, 1.0f };
    for (int q = 0; q < 3; ++q) o[q] = ImClamp((K[i][q] + (K[i + 1][q] - K[i][q]) * u) * (0.25f + 0.75f * g_kfx.col[q] / REF[q]), 0.0f, 1.0f);
}
static void KfxStart(ImVec2 org, float U, const float* col, unsigned seed)
{
    g_kfx = KFx(); g_kfx.on = true; g_kfx.org = org; g_kfx.U = U; for (int q = 0; q < 3; ++q) g_kfx.col[q] = col[q]; g_kfx.rng = seed;
}
static void KfxStep(float dt)
{
    KFx& F = g_kfx; if (!F.on) return;
    // emitters: 0/1 souls (cone up / omni), 2/3 smoke, 4/5 rays
    static const float DUR[6] = { 3, 3, 3, 3, 2.5f, 2.5f }, RATE[6] = { 10, 10, 25, 25, 25, 35 }, REND[6] = { 0, 0, 0.248f, 0.248f, 0.248f, 0.248f };
    static const int MAXN[6] = { 15, 15, 20, 20, 25, 25 };
    for (int e = 0; e < 6; ++e) {
        float nt = F.t / DUR[e]; if (nt >= 1.0f) continue;
        F.acc[e] += RATE[e] * (1.0f + (REND[e] - 1.0f) * nt) * dt;
        while (F.acc[e] >= 1.0f) {
            F.acc[e] -= 1.0f;
            if (F.alive[e] >= MAXN[e]) continue;
            KPart k = {}; k.sys = e; k.seed = KRand() * 100.0f; k.nh = 0;
            float d[3];
            if (e % 2 == 0) KDirCone(d, e == 0 ? 40.0f : (e == 2 ? 70.0f : 60.0f)); else KDirSphere(d);
            float r0 = e < 2 ? 0.2f : 0.0f; float sp[3]; KDirSphere(sp);
            for (int q = 0; q < 3; ++q) k.p[q] = sp[q] * r0 * (e == 0 && q == 1 ? 0.0f : 1.0f);
            if (e < 2) { k.life = KR(1.8f, 2.2f); for (int q = 0; q < 3; ++q) k.v[q] = d[q] * 4.0f; k.size = 0.5f; k.force = e == 1 ? KR(2, 4) : 0; float g = KRand(); k.a0 = g < 0.2f ? 1.0f : 1.0f - (g - 0.2f) / 0.8f * 0.98f; }
            else if (e < 4) { k.life = KR(0.8f, 1.0f); float s = KR(0.5f, 1.5f); for (int q = 0; q < 3; ++q) k.v[q] = d[q] * s; if (e == 2) { k.v[0] += KR(0, 1); k.v[1] += KR(0, 2); } k.size = KR(2, 4); k.rot = KR(0, 6.2832f); k.a0 = nt < 0.6f ? 1.0f : 1.0f - (nt - 0.6f) / 0.4f * 0.61f; k.force = nt; }
            else { k.life = 1.0f; for (int q = 0; q < 3; ++q) k.v[q] = d[q] * 0.1f; k.size = KR(0.4f, 0.8f); k.a0 = 0.35f; k.force = nt; }
            F.ps.push_back(k); F.alive[e]++;
        }
    }
    for (size_t i = 0; i < F.ps.size();) {
        KPart& k = F.ps[i];
        k.age += dt;
        if (k.age >= k.life) { F.alive[k.sys]--; F.ps[i] = F.ps.back(); F.ps.pop_back(); continue; }
        float nv[3] = { 0, 0, 0 };
        if (k.sys < 2) {   // separate-axis noise (strength 1, frequency 0.5, scroll 1)
            float fq = 0.5f, ts = F.t + k.seed;
            nv[0] = sinf(k.p[1] * fq * 2.1f + ts * 1.3f) * cosf(k.p[2] * fq * 1.7f + ts * 0.7f);
            nv[1] = sinf(k.p[2] * fq * 1.9f + ts * 1.1f + 1.3f) * cosf(k.p[0] * fq * 2.3f + ts * 0.9f);
            nv[2] = sinf(k.p[0] * fq * 1.8f + ts * 1.2f + 2.1f) * cosf(k.p[1] * fq * 2.0f + ts * 0.8f);
            k.v[1] += k.force * dt;
        }
        for (int q = 0; q < 3; ++q) k.p[q] += (k.v[q] + nv[q]) * dt;
        if (k.sys < 2) {   // trail points (lifetime = 0.5 * particle life * curve 1 -> 0.1)
            if (k.nh == 48) { memmove(k.hx, k.hx + 1, 47 * 4); memmove(k.hy, k.hy + 1, 47 * 4); memmove(k.ht, k.ht + 1, 47 * 4); k.nh = 47; }
            k.hx[k.nh] = k.p[0]; k.hy[k.nh] = k.p[1]; k.ht[k.nh] = k.age; k.nh++;
            float tl = 0.5f * k.life * (1.0f - 0.9f * k.age / k.life);
            int drop = 0; while (drop < k.nh - 2 && k.age - k.ht[drop] > tl) ++drop;
            if (drop) { memmove(k.hx, k.hx + drop, (k.nh - drop) * 4); memmove(k.hy, k.hy + drop, (k.nh - drop) * 4); memmove(k.ht, k.ht + drop, (k.nh - drop) * 4); k.nh -= drop; }
        }
        ++i;
    }
    F.t += dt;
    if (F.t > 3.0f && F.ps.empty()) F.on = false;
}
static void KfxDraw(const ImRect& clip)
{
    KFx& F = g_kfx; if (!F.on || !g_kfxTex[0]) return;
    DL->PushClipRect(clip.Min, clip.Max, true);
    auto S = [&](float x, float y) { return ImVec2(F.org.x + x * F.U, F.org.y - y * F.U); };
    auto col = [&](const float* c, float a) { return IM_COL32((int)(c[0] * 255), (int)(c[1] * 255), (int)(c[2] * 255), (int)(ImClamp(a, 0.0f, 1.0f) * 255)); };
    auto tri = [](float t) { return t < 0.5f ? t * 2.0f : (1.0f - t) * 2.0f; };   // colour module alpha 0 -> 1 -> 0
    // smoke (cloud blur), behind everything
    for (auto& k : F.ps) if (k.sys == 2 || k.sys == 3) {
        float t = k.age / k.life, c[3]; KGrad(k.force, c);
        float sz = k.size * (0.25f + 0.75f * t) * F.U * 0.5f; sz = ImMin(sz, clip.GetHeight() * 0.25f);
        float a = k.a0 * 0.5f * tri(t) * 0.55f;
        ImVec2 o = S(k.p[0], k.p[1]); float cs = cosf(k.rot) * sz, sn = sinf(k.rot) * sz;
        DL->AddImageQuad(g_kfxTex[2]->GetTexRef(), o + ImVec2(-cs + sn, -sn - cs), o + ImVec2(cs + sn, sn - cs), o + ImVec2(cs - sn, sn + cs), o + ImVec2(-cs - sn, -sn + cs),
                         ImVec2(0, 0), ImVec2(1, 0), ImVec2(1, 1), ImVec2(0, 1), col(c, a));
    }
    // rays (stretched inv spike): bright tip at the centre, fading outwards
    for (auto& k : F.ps) if (k.sys == 4 || k.sys == 5) {
        float t = k.age / k.life, c[3]; KGrad(k.force, c);
        float g = t;   // size over lifetime 0 -> 1
        float vx = k.v[0], vy = k.v[1], vl = sqrtf(vx * vx + vy * vy); if (vl < 1e-5f) continue;
        vx /= vl; vy /= vl;
        float len = ImMin(k.size * 10.0f * g * F.U * 0.5f, clip.GetHeight() * 0.5f), w = k.size * g * F.U * 0.5f;
        ImVec2 a0 = S(k.p[0], k.p[1]), dir(vx, -vy), nrm(-dir.y, dir.x);
        ImVec2 tip = a0, end = a0 + dir * len;
        float a = k.a0 * tri(t);
        DL->AddImageQuad(g_kfxTex[1]->GetTexRef(), end - nrm * w, tip - nrm * w * 0.02f, tip + nrm * w * 0.02f, end + nrm * w,
                         ImVec2(0, 0), ImVec2(1, 0), ImVec2(1, 1), ImVec2(0, 1), col(c, a));
    }
    // souls: ghost-trail texture stretched along each trail (face at the head)
    DL->PushTexture(g_kfxTex[0]->GetTexRef());
    for (auto& k : F.ps) if (k.sys < 2 && k.nh >= 2) {
        float t = k.age / k.life, c[3]; KGrad(t, c);
        float a = k.a0 * (t < 0.25f ? 1.0f : 1.0f - (t - 0.25f) / 0.75f);
        ImU32 cc = col(c, a);
        float tot = 0; for (int i = 1; i < k.nh; ++i) tot += sqrtf((k.hx[i] - k.hx[i - 1]) * (k.hx[i] - k.hx[i - 1]) + (k.hy[i] - k.hy[i - 1]) * (k.hy[i] - k.hy[i - 1]));
        if (tot < 1e-4f) continue;
        float w = k.size * F.U * 0.5f;
        int n = k.nh;
        DL->PrimReserve((n - 1) * 6, n * 2);
        unsigned base = DL->_VtxCurrentIdx; float acc = 0;
        for (int j = n - 1; j >= 0; --j) {   // head (newest) -> u = 0
            int jn = j == n - 1 ? j - 1 : j + 1, jp = j == n - 1 ? j : j;
            float dx = k.hx[j == n - 1 ? j : j] - k.hx[jn], dy = k.hy[j] - k.hy[jn]; if (j != n - 1) { dx = -dx; dy = -dy; }
            (void)jp;
            float l = sqrtf(dx * dx + dy * dy); if (l < 1e-6f) { dx = 0; dy = 1; l = 1; }
            ImVec2 nn(-(-dy / l), -(dx / l)); nn = ImVec2(dy / l, dx / l);   // screen-space normal (y flipped)
            float u = acc / tot; float ww = w * (1.0f - 0.5f * u);
            ImVec2 pp = S(k.hx[j], k.hy[j]);
            DL->PrimWriteVtx(pp + nn * ww, ImVec2(u, 0), cc);
            DL->PrimWriteVtx(pp - nn * ww, ImVec2(u, 1), cc);
            if (j > 0) acc += sqrtf((k.hx[j] - k.hx[j - 1]) * (k.hx[j] - k.hx[j - 1]) + (k.hy[j] - k.hy[j - 1]) * (k.hy[j] - k.hy[j - 1]));
        }
        for (int i = 0; i < n - 1; ++i) {
            ImDrawIdx a0 = (ImDrawIdx)(base + i * 2), b0 = (ImDrawIdx)(a0 + 1), a1 = (ImDrawIdx)(a0 + 2), b1 = (ImDrawIdx)(a0 + 3);
            DL->PrimWriteIdx(a0); DL->PrimWriteIdx(b0); DL->PrimWriteIdx(b1); DL->PrimWriteIdx(a0); DL->PrimWriteIdx(b1); DL->PrimWriteIdx(a1);
        }
    }
    DL->PopTexture();
    DL->PopClipRect();
}
static void KfxLoadTex()
{
    const unsigned char* src[3] = { KFX_GHOST, KFX_SPIKE, KFX_CLOUD }; const int n[3] = { (int)sizeof(KFX_GHOST), (int)sizeof(KFX_SPIKE), (int)sizeof(KFX_CLOUD) };
    for (int i = 0; i < 3; ++i) {
        int w, h; unsigned char* px = M3D_DecodeImage(src[i], n[i], &w, &h, 1); if (!px) continue;
        g_kfxTex[i] = IM_NEW(ImTextureData)(); g_kfxTex[i]->Create(ImTextureFormat_RGBA32, w, h);
        unsigned char* d = (unsigned char*)g_kfxTex[i]->Pixels;
        for (int j = 0; j < w * h; ++j) { d[j * 4] = d[j * 4 + 1] = d[j * 4 + 2] = 255; d[j * 4 + 3] = px[j]; }
        M3D_FreeImage(px); ImGui::RegisterUserTexture(g_kfxTex[i]);
    }
}
static void DrawEspPreview(PlayerCfg& p)
{
    ImRect mr = R(530, 110, 758, 548);
    // drag to rotate (with inertia)
    ImGuiID rid = Id("mdl_rot");
    bool hov = Hover(mr, rid);
    static ImVec2 lastM;
    ImGuiID did = Id("esp_drag");
    int hitEl = -1;
    if (p.enabled) for (int i = 0; i < 8; ++i) if (g_espHitOk[i] && Hover(g_espHit[i], did) && IN.click) hitEl = i;   // elements may sit outside the preview rect
    static ImVec2 pressM; static bool movedFar = false;
    if (hitEl >= 0) { g_espDrag = hitEl; g_active = did; g_espGrab = IN.m - (g_espHit[hitEl].Min + ImVec2(3, 3)); pressM = IN.m; movedFar = false; }
    else if (hov && IN.click) { g_active = rid; lastM = IN.m; g_mdlVel = 0.0f; }
    if (g_active == did && ImLengthSqr(IN.m - pressM) > 9.0f) movedFar = true;
    if (p.enabled && IN.rclick && g_active == 0) {   // right click on an element: its colour picker
        static const int EL_COL[8] = { 1, 2, 3, 4, 5, 6, 7, 1 };   // name, hp, armor, weapon, icon, distance, flags, avatar -> EspCols
        int ri = -1;
        for (int i = 0; i < 8; ++i) if (g_espHitOk[i] && Hover(g_espHit[i], did)) ri = i;
        if (ri >= 0) OpenEspPicker(EL_COL[ri], g_espHit[ri], false);
        else if (EP.box && Hover(ImRect(g_espBox.Min - ImVec2(4, 4), g_espBox.Max + ImVec2(4, 4)), did) && !ImRect(g_espBox.Min + ImVec2(4, 4), g_espBox.Max - ImVec2(4, 4)).Contains(IN.m))
            OpenEspPicker(0, ImRect(IN.m - ImVec2(4, 4), IN.m + ImVec2(4, 4)), false);   // box outline
    }
    if (g_active == did && !IN.down) {   // drop: renumber orders
        g_active = 0; g_espDrag = -1;
        int idx[8]; for (int i = 0; i < 8; ++i) idx[i] = i;
        std::sort(idx, idx + 8, [](int a, int b) { return g_espOrd[a] < g_espOrd[b]; });
        for (int q = 0; q < 8; ++q) g_espOrd[idx[q]] = (float)q;
    }
    if (g_active != did) g_espDrag = -1;
    if (g_espDrag >= 0 && g_espHitOk[g_espDrag]) {   // magnet: nearest box side + slot from the cursor
        ImRect bx = g_espBox; ImVec2 m = IN.m;
        auto segD = [](ImVec2 p, ImVec2 a, ImVec2 b) { ImVec2 ab = b - a; float t = ImClamp(ImDot(p - a, ab) / ImMax(1e-3f, ImDot(ab, ab)), 0.0f, 1.0f); return ImLengthSqr(p - (a + ab * t)); };
        float d[4] = { segD(m, bx.Min, ImVec2(bx.Max.x, bx.Min.y)), segD(m, ImVec2(bx.Min.x, bx.Max.y), bx.Max), segD(m, bx.Min, ImVec2(bx.Min.x, bx.Max.y)), segD(m, ImVec2(bx.Max.x, bx.Min.y), bx.Max) };
        int sd = 0; for (int k = 1; k < 4; ++k) if (d[k] < d[sd]) sd = k;
        int dr = g_espDrag; bool bar = dr == 1 || dr == 2;
        ImVec2 gc = m - g_espGrab + g_espHit[dr].GetSize() * 0.5f - ImVec2(3, 3);
        if (dr == 7) {   // avatar: dropping it onto the name glues it to the start of the text
            ImRect nr = g_espHit[0]; nr.Expand(6.0f);
            g_avAttach = g_espHitOk[0] && nr.Contains(gc);
        }
        if (!(dr == 7 && g_avAttach)) {
        g_espSide[dr] = sd;
        auto key = [&](ImVec2 c, bool isb) { return sd == 0 ? bx.Min.y - c.y : sd == 1 ? c.y - bx.Max.y : (isb ? (sd == 2 ? bx.Min.x - c.x : c.x - bx.Max.x) : c.y); };
        float mk = key(m - g_espGrab + g_espHit[dr].GetSize() * 0.5f - ImVec2(3, 3), bar);
        int others[8], n = 0;
        for (int i = 0; i < 8; ++i) if (i != dr && g_espSide[i] == sd) others[n++] = i;
        std::sort(others, others + n, [](int a, int b) { return g_espOrd[a] < g_espOrd[b]; });
        int k = 0;
        for (int q = 0; q < n; ++q) { int o = others[q]; bool ob = o == 1 || o == 2; if (sd >= 2 && ob != bar) continue; if (g_espHitOk[o] && key(g_espHit[o].GetCenter(), ob) < mk) k = q + 1; }
        for (int q = 0; q < n; ++q) g_espOrd[others[q]] = (float)q;
        g_espOrd[dr] = k - 0.5f;
        }
    }
    if (g_active == rid) {
        if (!IN.down) g_active = 0;
        else { float dx = IN.m.x - lastM.x; lastM = IN.m; g_mdlYaw += dx * 0.013f; g_mdlVel = ImLerp(g_mdlVel, dx * 0.013f / g_dt, 0.5f); }
    } else if (fabsf(g_mdlVel) > 0.01f) { g_mdlYaw += g_mdlVel * g_dt; g_mdlVel *= expf(-5.0f * g_dt); }
    else g_mdlVel = 0.0f;
    M3DSettings want;
    want.yaw = g_mdlYaw; want.pitch = 0.0f; want.model = (EP.model == 1 && g_plGroup == 1) ? 2 : EP.model;   // Teammates -> T agent
    const int mrow = g_plXray ? 1 : 0;
    want.mat = p.enabled ? ImClamp(p.model[mrow], 0, (int)M3D_COUNT - 1) : 0;
    ColF(want.col, p.modelCol[mrow]); want.overlay = p.modelCol[mrow].overlay;
    want.halo = p.enabled && p.glow; ColF(want.haloCol, p.glowCol);
    want.bright = 1.0f;
    bool animated = want.mat == M3D_WATERFLOW || want.mat >= M3D_GALAXY;
    want.time = animated ? (float)fmod(ImGui::GetTime(), 1000.0) : 0.0f;
    if (getenv("GTIME")) want.time = (float)atof(getenv("GTIME"));
    if (getenv("MCOL")) { unsigned v = (unsigned)strtoul(getenv("MCOL"), nullptr, 16); want.col[0] = ((v >> 16) & 255) / 255.0f; want.col[1] = ((v >> 8) & 255) / 255.0f; want.col[2] = (v & 255) / 255.0f; }
    if (EP.idleAnim) { want.anim = g_animT >= 0 ? g_animT : (float)fmod(ImGui::GetTime(), 3600.0); animated = true; }
    // ---- death: ragdoll with the "Ragdolls" chams + Kill Effect, then respawn
    static bool dbgInit = false; static float dbgT = -1.0f;
    if (!dbgInit) { dbgInit = true; if (getenv("DEATHT")) { dbgT = (float)atof(getenv("DEATHT")); if (getenv("KFX")) for (auto& q : PL) q.soul = true; } }
    const float kk = mr.GetWidth() / MDL_W;
    auto startFx = [&](const M3DSettings& alive) {
        float hp[3]; M3D_HeadPoint(alive, hp);
        float sx, sy; M3D_Project(hp[0], hp[1] - 0.42f, hp[2], MDL_W, MDL_H, alive, &sx, &sy);
        float c[4]; ColF(c, p.soulCol);
        KfxStart(ImVec2(mr.Min.x + sx * kk, mr.Min.y + sy * kk), 0.5f * MDL_H * kk * 0.14f, c, 12345u + (unsigned)(ImGui::GetTime() * 1000.0));
    };
    if (dbgT >= 0 && !g_dead) { g_killReq = true; }
    if (g_killReq) {
        g_killReq = false;
        if (!g_dead) {
            g_dead = true; g_deadT = 0.0f; g_deadAnim = want.anim; g_deadA = g_mdlYaw + 0.35f;
            if (p.soul) startFx(want); else g_kfx.on = false;
            if (dbgT >= 0) { g_deadT = dbgT; if (p.soul) { for (float t = 0; t < dbgT; t += 1.0f / 60.0f) KfxStep(1.0f / 60.0f); } }
        }
    }
    float imgA = g_spawnA;
    if (g_dead) {
        want.rag = g_deadT; want.ragA = g_deadA; want.anim = g_deadAnim;
        { float u = ImClamp(g_deadT / 1.1f, 0.0f, 1.0f); want.pitch = 0.42f * u * u * (3 - 2 * u); }
        want.mat = p.enabled ? ImClamp(p.model[4], 0, (int)M3D_COUNT - 1) : 0;
        ColF(want.col, p.modelCol[4]); want.overlay = p.modelCol[4].overlay; want.halo = false;
        want.time = (float)fmod(ImGui::GetTime(), 1000.0); if (getenv("GTIME")) want.time = (float)atof(getenv("GTIME"));
        animated = true;
        float u = ImClamp((g_deadT - DEAD_FADE0) / (DEAD_END - DEAD_FADE0), 0.0f, 1.0f); imgA = 1.0f - u * u * (3 - 2 * u);
        for (int i = 0; i < 8; ++i) g_espHitOk[i] = false;
    }
    MdlUpdate(want, animated);
    if (dbgT < 0) {
        if (g_dead) { g_deadT += g_dt; if (g_deadT >= DEAD_END) { g_dead = false; g_spawnA = 0.0f; } }
        else g_spawnA = ImMin(1.0f, g_spawnA + g_dt / 0.3f);
        KfxStep(g_dt);
    }
    if (!g_mdlHave) return;
    DL->AddImage(g_mdlTex->GetTexRef(), mr.Min, mr.Max, ImVec2(0, 0), ImVec2(1, 1), C(0xFFFFFF, imgA));
    KfxDraw(mr);
    if (!p.enabled || !g_mdlShownO.valid || g_dead || g_mdlShownS.rag >= 0) return;
    // ---- ESP overlay (configured in the Debug window)
    { bool any = false; for (bool b : EP.flag) any |= b; EP.flags = any; }
    EspPrevCfg E = EP;
    if (g_plXray) for (int i = 0; i < 10; ++i) *EspCols(E, i) = EP.inv[i];
    for (int i = 0; i < 10; ++i) if (i != 2) EspCols(E, i)->grad = false;   // gradients: health bar only
    const float k = mr.GetWidth() / MDL_W;
    auto toL = [&](float bx, float by) { return ImVec2(mr.Min.x + bx * k, mr.Min.y + by * k); };
    ImVec2 b0 = toL(g_mdlShownO.x0, g_mdlShownO.y0), b1 = toL(g_mdlShownO.x1, g_mdlShownO.y1);
    b0 = ImFloor(b0 - ImVec2(4, 4)) + ImVec2(0.5f, 0.5f); b1 = ImFloor(b1 + ImVec2(4, 3)) + ImVec2(0.5f, 0.5f);
    ImU32 blk = IM_COL32(0, 0, 0, 200);
    // recolour vertices [v0, end) with an EC along y (or x); vertex alpha is kept as coverage
    auto grad = [&](int v0, const EC& c, float p0, float p1, bool horiz) {
        ImDrawVert* vv = DL->VtxBuffer.Data; float inv = 1.0f / ImMax(1.0f, p1 - p0);
        for (int i = v0; i < DL->VtxBuffer.Size; ++i) {
            float t = c.grad ? ImClamp(((horiz ? vv[i].pos.x : vv[i].pos.y) - p0) * inv, 0.0f, 1.0f) : 0.0f;
            float cov = ((vv[i].col >> IM_COL32_A_SHIFT) & 0xFF) / 255.0f;
            float r = ImLerp(c.a[0], c.b[0], t), g = ImLerp(c.a[1], c.b[1], t), b = ImLerp(c.a[2], c.b[2], t), al = ImLerp(c.a[3], c.b[3], t) * cov;
            vv[i].col = IM_COL32((int)(r * 255 + 0.5f), (int)(g * 255 + 0.5f), (int)(b * 255 + 0.5f), (int)(ImClamp(al, 0.0f, 1.0f) * 255 + 0.5f));
        }
    };
    auto gtext = [&](ImFont* f, float sz, ImVec2 pos, const EC& c, const char* t) {
        ImU32 sh = IM_COL32(0, 0, 0, (int)(ImMax(c.a[3], c.b[3]) * 215));
        for (int q = 0; q < 4; ++q) DL->AddText(f, sz, pos + ImVec2(q == 0 ? -1.0f : (q == 1 ? 1.0f : 0.0f), q == 2 ? -1.0f : (q == 3 ? 1.0f : 0.0f)), sh, t);
        int v0 = DL->VtxBuffer.Size;
        DL->AddText(f, sz, pos, IM_COL32_WHITE, t);
        ImVec2 ts = f->CalcTextSizeA(sz, FLT_MAX, 0, t);
        grad(v0, c, pos.y + ts.y * 0.2f, pos.y + ts.y * 0.85f, false);
    };
    if (E.hitboxes) {   // capsules along the bones + head sphere
        static float hbn[32][6]; M3D_Bones(g_mdlShownS, hbn);
        ImU32 fillC = IM_COL32(255, 92, 92, 52), lineC = IM_COL32(255, 110, 110, 200);
        for (int i = 0; i < M3D_BoneCount(); ++i) {
            if (i == 3) continue;   // neck -> head: covered by the head sphere
            const float* bn = hbn[i]; float x0, y0, x1, y1;
            M3D_Project(bn[0], bn[1], bn[2], MDL_W, MDL_H, g_mdlShownS, &x0, &y0); M3D_Project(bn[3], bn[4], bn[5], MDL_W, MDL_H, g_mdlShownS, &x1, &y1);
            ImVec2 a = toL(x0, y0), b = toL(x1, y1);
            float rr = i < 3 ? 6.5f : (i >= 10 && (i % 4 == 0 || i % 4 == 1) ? 4.5f : 3.5f);
            ImVec2 d = b - a; float L = sqrtf(ImLengthSqr(d)); if (L < 0.5f) continue;
            ImVec2 n(-d.y / L * rr, d.x / L * rr);
            DL->AddLine(a, b, fillC, rr * 2.0f);
            DL->AddLine(a + n, b + n, lineC, 1.0f); DL->AddLine(a - n, b - n, lineC, 1.0f);
            DL->AddCircle(a, rr, lineC, 16, 1.0f); DL->AddCircle(b, rr, lineC, 16, 1.0f);
        }
        float hp[3]; M3D_HeadPoint(g_mdlShownS, hp); float hx, hy; M3D_Project(hp[0], hp[1], hp[2], MDL_W, MDL_H, g_mdlShownS, &hx, &hy);
        ImVec2 hc = toL(hx, hy - 6.0f);
        DL->AddCircleFilled(hc, 8.5f, fillC, 24); DL->AddCircle(hc, 8.5f, lineC, 24, 1.0f);
    }
    if (E.skeleton) {
        int v0 = DL->VtxBuffer.Size;
        static float bones[32][6]; M3D_Bones(g_mdlShownS, bones);
        for (int i = 0; i < M3D_BoneCount(); ++i) {
            const float* bn = bones[i]; float x0, y0, x1, y1;
            M3D_Project(bn[0], bn[1], bn[2], MDL_W, MDL_H, g_mdlShownS, &x0, &y0); M3D_Project(bn[3], bn[4], bn[5], MDL_W, MDL_H, g_mdlShownS, &x1, &y1);
            DL->AddLine(toL(x0, y0), toL(x1, y1), IM_COL32_WHITE, 1.3f);
        }
        grad(v0, E.skelCol, b0.y, b1.y, false);
    }
    if (E.headDot) {
        float hp[3]; M3D_HeadPoint(g_mdlShownS, hp); float hx, hy; M3D_Project(hp[0], hp[1], hp[2], MDL_W, MDL_H, g_mdlShownS, &hx, &hy);
        ImVec2 hc = toL(hx, hy);
        DL->AddCircleFilled(hc, 3.2f, blk, 16);
        int v0 = DL->VtxBuffer.Size; DL->AddCircleFilled(hc, 2.3f, IM_COL32_WHITE, 16); grad(v0, E.headCol, hc.y - 2.3f, hc.y + 2.3f, false);
    }
    if (E.box && E.boxType == 1) {   // corner box
        float lw = floorf((b1.x - b0.x) * 0.28f), lh = floorf((b1.y - b0.y) * 0.16f);
        auto corners = [&](ImU32 c, float o) {   // o: outline offset (outer +1 / inner -1 / 0)
            ImVec2 p[4] = { b0, ImVec2(b1.x, b0.y), b1, ImVec2(b0.x, b1.y) };
            float sx[4] = { 1, -1, -1, 1 }, sy[4] = { 1, 1, -1, -1 };
            for (int q = 0; q < 4; ++q) {
                ImVec2 c0 = p[q] - ImVec2(sx[q] * o, sy[q] * o);
                DL->AddLine(c0, c0 + ImVec2(sx[q] * (lw + o), 0), c, 1.0f);
                DL->AddLine(c0, c0 + ImVec2(0, sy[q] * (lh + o)), c, 1.0f);
            }
        };
        corners(blk, 1.0f); corners(blk, -1.0f);
        int v0 = DL->VtxBuffer.Size; corners(IM_COL32_WHITE, 0.0f); grad(v0, E.boxCol, b0.y, b1.y, false);
    } else if (E.box && E.boxType == 2) {   // 3D box around the player (rotates with the model)
        float hp3[3]; M3D_HeadPoint(g_mdlShownS, hp3);
        const float hw = 0.28f, top = hp3[1] + 0.16f;
        float cv[8][3] = { { -hw, 0, -hw }, { hw, 0, -hw }, { hw, 0, hw }, { -hw, 0, hw }, { -hw, top, -hw }, { hw, top, -hw }, { hw, top, hw }, { -hw, top, hw } };
        ImVec2 sp[8];
        for (int q = 0; q < 8; ++q) { float x, y; M3D_Project(cv[q][0], cv[q][1], cv[q][2], MDL_W, MDL_H, g_mdlShownS, &x, &y); sp[q] = toL(x, y); }
        static const int ed[12][2] = { { 0, 1 }, { 1, 2 }, { 2, 3 }, { 3, 0 }, { 4, 5 }, { 5, 6 }, { 6, 7 }, { 7, 4 }, { 0, 4 }, { 1, 5 }, { 2, 6 }, { 3, 7 } };
        float y0 = 1e9f, y1 = -1e9f; for (auto& v : sp) { y0 = ImMin(y0, v.y); y1 = ImMax(y1, v.y); }
        for (auto& e : ed) DL->AddLine(sp[e[0]], sp[e[1]], IM_COL32(0, 0, 0, 120), 3.0f);
        int v0 = DL->VtxBuffer.Size; for (auto& e : ed) DL->AddLine(sp[e[0]], sp[e[1]], IM_COL32_WHITE, 1.0f); grad(v0, E.boxCol, y0, y1, false);
    } else if (E.box) {
        DL->AddRect(b0 - ImVec2(1, 1), b1 + ImVec2(1, 1), blk, 0.0f, 0, 1.0f);
        DL->AddRect(b0 + ImVec2(1, 1), b1 - ImVec2(1, 1), blk, 0.0f, 0, 1.0f);
        int v0 = DL->VtxBuffer.Size; DL->AddRect(b0, b1, IM_COL32_WHITE, 0.0f, 0, 1.0f); grad(v0, E.boxCol, b0.y, b1.y, false);
    }
    g_espBox = ImRect(b0, b1);
    float cx = (b0.x + b1.x) * 0.5f;
    // ---- draggable elements: each one sits on a side of the box (0 top, 1 bottom, 2 left, 3 right) and snaps to the nearest side while dragged
    enum { EL_NAME, EL_HP, EL_AP, EL_WPN, EL_ICON, EL_DIST, EL_FLAGS, EL_AV, EL_N };
    const bool avOn = E.avatar && g_avTex != nullptr, avIn = avOn && g_avAttach && E.name;
    const bool wIco = E.weaponIcon && g_wiTex != nullptr; const int nExtra = (int)E.wBomb + (int)E.wDefuser + (int)E.wTaser;
    const bool en[EL_N] = { E.name, E.health, E.armor, E.weapon, wIco || nExtra > 0 || E.readiness, E.distance, E.flags, avOn && !avIn };
    char nm[32]; snprintf(nm, sizeof nm, "%s", "t.me/Anesthysia");
    if (E.nameCase == 1) for (char* c = nm; *c; ++c) *c = (char)toupper((unsigned char)*c);
    else if (E.nameCase == 0) nm[0] = nm[0];
    else for (char* c = nm; *c; ++c) *c = (char)tolower((unsigned char)*c);
    ImFont* nf = FontBy(E.nameFont, F_MED); const float nsz = SizeBy(E.nameFont, E.nameSize);
    int wi = ImClamp(E.weaponIdx, 0, WI_N - 1);
    char wname[32]; snprintf(wname, sizeof wname, "%s", WI_RECTS[wi].name); for (char* c = wname; *c; ++c) *c = (char)tolower((unsigned char)*c);
    const char* fl[15]; int nfl = 0; for (int i = 0; i < 15; ++i) if (E.flag[i]) fl[nfl++] = FLAG_TEXT[i];
    const float flh = E.font == 2 ? 9.0f : 11.0f;
    auto isBar = [](int i) { return i == EL_HP || i == EL_AP; };
    auto measure = [&](int i, int side) -> ImVec2 {
        bool vert = side >= 2;
        switch (i) {
        case EL_HP: case EL_AP: return vert ? ImVec2(3, b1.y - b0.y + 1) : ImVec2(b1.x - b0.x + 1, 3);
        case EL_NAME: { ImVec2 ts = nf->CalcTextSizeA(nsz, FLT_MAX, 0, nm); if (avIn) ts.x += floorf(ImMax(12.0f, ts.y)) + 3.0f; return ts; }
        case EL_AV: return ImVec2(16, 16);
        case EL_WPN: return EF(F_MED)->CalcTextSizeA(ES(13.0f), FLT_MAX, 0, wname);
        case EL_ICON: {
            const WiRect& q = WI_RECTS[wi];
            float w = wIco ? floorf(q.w * 13.0f / q.h) : 0.0f;
            for (int k = 0; k < nExtra; ++k) w += (w > 0 ? 4.0f : 0.0f) + 12.0f;
            float h = w > 0 ? 13.0f : 0.0f;
            if (E.readiness) { w = ImMax(w, 30.0f); h += (h > 0 ? 4.0f : 0.0f) + 2.0f; }
            return ImVec2(w, h);
        }
        case EL_DIST: return EF(F_PIX)->CalcTextSizeA(ES(13.0f), FLT_MAX, 0, "12m");
        default: { float w = 0; for (int q = 0; q < nfl; ++q) w = ImMax(w, EF(F_PIX)->CalcTextSizeA(ES(13.0f), FLT_MAX, 0, fl[q]).x); return ImVec2(w, flh * ImMax(0, nfl - 1) + EF(F_PIX)->CalcTextSizeA(ES(13.0f), FLT_MAX, 0, "H").y); }
        }
    };
    // layout every enabled element
    static ImRect lr[EL_N]; static bool lv[EL_N];
    ImRect tr[EL_N];
    {
        int idx[EL_N]; for (int i = 0; i < EL_N; ++i) idx[i] = i;
        std::sort(idx, idx + EL_N, [&](int a, int b) { return g_espOrd[a] < g_espOrd[b]; });
        float ct = b0.y, cb = b1.y, cl = b0.x, crt = b1.x;            // outward cursors (bars)
        for (int q = 0; q < EL_N; ++q) {
            int i = idx[q]; if (!en[i]) continue;
            int sd = g_espSide[i]; ImVec2 sz = measure(i, sd);
            float pb = isBar(i) ? 3.5f : (i == EL_ICON ? 2.0f : (i == EL_NAME || i == EL_AV ? 2.0f : 0.0f)), pa = isBar(i) ? 2.5f : (i == EL_ICON || i == EL_AV ? 2.0f : 0.0f);
            if (sd == 0)      { float y1 = floorf(ct - pb) + (isBar(i) ? 0.5f : 0.0f); tr[i] = ImRect(ImVec2(isBar(i) ? b0.x - 0.5f : floorf(cx - sz.x * 0.5f), y1 - sz.y), ImVec2((isBar(i) ? b0.x - 0.5f : floorf(cx - sz.x * 0.5f)) + sz.x, y1)); ct = tr[i].Min.y - pa; }
            else if (sd == 1) { float y0 = floorf(cb + pb) + (isBar(i) ? 0.5f : 0.0f); float x0 = isBar(i) ? b0.x - 0.5f : floorf(cx - sz.x * 0.5f); tr[i] = ImRect(ImVec2(x0, y0), ImVec2(x0 + sz.x, y0 + sz.y)); cb = tr[i].Max.y + pa; }
            else if (isBar(i) && sd == 2) { float x1 = cl - pb; tr[i] = ImRect(ImVec2(x1 - sz.x, b0.y - 0.5f), ImVec2(x1, b0.y - 0.5f + sz.y)); cl = tr[i].Min.x - pa; }
            else if (isBar(i))            { float x0 = crt + pb; tr[i] = ImRect(ImVec2(x0, b0.y - 0.5f), ImVec2(x0 + sz.x, b0.y - 0.5f + sz.y)); crt = tr[i].Max.x + pa; }
        }
        float tl = b0.y - 1.0f, trr = b0.y - 1.0f;                     // text columns on the sides, below each other
        for (int q = 0; q < EL_N; ++q) {
            int i = idx[q]; if (!en[i] || isBar(i) || g_espSide[i] < 2) continue;
            ImVec2 sz = measure(i, g_espSide[i]);
            if (g_espSide[i] == 2) { float x1 = floorf(cl - 2.0f); tr[i] = ImRect(ImVec2(x1 - sz.x, tl), ImVec2(x1, tl + sz.y)); tl += sz.y + (i == EL_ICON ? 3.0f : 1.0f); }
            else                   { float x0 = floorf(crt + 2.0f); tr[i] = ImRect(ImVec2(x0, trr), ImVec2(x0 + sz.x, trr + sz.y)); trr += sz.y + (i == EL_ICON ? 3.0f : 1.0f); }
        }
    }
    // smooth "magnet" movement when an element changes side / slot
    static ImVec2 off[EL_N], prevT[EL_N]; static bool prevOk[EL_N];
    for (int i = 0; i < EL_N; ++i) {
        if (!en[i]) { prevOk[i] = false; lv[i] = false; continue; }
        ImVec2 rel = tr[i].Min - b0;   // relative to the box: moving the menu / rotating never triggers the slide
        if (prevOk[i] && ImLengthSqr(rel - prevT[i]) > 36.0f) off[i] += prevT[i] - rel;
        prevT[i] = rel; prevOk[i] = true;
        off[i] *= expf(-16.0f * g_dt); if (ImLengthSqr(off[i]) < 0.04f) off[i] = ImVec2(0, 0);
        tr[i].Translate(ImFloor(off[i] + ImVec2(0.5f, 0.5f)) - ImVec2(0.0f, 0.0f));
        lr[i] = tr[i]; lv[i] = true;
    }
    if (avIn && lv[EL_NAME]) {   // inline avatar: its own grab area at the start of the name
        float av = floorf(ImMax(12.0f, lr[EL_NAME].GetHeight()));
        ImVec2 a0(lr[EL_NAME].Min.x, floorf(lr[EL_NAME].Min.y + (lr[EL_NAME].GetHeight() - av) * 0.5f));
        lr[EL_AV] = ImRect(a0, a0 + ImVec2(av, av)); lv[EL_AV] = true; prevOk[EL_AV] = false;
    }
    for (int i = 0; i < EL_N; ++i) { g_espHit[i] = lv[i] ? ImRect(lr[i].Min - ImVec2(3, 3), lr[i].Max + ImVec2(3, 3)) : ImRect(); g_espHitOk[i] = lv[i]; }
    // drag feedback: the target side and a ghost under the cursor, both grey
    if (g_espDrag >= 0) {
        int ts = g_espSide[g_espDrag];
        ImVec2 e0[4] = { b0, ImVec2(b0.x, b1.y), b0, ImVec2(b1.x, b0.y) }, e1[4] = { ImVec2(b1.x, b0.y), b1, ImVec2(b0.x, b1.y), b1 };
        if (!(g_espDrag == EL_AV && avIn)) { DL->AddLine(e0[ts], e1[ts], C(0xA0A3AB, 0.22f), 6.0f); DL->AddLine(e0[ts], e1[ts], C(0xC4C6CC, 0.8f), 1.5f); }
        ImVec2 sz = lr[g_espDrag].GetSize(), gm = IN.m - g_espGrab;
        bool gb = g_espDrag == 1 || g_espDrag == 2;
        DL->AddRectFilled(gm - ImVec2(2, 2), gm + sz + ImVec2(2, 2), C(0x9A9DA5, 0.18f), gb ? 0.0f : 3.0f);
    }
    auto sideOf = [&](int i) { return g_espSide[i]; };
    // ---- draw
    if (en[EL_NAME]) {
        float tx = lr[EL_NAME].Min.x;
        if (avIn) tx = lr[EL_AV].Max.x + 3.0f;
        gtext(nf, nsz, ImVec2(tx, lr[EL_NAME].Min.y), E.nameCol, nm);
    }
    if (en[EL_AV] || avIn) {
        ImVec2 a0 = lr[EL_AV].Min, a1 = lr[EL_AV].Max;
        DL->AddRectFilled(a0 - ImVec2(1, 1), a1 + ImVec2(1, 1), IM_COL32(0, 0, 0, 200), 2.0f);
        DL->AddImageRounded(g_avTex->GetTexRef(), a0, a1, ImVec2(0, 0), ImVec2(1, 1), IM_COL32_WHITE, 1.5f);
    }
    if (en[EL_HP]) {   // animated (hits drop fast with a fading trail, heals rise slowly)
        static float hpCur = 100.0f, hpLag = 100.0f, hpTarget = 100.0f, hpTimer = 1.0f;
        int maxHp = ImClamp(E.hp, 1, 100);
        if (E.hpAnim) {
            hpTimer -= g_dt;
            if (hpTimer <= 0.0f) {
                if (hpTarget > 28.0f && (rand() % 3) != 0) { hpTarget = ImMax(4.0f, hpTarget - (float)(14 + rand() % 30)); hpTimer = 0.9f + (rand() % 60) / 100.0f; }
                else { hpTarget = (float)maxHp; hpTimer = 2.2f; }
            }
            hpTarget = ImMin(hpTarget, (float)maxHp);
            float sp = hpTarget < hpCur ? 14.0f : 2.2f;
            hpCur += (hpTarget - hpCur) * (1.0f - expf(-sp * g_dt));
            hpLag = hpLag < hpCur ? hpCur : hpLag + (hpCur - hpLag) * (1.0f - expf(-3.0f * g_dt));
        } else { hpCur = hpLag = hpTarget = (float)maxHp; }
        float hp = ImClamp(hpCur, 0.0f, 100.0f) / 100.0f, lag = ImClamp(hpLag, 0.0f, 100.0f) / 100.0f;
        ImRect hb = lr[EL_HP]; bool vert = sideOf(EL_HP) >= 2;
        DL->AddRectFilled(hb.Min - ImVec2(1, 1), hb.Max + ImVec2(1, 1), blk);
        int hv = (int)(hpCur + 0.5f); char t[8]; snprintf(t, sizeof t, "%d", hv);
        ImVec2 nts = EF(F_PIX)->CalcTextSizeA(ES(13.0f), FLT_MAX, 0, t);
        if (vert) {
            float top = hb.Max.y - hb.GetHeight() * hp, ltop = hb.Max.y - hb.GetHeight() * lag;
            if (ltop < top - 0.5f) DL->AddRectFilled(ImVec2(hb.Min.x, ltop), ImVec2(hb.Max.x, top), IM_COL32(255, 255, 255, 120));
            int v0 = DL->VtxBuffer.Size; DL->AddRectFilled(ImVec2(hb.Min.x, top), hb.Max, IM_COL32_WHITE); grad(v0, E.healthCol, hb.Min.y, hb.Max.y, false);
            if (hv < 100) OutlinedText(EF(F_PIX), ES(13.0f), ImVec2(floorf(hb.GetCenter().x - nts.x * 0.5f), floorf(top - nts.y * 0.5f)), IM_COL32(255, 255, 255, 235), t);
        } else {
            float rx = hb.Min.x + hb.GetWidth() * hp, lx = hb.Min.x + hb.GetWidth() * lag;
            if (lx > rx + 0.5f) DL->AddRectFilled(ImVec2(rx, hb.Min.y), ImVec2(lx, hb.Max.y), IM_COL32(255, 255, 255, 120));
            int v0 = DL->VtxBuffer.Size; DL->AddRectFilled(hb.Min, ImVec2(rx, hb.Max.y), IM_COL32_WHITE); grad(v0, E.healthCol, hb.Min.x, hb.Max.x, true);
            if (hv < 100) OutlinedText(EF(F_PIX), ES(13.0f), ImVec2(floorf(rx - nts.x * 0.5f), floorf(hb.GetCenter().y - nts.y * 0.5f)), IM_COL32(255, 255, 255, 235), t);
        }
    }
    if (en[EL_AP]) {
        float ap = ImClamp(E.ap, 0, 100) / 100.0f;
        ImRect ab = lr[EL_AP];
        DL->AddRectFilled(ab.Min - ImVec2(1, 1), ab.Max + ImVec2(1, 1), blk);
        int v0 = DL->VtxBuffer.Size;
        if (sideOf(EL_AP) >= 2) { DL->AddRectFilled(ImVec2(ab.Min.x, ab.Max.y - ab.GetHeight() * ap), ab.Max, IM_COL32_WHITE); grad(v0, E.armorCol, ab.Min.y, ab.Max.y, false); }
        else { DL->AddRectFilled(ab.Min, ImVec2(ab.Min.x + ab.GetWidth() * ap, ab.Max.y), IM_COL32_WHITE); grad(v0, E.armorCol, ab.Min.x, ab.Max.x, true); }
    }
    if (en[EL_WPN]) gtext(EF(F_MED), ES(13.0f), lr[EL_WPN].Min, E.weaponCol, wname);
    if (en[EL_ICON]) {
        const WiRect& q = WI_RECTS[wi];
        ImRect ir = lr[EL_ICON];
        float iw = wIco ? floorf(q.w * 13.0f / q.h) : 0.0f, ew = 0.0f;
        for (int k = 0; k < nExtra; ++k) ew += (iw + ew > 0 ? 4.0f : 0.0f) + 12.0f;
        bool hasRow = iw + ew > 0;
        float rowX = floorf(ir.GetCenter().x - (iw + ew) * 0.5f);
        if (sideOf(EL_ICON) == 2) rowX = ir.Max.x - (iw + ew); else if (sideOf(EL_ICON) == 3) rowX = ir.Min.x;
        if (nExtra > 0) {   // C4 / defuse kit / taser next to the weapon icon
            const char* xi[3]; int n = 0;
            if (E.wBomb) xi[n++] = "\xef\x87\xa2";      // rocket f135
            if (E.wDefuser) xi[n++] = "\xef\x9f\x99";   // screwdriver-wrench f7d9
            if (E.wTaser) xi[n++] = "\xef\x83\xa7";     // bolt f0e7
            float x = rowX + iw;
            for (int k = 0; k < n; ++k) {
                x += (x > rowX ? 4.0f : 0.0f);
                ImVec2 c(x + 6.0f, ir.Min.y + 6.5f);
                for (int s2 = 0; s2 < 4; ++s2) Icon(xi[k], 10.5f, c + ImVec2(s2 == 0 ? -1.0f : (s2 == 1 ? 1.0f : 0.0f), s2 == 2 ? -1.0f : (s2 == 3 ? 1.0f : 0.0f)), IM_COL32(0, 0, 0, 150));
                int v0 = DL->VtxBuffer.Size; Icon(xi[k], 10.5f, c, IM_COL32_WHITE); grad(v0, E.iconCol, ir.Min.y, ir.Min.y + 13.0f, false);
                x += 12.0f;
            }
        }
        if (E.readiness) {   // weapon readiness: refills like a reload / deploy timer
            float rt = (float)fmod(ImGui::GetTime(), 3.0);
            float fr = rt < 1.8f ? rt / 1.8f : 1.0f;
            float by = hasRow ? ir.Min.y + 17.0f : ir.Min.y;
            ImVec2 a0(ir.Min.x, by), a1(ir.Max.x, by + 2.0f);
            DL->AddRectFilled(a0 - ImVec2(1, 1), a1 + ImVec2(1, 1), blk);
            DL->AddRectFilled(a0, ImVec2(ImLerp(a0.x, a1.x, fr), a1.y), fr < 1.0f ? IM_COL32(240, 200, 90, 255) : IM_COL32(235, 236, 240, 255));
        }
        if (!wIco) goto icon_done;
        {
        ImVec2 p0(rowX, ir.Min.y), p1(rowX + iw, ir.Min.y + 13.0f);
        ImVec2 uv0((float)q.x / WI_AW, (float)q.y / WI_AH), uv1((float)(q.x + q.w) / WI_AW, (float)(q.y + q.h) / WI_AH);
        for (int s2 = 0; s2 < 4; ++s2) { ImVec2 d(s2 == 0 ? -1.0f : (s2 == 1 ? 1.0f : 0.0f), s2 == 2 ? -1.0f : (s2 == 3 ? 1.0f : 0.0f)); DL->AddImage(g_wiTex->GetTexRef(), p0 + d, p1 + d, uv0, uv1, IM_COL32(0, 0, 0, 150)); }
        int v0 = DL->VtxBuffer.Size; DL->AddImage(g_wiTex->GetTexRef(), p0, p1, uv0, uv1, IM_COL32_WHITE); grad(v0, E.iconCol, p0.y, p1.y, false);
        }
        icon_done:;
    }
    if (en[EL_DIST]) gtext(EF(F_PIX), ES(13.0f), lr[EL_DIST].Min, E.distCol, "12m");
    if (en[EL_FLAGS]) {
        ImRect r = lr[EL_FLAGS]; int sd = sideOf(EL_FLAGS);
        float fy = r.Min.y;
        for (int i = 0; i < nfl; ++i) {
            float w = EF(F_PIX)->CalcTextSizeA(ES(13.0f), FLT_MAX, 0, fl[i]).x;
            float x = sd == 2 ? r.Max.x - w : (sd == 3 ? r.Min.x : floorf(r.GetCenter().x - w * 0.5f));
            gtext(EF(F_PIX), ES(13.0f), ImVec2(x, fy), E.flagsCol, fl[i]); fy += flh;
        }
    }
}
static void EspResetLayout()
{
    static const int sd[8] = { 0, 2, 1, 1, 1, 1, 3, 0 }; static const float od[8] = { 0, 0, 0, 1, 2, 3, 0, 1 };
    for (int i = 0; i < 8; ++i) { g_espSide[i] = sd[i]; g_espOrd[i] = od[i]; }
    g_avAttach = true;
}
// separate plain ImGui window with every ESP preview option
static void EspPreviewWindow(bool interactive)
{
    ImGui::SetNextWindowPos(ImVec2(330, 20), ImGuiCond_FirstUseEver);
    ImGuiWindowFlags wf = ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_AlwaysAutoResize;
    if (!interactive) wf |= ImGuiWindowFlags_NoInputs;
    if (!ImGui::Begin("ESP Preview", nullptr, wf)) { ImGui::End(); return; }
    static const char* models[2] = { "Default", "Standoff 2 (Enemies CT / Teammates T)" };
    ImGui::SetNextItemWidth(160); ImGui::Combo("Model", &EP.model, models, 2);
    ImGui::Checkbox("Idle animation", &EP.idleAnim);
    ImGui::SameLine(); if (ImGui::Button("Reset rotation")) { g_mdlYaw = 0.0f; g_mdlVel = 0.0f; }
    ImGui::Separator();
    struct It { const char* n; bool* on; EC* c; };
    It it[] = { { "Box", &EP.box, &EP.boxCol }, { "Name", &EP.name, &EP.nameCol }, { "Health bar", &EP.health, &EP.healthCol }, { "Armor bar", &EP.armor, &EP.armorCol },
                { "Weapon", &EP.weapon, &EP.weaponCol }, { "Weapon icon", &EP.weaponIcon, &EP.iconCol }, { "Distance", &EP.distance, &EP.distCol },
                { "Flags", &EP.flags, &EP.flagsCol }, { "Skeleton", &EP.skeleton, &EP.skelCol }, { "Head dot", &EP.headDot, &EP.headCol } };
    const ImGuiColorEditFlags cf = ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaBar;
    if (ImGui::BeginTable("esp_el", 3, ImGuiTableFlags_SizingFixedFit | ImGuiTableFlags_RowBg | ImGuiTableFlags_BordersInnerV)) {
        ImGui::TableSetupColumn("Element"); ImGui::TableSetupColumn("Visible"); ImGui::TableSetupColumn("Invisible");
        ImGui::TableHeadersRow();
        int idx = 0;
        for (auto& e : it) {
            ImGui::PushID(e.n); ImGui::TableNextRow();
            ImGui::TableSetColumnIndex(0); ImGui::Checkbox(e.n, e.on);
            if (idx == 0) { ImGui::SameLine(); static const char* bt[] = { "Default", "Corner", "3D" }; ImGui::SetNextItemWidth(80); ImGui::Combo("##boxtype", &EP.boxType, bt, 3); }
            for (int v = 0; v < 2; ++v) {
                EC* c = v ? &EP.inv[idx] : e.c;
                ImGui::TableSetColumnIndex(1 + v); ImGui::PushID(v);
                ImGui::ColorEdit4("##c", c->a, cf);
                if (idx == 2) {   // only the health bar has a gradient
                    ImGui::SameLine(); ImGui::BeginDisabled(!c->grad); ImGui::ColorEdit4("##c2", c->b, cf); ImGui::EndDisabled();
                    ImGui::SameLine(); ImGui::Checkbox("Gradient", &c->grad);
                } else c->grad = false;
                ImGui::PopID();
            }
            ImGui::PopID(); ++idx;
        }
        ImGui::EndTable();
    }
    ImGui::TextDisabled("Invisible colours: eye button in the players preview");
    ImGui::Checkbox("Avatar", &EP.avatar);
    ImGui::SameLine(); if (ImGui::Button("Reset layout")) EspResetLayout();
    ImGui::TextDisabled("Drag the elements in the preview to move them");
    ImGui::Separator();
    { static const char* fonts[] = { "Default", "Verdana", "Pixel" }; ImGui::SetNextItemWidth(160); ImGui::Combo("Font", &EP.font, fonts, 3); }
    ImGui::SetNextItemWidth(160); ImGui::SliderFloat("Name size", &EP.nameSize, 8.0f, 24.0f, "%.1f");
    ImGui::Checkbox("Animate HP", &EP.hpAnim);
    ImGui::SetNextItemWidth(160); ImGui::SliderInt("Max HP", &EP.hp, 1, 100);
    ImGui::SetNextItemWidth(160); ImGui::SliderInt("Armor", &EP.ap, 0, 100);
    ImGui::SetNextItemWidth(160);
    if (ImGui::BeginCombo("Weapon", WI_RECTS[ImClamp(EP.weaponIdx, 0, WI_N - 1)].name)) {
        for (int i = 0; i < WI_N; ++i) if (ImGui::Selectable(WI_RECTS[i].name, EP.weaponIdx == i)) EP.weaponIdx = i;
        ImGui::EndCombo();
    }
    ImGui::End();
}

static void DrawPlayers()
{
    PlayerCfg& p = PL[g_plGroup];
    const float L0 = 180, L1 = 481, LR = 466, LX = 195, SW = 416, SWC = 313;
    SectionHeader(195, 73.5f, g_plGroup ? "TEAMMATE" : "ENEMY");
    float y = 85;
    Card(L0, y, L1, 3);
    Label(LX, RowCY(y, 0), "Enabled");         Toggle(GK("pl_en"), &p.enabled, LR, RowCY(y, 0));
    Label(LX, RowCY(y, 1), "Offscreen Arrow"); Swatch(GK("pl_arrow_c"), &p.arrowCol, SW, RowCY(y, 1), false);  Toggle(GK("pl_arrow"), &p.arrow, LR, RowCY(y, 1));
    Label(LX, RowCY(y, 2), "Sounds");          Swatch(GK("pl_snd_c"), &p.soundsCol, SW, RowCY(y, 2), false);   Toggle(GK("pl_snd"), &p.sounds, LR, RowCY(y, 2));

    SectionHeader(195, 227.5f, g_plGroup ? "TEAMMATE MODEL" : "ENEMY MODEL");
    y = 239;
    Card(L0, y, L1, 7);
    static const char* names[5] = { "Player", "Behind Walls", "On Shot", "History", "Ragdolls" };
    for (int i = 0; i < 5; ++i) {
        float cy = RowCY(y, i);
        char k1[24], k2[24]; snprintf(k1, sizeof k1, "pl_mc%d", i); snprintf(k2, sizeof k2, "pl_m%d", i);
        Label(LX, cy, names[i]);
        Swatch(GK(k1), &p.modelCol[i], SWC, cy, false);
        if ((p.model[i] == M3D_WIREFRAME || p.model[i] == M3D_GALAXYWIRE || p.model[i] == M3D_WATERFLOW || p.model[i] == M3D_GALAXY) && g_ov.type == OV_COLOR && g_ov.id == Id(GK(k1))) g_cpOverlayFor = &p.modelCol[i];
        ChamsRow(GK(k2), R(331, cy - 12, 466, cy + 12), MODEL_ITEMS, IM_ARRAYSIZE(MODEL_ITEMS), &p.model[i]);
    }
    Label(LX, RowCY(y, 5), "Kill Effect"); Swatch(GK("pl_soul_c"), &p.soulCol, SW, RowCY(y, 5), false); Toggle(GK("pl_soul"), &p.soul, LR, RowCY(y, 5));
    Label(LX, RowCY(y, 6), "Glow");           Swatch(GK("pl_glow_c"), &p.glowCol, SW, RowCY(y, 6), false); Toggle(GK("pl_glow"), &p.glow, LR, RowCY(y, 6));

    // ---- preview: group tabs  [ (icon) Enemies ] (icon) ... (list) (expand)
    static const char* gn[2] = { "Enemies", "Teammates" };
    static const char* gi[2] = { "\xef\x80\x87", "\xef\x94\x83" };   // user f007, user-minus f503
    float x = 553;
    for (int i = 0; i < 2; ++i) {
        float s = Anim(Id("plgrp", i), g_plGroup == i ? 1.0f : 0.0f, 14.0f);
        float tw = TextSize(F_MED, 12.6f, gn[i]).x;
        float w = ImLerp(34.0f, 29.0f + tw + 10.0f, EaseInOut(s));
        ImRect r = R(x, 68, x + w, 90);
        ImGuiID id = Id("plgrp_h", i);
        bool hov = Hover(r, id);
        float h = Anim(id, hov ? 1.0f : 0.0f, 16.0f);
        if (hov && IN.click && g_plGroup != i) { g_plGroup = i; if (g_ov.open && g_ov.type != OV_PROFILE) g_ov.open = false; }
        float bga = ImMax(s, h * 0.5f);
        if (bga > 0.003f) DL->AddRectFilled(r.Min, r.Max, C(0x18191F, bga), 5.0f);
        Icon(gi[i], 12.0f, P(x + ImLerp(17.0f, 14.0f, s), 79), C(Mix(Mix(0xB4B6BD, 0xF0F1F4, h), ACCENT, s)));
        if (s > 0.01f) {
            ImVec4 clip(r.Min.x, r.Min.y, r.Max.x - 4, r.Max.y);
            Text(F_MED, 12.6f, P(x + 29, 0), O.y + 79, C(ACCENT, s), gn[i], &clip);
        }
        x += w + 4;
    }
    {   // list / expand buttons
        static const char* ic[2] = { "\xef\x80\xa2", "\xef\x90\xa4" };   // rectangle-list f022, up-right-and-down-left-from-center f424
        float cx[2] = { x + 15, x + 44 };
        DL->AddLine(P(x + 1.5f, 71), P(x + 1.5f, 87), C(0x1B1D24), 1.0f);   // divider between the group tabs and the buttons
        const bool itemsOpen = (g_ov.type == OV_ESPITEMS && g_ov.open) || (g_hasParent && g_ovParent.type == OV_ESPITEMS && g_ov.type == OV_COLOR && g_ov.open);
        for (int i = 0; i < 1; ++i) {
            ImRect r = R(cx[i] - 12, 68, cx[i] + 12, 90);
            ImGuiID id = Id("plbtn", i);
            bool hov = Hover(r, id);
            float h = Anim(id, hov ? 1.0f : 0.0f, 16.0f);
            float act = i == 0 ? Anim(Id("plbtn_act"), itemsOpen ? 1.0f : 0.0f, 14.0f) : 0.0f;
            if (ImMax(h * 0.6f, act) > 0.003f) DL->AddRectFilled(r.Min, r.Max, C(0x18191F, ImMax(h * 0.6f, act)), 5.0f);
            if (i == 0) {   // ESP Items panel
                if (hov && IN.click) OpenOverlay(OV_ESPITEMS, Id("espitems"), r);
                {   // square list icon (rounded square, 3 rows: bullet + line)
                    ImU32 col = C(Mix(Mix(0xB4B6BD, 0xF0F1F4, h), 0xE6E7EB, act));
                    ImVec2 c = P(cx[i], 79);
                    DL->AddRectFilled(c - ImVec2(6.0f, 6.0f), c + ImVec2(6.0f, 6.0f), col, 2.5f);
                    ImU32 hole = C(0x0D0E14, 0.85f);
                    for (int q = -1; q <= 1; ++q) {
                        float yy = c.y + q * 3.0f;
                        DL->AddRectFilled(ImVec2(c.x - 4.0f, yy - 0.8f), ImVec2(c.x - 2.2f, yy + 0.8f), hole);
                        DL->AddRectFilled(ImVec2(c.x - 1.0f, yy - 0.8f), ImVec2(c.x + 4.0f, yy + 0.8f), hole);
                    }
                }
                continue;
            }
            Icon(ic[i], 11.5f, P(cx[i], 79), C(Mix(0xB4B6BD, 0xF0F1F4, h)));
        }
    }
    DrawEspPreview(p);
}

// ---- Visuals > World
static void DrawWorld()
{
    const float L0 = 180, L1 = 481, LR = 466, LX = 195;
    const float R0 = 491, R1 = 787, RR = 772, RX = 506;
    SectionHeader(195, 73.5f, "VIEW");
    float y = 85;
    Card(L0, y, L1, 6);
    NavRow("w_view",  L0, L1, LX, RowCY(y, 0), "View Options");
    NavRow("w_scope", L0, L1, LX, RowCY(y, 1), "Scope Options");
    NavRow("w_vm",    L0, L1, LX, RowCY(y, 2), "Viewmodel Options");
    NavRow("w_persp", L0, L1, LX, RowCY(y, 3), "Perspective Options");
    Label(LX, RowCY(y, 4), "Unlock Spectating");
    ComboRow("w_spec", R(331, RowCY(y, 4) - 12, 466, RowCY(y, 4) + 12), SPEC_ITEMS, 3, nullptr, WD.unlockSpec);
    Label(LX, RowCY(y, 5), "Visual Recoil");
    ComboRow("w_recoil", R(331, RowCY(y, 5) - 12, 466, RowCY(y, 5) + 12), RECOIL_ITEMS, 2, nullptr, WD.visualRecoil);

    SectionHeader(505, 73.5f, "HUD");
    Card(R0, y, R1, 6);
    Label(RX, RowCY(y, 0), "Radar");             Toggle("w_radar", &WD.radar, RR, RowCY(y, 0));
    Label(RX, RowCY(y, 1), "Preserve Killfeed"); Toggle("w_kf", &WD.killfeed, RR, RowCY(y, 1));
    Label(RX, RowCY(y, 2), "Inaccuracy Overlay"); Swatch("w_inacc_c", &WD.inaccuracyCol, 722, RowCY(y, 2)); Toggle("w_inacc", &WD.inaccuracy, RR, RowCY(y, 2));
    Label(RX, RowCY(y, 3), "Scope Overlay");
    ComboRow("w_scopeov", R(640, RowCY(y, 3) - 12, 772, RowCY(y, 3) + 12), SCOPEOV_ITEMS, 4, &WD.scopeOverlay, nullptr);
    NavRow("w_score", R0, R1, RX, RowCY(y, 4), "Scoreboard");
    NavRow("w_cross", R0, R1, RX, RowCY(y, 5), "Crosshairs");

    SectionHeader(195, 344.5f, "WORLD ESP");
    y = 356;
    Card(L0, y, L1, 5);
    NavRow("w_bomb",  L0, L1, LX, RowCY(y, 0), "Bomb");
    NavRow("w_weap",  L0, L1, LX, RowCY(y, 1), "Weapons");
    NavRow("w_gren",  L0, L1, LX, RowCY(y, 2), "Grenades");
    Label(LX, RowCY(y, 3), "Grenade Trajectory"); Dots("w_gt_dots", 427, RowCY(y, 3), false); Toggle("w_gt", &WD.grenTraj, LR, RowCY(y, 3));
    Label(LX, RowCY(y, 4), "Grenade Proximity Warnings"); Toggle("w_gp", &WD.grenProx, LR, RowCY(y, 4));

    SectionHeader(505, 344.5f, "MISCELLANEOUS");
    Card(R0, y, R1, 6);
    NavRow("w_win",   R0, R1, RX, RowCY(y, 0), "Windows");
    NavRow("w_rem",   R0, R1, RX, RowCY(y, 1), "Removals");
    NavRow("w_amb",   R0, R1, RX, RowCY(y, 2), "Ambience");
    NavRow("w_hit",   R0, R1, RX, RowCY(y, 3), "Hit Marker");
    NavRow("w_trac",  R0, R1, RX, RowCY(y, 4), "Bullet Tracers");
    Label(RX, RowCY(y, 5), "Bullet Impacts"); Swatch("w_imp_c", &WD.impactsCol, 722, RowCY(y, 5)); Toggle("w_imp", &WD.impacts, RR, RowCY(y, 5));
}

// ---- Combat > Projectiles
static void DrawProjectiles()
{
    const float L0 = 180, L1 = 481, LR = 466, LX = 195, SW = 416;
    const float R0 = 491, R1 = 787, RR = 772, RX = 506;
    SectionHeader(195, 73.5f, "MAIN");
    float y = 85;
    Card(L0, y, L1, 5);
    Label(LX, RowCY(y, 0), "Enabled");          Toggle("pj_en", &PJ.enabled, LR, RowCY(y, 0));
    Label(LX, RowCY(y, 1), "Grenades");
    ComboRow("pj_types", R(331, RowCY(y, 1) - 12, 466, RowCY(y, 1) + 12), GREN_ITEMS, 4, nullptr, PJ.types);
    Label(LX, RowCY(y, 2), "Trajectory");       Swatch("pj_traj_c", &PJ.trajCol, SW, RowCY(y, 2)); Toggle("pj_traj", &PJ.trajectory, LR, RowCY(y, 2));
    Label(LX, RowCY(y, 3), "Bounce Points");    Toggle("pj_bnc", &PJ.bounces, LR, RowCY(y, 3));
    Label(LX, RowCY(y, 4), "Landing Radius");   Swatch("pj_rad_c", &PJ.radiusCol, SW, RowCY(y, 4)); Toggle("pj_rad", &PJ.radius, LR, RowCY(y, 4));

    SectionHeader(505, 73.5f, "HELPER");
    Card(R0, y, R1, 4);
    Label(RX, RowCY(y, 0), "Grenade Helper");   Toggle("pj_help", &PJ.helper, RR, RowCY(y, 0));
    Label(RX, RowCY(y, 1), "Auto Throw");       Toggle("pj_auto", &PJ.autoThrow, RR, RowCY(y, 1));
    Label(RX, RowCY(y, 2), "Throw Strength");   Slider("pj_str", &PJ.strength, 0, 100, "%d%%", 637, RowCY(y, 2), 90);
    Label(RX, RowCY(y, 3), "Throw Mode");
    ComboRow("pj_mode", R(640, RowCY(y, 3) - 12, 772, RowCY(y, 3) + 12), THROW_ITEMS, 3, &PJ.throwMode, nullptr);
}

static void DrawMisc();   // misc_ui.inc


// ---- colour picker popup (click on a swatch)
static void ShadeGrad(int v0, ImVec2 p0, ImVec2 p1, ImU32 c0, float a0, ImU32 c1, float a1)
{
    ImVec2 d = p1 - p0; float l2 = ImMax(ImLengthSqr(d), 1e-4f);
    ImDrawVert* vv = DL->VtxBuffer.Data;
    for (int i = v0; i < DL->VtxBuffer.Size; ++i) {
        float t = Sat(ImDot(vv[i].pos - p0, d) / l2);
        ImU32 rgb = Mix(c0, c1, t);
        float oa = ((vv[i].col >> IM_COL32_A_SHIFT) & 0xFF) / 255.0f;
        vv[i].col = C(rgb, oa * ImLerp(a0, a1, t));
    }
}
static void Checker(ImRect r, float rnd, float cell = 3.5f)
{
    DL->AddRectFilled(r.Min, r.Max, C(0xD9D9DE), rnd);
    for (float y = r.Min.y; y < r.Max.y - 0.01f; y += cell)
        for (float x = r.Min.x; x < r.Max.x - 0.01f; x += cell) {
            int ix = (int)((x - r.Min.x) / cell + 0.5f), iy = (int)((y - r.Min.y) / cell + 0.5f);
            if (((ix + iy) & 1) == 0) continue;
            ImVec2 a(x, y), b(ImMin(x + cell, r.Max.x), ImMin(y + cell, r.Max.y));
            ImVec2 c = (a + b) * 0.5f;   // skip cells outside the rounded corners
            float qx = ImMax(ImMax(r.Min.x + rnd - c.x, c.x - (r.Max.x - rnd)), 0.0f), qy = ImMax(ImMax(r.Min.y + rnd - c.y, c.y - (r.Max.y - rnd)), 0.0f);
            if (qx * qx + qy * qy > rnd * rnd * 0.8f) continue;
            DL->AddRectFilled(a, b, C(0x9C9CA3));
        }
}
#include "inv_ui.inc"
static void DrawColRect(ImRect r, float rnd, const Col& c)
{
    bool g = c.grad;
    if (c.a[0] < 0.999f || (g && c.a[1] < 0.999f)) Checker(r, rnd);
    int v0 = DL->VtxBuffer.Size;
    DL->AddRectFilled(r.Min, r.Max, IM_COL32_WHITE, rnd);
    ShadeGrad(v0, ImVec2(r.Min.x, r.Min.y), ImVec2(r.Max.x, r.Min.y), c.c[0], c.a[0], g ? c.c[1] : c.c[0], g ? c.a[1] : c.a[0]);
}
static void Swatch(const char* key, Col* col, float cx, float cy, bool allowGrad)
{
    ImGuiID id = Id(key);
    ImRect r(P(cx - 7, cy - 7), P(cx + 7, cy + 7));
    bool hov = Hover(ImRect(r.Min - ImVec2(3, 3), r.Max + ImVec2(3, 3)), id);
    bool open = g_ov.type == OV_COLOR && g_ov.id == id && g_ov.open;
    float h = Anim(id, (hov || open) ? 1.0f : 0.0f, 16.0f);
    DrawColRect(r, 3.5f, *col);
    DL->AddRect(r.Min, r.Max, C(0x000000, 0.18f), 3.5f, 0, 1.0f);
    if (h > 0.003f) DL->AddRect(r.Min - ImVec2(2.5f, 2.5f), r.Max + ImVec2(2.5f, 2.5f), C(0xFFFFFF, 0.22f * h), 5.5f, 0, 1.0f);
    if (hov && IN.click) {
        if (g_inOverlay && g_ov.type == OV_FOVPOP) { g_ovParent = g_ov; g_hasParent = true; } else g_hasParent = false;
        g_espCPIdx = -1;
        OpenOverlay(OV_COLOR, id, r);
    }
    g_swatches[id] = col; g_swNoGrad[id] = !allowGrad;
}
static ImU32 HsvToRgb(float h, float s, float v)
{
    float r, g, b; ImGui::ColorConvertHSVtoRGB(h, s, v, r, g, b);
    return ((ImU32)(r * 255.0f + 0.5f) << 16) | ((ImU32)(g * 255.0f + 0.5f) << 8) | (ImU32)(b * 255.0f + 0.5f);
}
static void RgbToHsv(ImU32 c, float& h, float& s, float& v)
{
    float hh, ss, vv; ImGui::ColorConvertRGBtoHSV(((c >> 16) & 0xFF) / 255.0f, ((c >> 8) & 0xFF) / 255.0f, (c & 0xFF) / 255.0f, hh, ss, vv);
    if (ss > 0.0f && vv > 0.0f) h = hh;   // keep the hue for greys / black
    if (vv > 0.0f) s = ss;
    v = vv;
}
static const ImU32 PICKER_PRESETS[] = { 0xFFFFFF, 0xC8C7E5, 0x96AEFD, 0x6172F3, 0x51A5C1, 0x5BEEFA, 0x45C28A, 0xF0D35A, 0xF0A33C, 0xFF6E98, 0xE0457B, 0x8B7CF6 };
static void DrawColorPicker(float a)
{
    auto it = g_swatches.find(g_ov.id);
    if (it == g_swatches.end()) return;
    Col* col = it->second;
    ImGuiIO& io = ImGui::GetIO();
    static ImGuiID initFor = 0; static Col orig; static int stop = 0; static float H = 0, Sv = 0, V = 1;
    static int dd = 0; static float ddA = 0.0f; static int ddShown = 0;   // inner dropdowns: 1 = mode, 2 = format
    static int fmt = 0;                     // 0 HEX, 1 RGB, 2 HSV
    static int edit = 0; static char eb[40]; static bool efresh = false; static float blink = 0.0f;
    static bool palette = false;
    auto load = [&]() { RgbToHsv(col->c[stop], H, Sv, V); };
    if (initFor != g_ov.id) { initFor = g_ov.id; orig = *col; stop = 0; dd = 0; ddA = 0; edit = 0; H = 0; Sv = 0; load(); }
    if (!g_ov.open) { edit = 0; dd = 0; }
    bool noGrad = g_swNoGrad[g_ov.id];
    const bool espC = EspPickerOpen();               // ESP element: visible / behind-walls colours
    const bool espN = espC && g_espCPIdx == 1;       // Name also gets Font, Case, Draw Avatar
    if (noGrad) col->grad = false;
    if (!col->grad && !espC) stop = 0;

    const float W = 262.0f;
    float gA = AnimS("cp_grad", col->grad ? 1.0f : 0.0f, 14.0f);
    float pA = AnimS("cp_pal", palette ? 1.0f : 0.0f, 14.0f);
    bool ovShow = col == g_cpOverlayFor;   // Wireframe / Waterflow chams: "Overlay" switch
    bool fovX = col == &S.fovCol;          // FOV circle colour: Fill / Thickness / Glow sliders
    float gy = 0.0f, py = 34.0f * pA, oy = ovShow ? 36.0f : (fovX ? 100.0f : 0.0f);
    float HH = 386.0f + gy + py + oy + (g_swNoGrad[g_ov.id] ? -34.0f : 0.0f) + (espN ? 160.0f : espC ? 56.0f : 0.0f);
    // place right of the swatch, kept on screen
    ImRect sw = g_ov.opener;
    ImVec2 o(sw.Max.x + 12.0f, floorf(sw.GetCenter().y - 40.0f));
    {
        float top = g_snapO.y, bot = top + (io.DisplaySize.y - top) / g_dpi, scrTop = top - top / g_dpi;
        float left = g_snapO.x, right = left + (io.DisplaySize.x - left) / g_dpi;
        o.y = ImClamp(o.y, scrTop + 8.0f, bot - HH - 8.0f);
        if (espC) {   // ESP element / chip: drop down right under it (above when no room)
            o = ImVec2(sw.Min.x, sw.Max.y + 6.0f);
            if (o.y + HH > bot - 8) o.y = sw.Min.y - 6.0f - HH;
            o.y = ImMax(o.y, scrTop + 8.0f);
            o.x = ImClamp(o.x, left + 8.0f, right - 8.0f - W);
        } else {
        if (g_hasParent) o.x = g_parentRect.Max.x + 8.0f;
        if (o.x + W > right - 8) o.x = (g_hasParent ? g_parentRect.Min.x : sw.Min.x) - 12.0f - W;
        }
    }
    o.x -= (1.0f - EaseOutCubic(a)) * 6.0f;
    auto Q = [&](float x, float y) { return o + ImVec2(x, y); };
    ImRect r(o, o + ImVec2(W, HH));
    g_ov.rect = r;
    Shadow(r, 10.0f, 14.0f, 0.6f, ImVec2(0, 3));
    Backdrop(r, 10.0f, 1.0f);
    DL->AddRectFilled(r.Min, r.Max, C(0x12141A, 0.93f), 10.0f);
    DL->AddRect(r.Min, r.Max, C(0x1E2027), 10.0f, 0, 1.0f);
    bool block = dd != 0;   // an inner dropdown is open -> it owns the mouse
    auto HoverP = [&](ImRect rr, ImGuiID id) { return !block && Hover(rr, id, true); };
    bool clickUsed = false;

    bool ddOpenedNow = false;
    // ---- header: [v Gradient]
    if (!noGrad) {
        const char* mt = col->grad ? "Gradient" : "Default";
        float tw = TextSize(F_MED, 12.6f, mt).x;
        ImRect mb(Q(9, 12), Q(9 + 18 + tw + 9, 33));
        ImGuiID id = Id("cp_mode");
        bool hov = HoverP(mb, id);
        float h = Anim(id, (hov || dd == 1) ? 1.0f : 0.0f, 16.0f);
        DL->AddRectFilled(mb.Min, mb.Max, C(Mix(0x1D1F25, 0x26282F, h)), 5.0f);
        Chevron(Q(18.5f, 23.0f), 7.0f, 3.5f, C(Mix(0xA9AAB1, 0xE2E3E8, h)), dd == 1 ? EaseInOut(ddA) : 0.0f, 1.5f);
        Text(F_MED, 12.6f, Q(27, 0), o.y + 22.5f, C(Mix(0xC9CAD0, 0xEDEEF2, h)), mt);
        if (hov && IN.click) { dd = dd == 1 ? 0 : 1; clickUsed = true; ddOpenedNow = true; }
    }
    // ---- colour boxes (top right): Default = 1 box, Gradient = 2 boxes (click = edit that colour)
    for (int k = 0; k < 2 && !noGrad; ++k) {
        float vis = k == 0 ? 1.0f : gA;          // the 2nd box appears in gradient mode
        if (vis <= 0.003f) continue;
        float cx = k == 0 ? ImLerp(238.0f, 214.0f, gA) : 238.0f;
        ImVec2 kc = Q(cx, 22.5f);
        ImRect bx(kc - ImVec2(7.5f, 7.5f), kc + ImVec2(7.5f, 7.5f));
        ImGuiID id = Id("cp_box", k);
        bool hov = HoverP(ImRect(bx.Min - ImVec2(4, 4), bx.Max + ImVec2(4, 4)), id) && col->grad;
        float sel = Anim(id, (col->grad && stop == k) ? 1.0f : 0.0f, 16.0f);
        float h = Anim(id + 1, hov ? 1.0f : 0.0f, 16.0f);
        int v0 = DL->VtxBuffer.Size;
        Col one; one.c[0] = col->c[k]; one.a[0] = col->a[k];
        DrawColRect(bx, 3.5f, one);
        DL->AddRect(bx.Min, bx.Max, C(0x000000, 0.2f), 3.5f);
        float ring = ImMax(sel, h * 0.5f);
        if (ring > 0.003f) DL->AddRect(bx.Min - ImVec2(2.5f, 2.5f), bx.Max + ImVec2(2.5f, 2.5f), C(0xFFFFFF, 0.65f * ring), 5.5f, 0, 1.2f);
        FadeVerts(v0, vis);
        if (hov && IN.click) { stop = k; load(); clickUsed = true; }
    }
    // ---- saturation / value square
    float hdr = noGrad ? -34.0f : 0.0f;
    float y0 = 46.0f + gy + hdr;
    ImRect sv(Q(9, y0), Q(W - 9, y0 + 242));
    ImRect hb(Q(9, y0 + 260 - 3.5f), Q(W - 9, y0 + 260 + 3.5f));
    ImRect ab(Q(9, y0 + 284.5f - 3.5f), Q(W - 9, y0 + 284.5f + 3.5f));
    ImGuiID idSv = Id("cp_sv"), idHue = Id("cp_hue"), idA = Id("cp_alpha");
    if (HoverP(sv, idSv) && IN.click) { g_active = idSv; clickUsed = true; }
    if (HoverP(ImRect(hb.Min - ImVec2(4, 6), hb.Max + ImVec2(4, 6)), idHue) && IN.click) { g_active = idHue; clickUsed = true; }
    if (HoverP(ImRect(ab.Min - ImVec2(4, 6), ab.Max + ImVec2(4, 6)), idA) && IN.click) { g_active = idA; clickUsed = true; }
    float& A = col->a[stop];
    if (g_active == idSv)  { g_hotAny = true; Sv = Sat((IN.m.x - sv.Min.x) / sv.GetWidth()); V = 1.0f - Sat((IN.m.y - sv.Min.y) / sv.GetHeight()); if (!IN.down) g_active = 0; }
    if (g_active == idHue) { g_hotAny = true; H = ImMin(Sat((IN.m.x - hb.Min.x) / hb.GetWidth()), 0.9999f); if (!IN.down) g_active = 0; }
    if (g_active == idA)   { g_hotAny = true; A = Sat((IN.m.x - ab.Min.x) / ab.GetWidth()); if (!IN.down) g_active = 0; }
    if (g_active == idSv || g_active == idHue) col->c[stop] = HsvToRgb(H, Sv, V);
    ImU32 hue = HsvToRgb(H, 1, 1), cur = col->c[stop];
    {
        int v0 = DL->VtxBuffer.Size;
        DL->AddRectFilled(sv.Min, sv.Max, IM_COL32_WHITE, 7.0f);
        ShadeGrad(v0, sv.Min, ImVec2(sv.Max.x, sv.Min.y), 0xFFFFFF, 1, hue, 1);
        v0 = DL->VtxBuffer.Size;
        DL->AddRectFilled(sv.Min, sv.Max, IM_COL32_WHITE, 7.0f);
        ShadeGrad(v0, sv.Min, ImVec2(sv.Min.x, sv.Max.y), 0x000000, 0, 0x000000, 1);
    }
    // hue bar (rounded ends + 6 segments)
    {
        float rad = hb.GetHeight() * 0.5f, x0 = hb.Min.x + rad, x1 = hb.Max.x - rad;
        DL->AddCircleFilled(ImVec2(x0, hb.GetCenter().y), rad, C(0xFF0000), 16);
        DL->AddCircleFilled(ImVec2(x1, hb.GetCenter().y), rad, C(0xFF0000), 16);
        for (int k = 0; k < 6; ++k) {
            float xa = x0 + (x1 - x0) * k / 6.0f, xb = x0 + (x1 - x0) * (k + 1) / 6.0f;
            ImU32 c0 = C(HsvToRgb(k / 6.0f, 1, 1)), c1 = C(HsvToRgb((k + 1) / 6.0f * 0.99999f, 1, 1));
            DL->AddRectFilledMultiColor(ImVec2(xa - 0.3f, hb.Min.y), ImVec2(xb + 0.3f, hb.Max.y), c0, c1, c1, c0);
        }
    }
    // alpha bar
    {
        Checker(ab, ab.GetHeight() * 0.5f, 3.5f);
        int v0 = DL->VtxBuffer.Size;
        DL->AddRectFilled(ab.Min, ab.Max, IM_COL32_WHITE, ab.GetHeight() * 0.5f);
        ShadeGrad(v0, ab.Min, ImVec2(ab.Max.x, ab.Min.y), cur, 0, cur, 1);
    }
    // knobs
    {
        ImVec2 kp(sv.Min.x + Sv * sv.GetWidth(), sv.Min.y + (1 - V) * sv.GetHeight());
        float hk = AnimS("cp_k0", g_active == idSv ? 1.0f : 0.0f, 18.0f);
        float kr = 7.0f + hk * 1.0f;
        DL->AddCircleFilled(kp, kr + 1.5f, C(0x000000, 0.28f), 24);
        DL->AddCircleFilled(kp, kr, C(0xF2F2F5), 24);
        DL->AddCircleFilled(kp, kr - 2.5f, C(cur), 24);
        float hx = ImClamp(hb.Min.x + H * hb.GetWidth(), hb.Min.x + 4.5f, hb.Max.x - 4.5f);
        ImRect hk2(ImVec2(hx - 5.5f, hb.GetCenter().y - 9.5f), ImVec2(hx + 5.5f, hb.GetCenter().y + 9.5f));
        DL->AddRectFilled(hk2.Min - ImVec2(1, 1), hk2.Max + ImVec2(1, 1), C(0x000000, 0.3f), 6.5f);
        DL->AddRectFilled(hk2.Min, hk2.Max, C(0xF5F5F8), 5.5f);
        DL->AddRectFilled(hk2.Min + ImVec2(2.5f, 2.5f), hk2.Max - ImVec2(2.5f, 2.5f), C(hue), 3.0f);
        float ax = ImClamp(ab.Min.x + A * ab.GetWidth(), ab.Min.x + 6.0f, ab.Max.x - 6.0f);
        DL->AddCircleFilled(ImVec2(ax, ab.GetCenter().y), 7.5f, C(0x000000, 0.28f), 24);
        DL->AddCircleFilled(ImVec2(ax, ab.GetCenter().y), 6.5f, C(0xF5F5F8), 24);
    }
    // ---- bottom row: [v HEX]  [■ #E3E3E3FF] [100%] [palette]
    float by = y0 + 317.0f;
    {
        static const char* FMT[3] = { "HEX", "RGB", "HSV" };
        float tw = TextSize(F_MED, 12.6f, FMT[fmt]).x;
        ImRect fb(Q(9, by - 11), Q(9 + 18 + tw + 9, by + 11));
        ImGuiID id = Id("cp_fmt");
        bool hov = HoverP(fb, id);
        float h = Anim(id, (hov || dd == 2) ? 1.0f : 0.0f, 16.0f);
        if (h > 0.003f) DL->AddRectFilled(fb.Min, fb.Max, C(0x1D1F25, h), 5.0f);
        Chevron(Q(18.5f, by + 0.5f), 7.0f, 3.5f, C(Mix(0xA9AAB1, 0xE2E3E8, h)), dd == 2 ? EaseInOut(ddA) : 0.0f, 1.5f);
        Text(F_MED, 12.6f, Q(27, 0), o.y + by, C(Mix(0xC9CAD0, 0xEDEEF2, h)), FMT[fmt]);
        if (hov && IN.click) { dd = dd == 2 ? 0 : 2; clickUsed = true; ddOpenedNow = true; }
    }
    auto valueText = [&](char* out, int n) {
        int R = (cur >> 16) & 0xFF, G = (cur >> 8) & 0xFF, B = cur & 0xFF;
        if (fmt == 0) snprintf(out, n, "%06X%02X", cur, (int)(A * 255.0f + 0.5f));
        else if (fmt == 1) snprintf(out, n, "%d, %d, %d", R, G, B);
        else snprintf(out, n, "%d, %d, %d", (int)(H * 360.0f + 0.5f), (int)(Sv * 100.0f + 0.5f), (int)(V * 100.0f + 0.5f));
    };
    auto apply = [&]() {
        if (edit == 1) {
            if (fmt == 0) {
                char hx[16] = {}; int n = 0;
                for (char* p = eb; *p && n < 8; ++p) if (isxdigit((unsigned char)*p)) hx[n++] = *p;
                if (n == 3) { char t[7] = { hx[0], hx[0], hx[1], hx[1], hx[2], hx[2], 0 }; memcpy(hx, t, 7); n = 6; }
                if (n == 6 || n == 8) {
                    unsigned v = (unsigned)strtoul(hx, nullptr, 16);
                    if (n == 8) { A = (v & 0xFF) / 255.0f; v >>= 8; }
                    col->c[stop] = v & 0xFFFFFF; load();
                }
            } else {
                char t[40]; int k = 0; for (char* p = eb; *p && k < 39; ++p) t[k++] = (isdigit((unsigned char)*p) || *p == '.') ? *p : ' '; t[k] = 0;
                float x = 0, y = 0, z = 0;
                if (sscanf(t, "%f %f %f", &x, &y, &z) == 3) {
                    if (fmt == 1) col->c[stop] = ((ImU32)ImClamp((int)x, 0, 255) << 16) | ((ImU32)ImClamp((int)y, 0, 255) << 8) | (ImU32)ImClamp((int)z, 0, 255);
                    else { H = ImClamp(x / 360.0f, 0.0f, 0.9999f); Sv = Sat(y / 100.0f); V = Sat(z / 100.0f); col->c[stop] = HsvToRgb(H, Sv, V); }
                    if (fmt == 1) load();
                }
            }
        } else if (edit == 2) {
            int v = atoi(eb); A = ImClamp(v, 0, 100) / 100.0f;
        }
        edit = 0;
    };
    // keyboard for the text fields
    if (edit) {
        ImGui::GetCurrentContext()->WantTextInputNextFrame = 1;
        blink += g_dt;
        for (int i = 0; i < io.InputQueueCharacters.Size; ++i) {
            ImWchar ch = io.InputQueueCharacters[i];
            bool ok = edit == 2 ? (ch >= '0' && ch <= '9') : (fmt == 0 ? (ch < 128 && isxdigit(ch)) || ch == '#' : (ch >= '0' && ch <= '9') || ch == ',' || ch == ' ' || ch == '.');
            if (!ok) continue;
            if (efresh) { eb[0] = 0; efresh = false; }
            size_t L = strlen(eb);
            size_t maxL = edit == 2 ? 3 : (fmt == 0 ? 9 : 16);
            if (L < maxL) { eb[L] = (char)(fmt == 0 && edit == 1 ? toupper(ch) : ch); eb[L + 1] = 0; blink = 0; }
        }
        io.InputQueueCharacters.resize(0);
        if (ImGui::IsKeyPressed(ImGuiKey_Backspace, true)) { if (efresh) { eb[0] = 0; efresh = false; } size_t L = strlen(eb); if (L) eb[L - 1] = 0; blink = 0; }
        if (ImGui::IsKeyPressed(ImGuiKey_Enter, false)) apply();
        else if (ImGui::IsKeyPressed(ImGuiKey_Escape, false)) edit = 0;
    }
    {   // value box
        ImRect vb(Q(82, by - 12), Q(179, by + 12));
        ImGuiID id = Id("cp_val");
        bool hov = HoverP(vb, id);
        float h = Anim(id, (hov || edit == 1) ? 1.0f : 0.0f, 16.0f);
        DL->AddRectFilled(vb.Min, vb.Max, C(Mix(0x1A1C22, 0x22242B, h)), 5.0f);
        if (edit == 1) DL->AddRect(vb.Min, vb.Max, C(ACCENT, 0.7f), 5.0f, 0, 1.0f);
        ImRect ps(Q(89, by - 5.5f), Q(100, by + 5.5f));
        Col one; one.c[0] = cur; one.a[0] = A; DrawColRect(ps, 2.5f, one);
        char txt[40]; if (edit == 1) snprintf(txt, sizeof txt, "%s", eb); else valueText(txt, sizeof txt);
        ImVec4 clip(vb.Min.x, vb.Min.y, vb.Max.x - 2, vb.Max.y);
        float tx = o.x + 106;
        if (fmt == 0) { Text(F_MED, 11.5f, ImVec2(tx, 0), o.y + by, C(0x6A6B73), "#", &clip); tx += TextSize(F_MED, 11.5f, "#").x + 1.0f; }
        Text(F_MED, 12.0f, ImVec2(tx, 0), o.y + by, C(efresh && edit == 1 ? 0xFFFFFF : Mix(0xA9AAB1, 0xDADBE0, h)), txt, &clip);
        if (efresh && edit == 1) { float w = TextSize(F_MED, 12.0f, txt).x; DL->AddRectFilled(ImVec2(tx - 1, o.y + by - 8), ImVec2(tx + w + 1, o.y + by + 8), C(ACCENT, 0.35f), 2.0f); }
        if (edit == 1 && fmodf(blink, 1.0f) < 0.55f) { float w = TextSize(F_MED, 12.0f, txt).x; DL->AddLine(ImVec2(tx + w + 1, o.y + by - 7), ImVec2(tx + w + 1, o.y + by + 7), C(0xE6E6EA), 1.0f); }
        if (hov && IN.click) { if (edit && edit != 1) apply(); if (edit != 1) { edit = 1; valueText(eb, sizeof eb); efresh = true; blink = 0; } clickUsed = true; }
    }
    {   // alpha % box
        ImRect pb(Q(184, by - 12), Q(228, by + 12));
        ImGuiID id = Id("cp_pct");
        bool hov = HoverP(pb, id);
        float h = Anim(id, (hov || edit == 2) ? 1.0f : 0.0f, 16.0f);
        DL->AddRectFilled(pb.Min, pb.Max, C(Mix(0x1A1C22, 0x22242B, h)), 5.0f);
        if (edit == 2) DL->AddRect(pb.Min, pb.Max, C(ACCENT, 0.7f), 5.0f, 0, 1.0f);
        char txt[16]; if (edit == 2) snprintf(txt, sizeof txt, "%s%%", eb); else snprintf(txt, sizeof txt, "%d%%", (int)(A * 100.0f + 0.5f));
        float w = TextSize(F_MED, 12.0f, txt).x;
        float tx = pb.GetCenter().x - w * 0.5f;
        if (efresh && edit == 2) DL->AddRectFilled(ImVec2(tx - 1, o.y + by - 8), ImVec2(tx + w + 1, o.y + by + 8), C(ACCENT, 0.35f), 2.0f);
        Text(F_MED, 12.0f, ImVec2(tx, 0), o.y + by, C(edit == 2 ? 0xFFFFFF : Mix(0xA9AAB1, 0xDADBE0, h)), txt);
        if (edit == 2 && !efresh && fmodf(blink, 1.0f) < 0.55f) { float cw = TextSize(F_MED, 12.0f, eb).x; DL->AddLine(ImVec2(tx + cw + 0.5f, o.y + by - 7), ImVec2(tx + cw + 0.5f, o.y + by + 7), C(0xE6E6EA), 1.0f); }
        if (hov && IN.click) { if (edit && edit != 2) apply(); if (edit != 2) { edit = 2; snprintf(eb, sizeof eb, "%d", (int)(A * 100.0f + 0.5f)); efresh = true; blink = 0; } clickUsed = true; }
    }
    {   // palette button (grid + plus)
        ImRect gb(Q(232, by - 11), Q(253, by + 11));
        ImGuiID id = Id("cp_palbtn");
        bool hov = HoverP(gb, id);
        float h = Anim(id, (hov || palette) ? 1.0f : 0.0f, 16.0f);
        if (h > 0.003f) DL->AddRectFilled(gb.Min, gb.Max, C(0x1D1F25, h), 5.0f);
        ImU32 ic = C(Mix(0xA9AAB1, 0xF0F1F4, h));
        ImVec2 c = gb.GetCenter();
        DL->AddRectFilled(c + ImVec2(-5, -5), c + ImVec2(-1, -1), ic, 1.0f);
        DL->AddRectFilled(c + ImVec2(1, -5), c + ImVec2(5, -1), ic, 1.0f);
        DL->AddRectFilled(c + ImVec2(-5, 1), c + ImVec2(-1, 5), ic, 1.0f);
        DL->AddLine(c + ImVec2(3, 0.8f), c + ImVec2(3, 5.2f), ic, 1.4f);
        DL->AddLine(c + ImVec2(0.8f, 3), c + ImVec2(5.2f, 3), ic, 1.4f);
        if (hov && IN.click) { palette = !palette; clickUsed = true; }
    }
    if (ovShow) {   // Overlay: draw the chams on top of the model instead of replacing it
        float cy = by + 36.0f;
        DL->AddLine(Q(9, by + 17.5f), Q(W - 9, by + 17.5f), C(0x1C1E25));
        Text(F_MED, 12.6f, Q(12, 0), o.y + cy, C(0xCDCCD4), "Overlay");
        ImVec2 so = O; O = o;
        bool si = g_inOverlay; g_inOverlay = true;
        Toggle("cp_overlay", &col->overlay, W - 12, cy, block);
        g_inOverlay = si;
        O = so;
    }
    if (fovX) {
        DL->AddLine(Q(9, by + 17.5f), Q(W - 9, by + 17.5f), C(0x1C1E25));
        ImVec2 so = O; O = o;
        bool si = g_inOverlay; g_inOverlay = true;
        struct FRow { const char* name; float* v; };
        const FRow fr[3] = { { "Fill", &S.fovFill }, { "Thickness", &S.fovThick }, { "Glow", &S.fovGlow } };
        for (int i = 0; i < 3; ++i) {
            float cy = by + 36.0f + 32.0f * i;
            ImRect rr(Q(5, cy - 15), Q(W - 5, cy + 15));
            ImGuiID id = Id("cp_fovrow", i);
            bool hov = !block && (Hover(rr, id, true) || g_active == Id(fr[i].name));
            float h = Anim(id, hov ? 1.0f : 0.0f, 14.0f);
            if (h > 0.003f) DL->AddRectFilled(rr.Min, rr.Max, C(0x1D1C26, h * 0.9f), 5.0f);
            Text(F_MED, 12.6f, Q(12, 0), o.y + cy, C(Mix(0xB4B3BA, 0xD6D5DB, h)), fr[i].name);
            BarSlider(fr[i].name, fr[i].v, W - 113, cy, 101, h > 0.5f);
        }
        g_inOverlay = si;
        O = so;
    }
    float pby = by + oy;
    if (pA > 0.003f) {   // preset palette
        int v0 = DL->VtxBuffer.Size;
        DL->PushClipRect(Q(0, pby + 14), Q(W, HH), true);
        float cy = pby + 33.0f;
        DL->AddLine(Q(9, pby + 17.5f), Q(W - 9, pby + 17.5f), C(0x1C1E25));
        const int N = IM_ARRAYSIZE(PICKER_PRESETS);
        float step = (W - 18 - 16) / (N - 1);
        for (int i = 0; i < N; ++i) {
            ImVec2 c = Q(17 + step * i, cy);
            ImRect q(c - ImVec2(8, 8), c + ImVec2(8, 8));
            ImGuiID id = Id("cp_pre", i);
            bool hov = HoverP(q, id) && palette;
            float h = Anim(id, hov ? 1.0f : 0.0f, 16.0f);
            DL->AddRectFilled(q.Min, q.Max, C(PICKER_PRESETS[i]), 4.0f);
            if (h > 0.003f || PICKER_PRESETS[i] == cur) DL->AddRect(q.Min - ImVec2(2, 2), q.Max + ImVec2(2, 2), C(0xFFFFFF, PICKER_PRESETS[i] == cur ? 0.6f : 0.3f * h), 5.5f);
            if (hov && IN.click) { col->c[stop] = PICKER_PRESETS[i]; load(); clickUsed = true; }
        }
        DL->PopClipRect();
        FadeVerts(v0, pA);
    }
    float rowY[3] = { 0, 0, 0 };
    if (espC) {   // [vis][inv] colour boxes, then (Name) Font / Case / Draw Avatar rows
        float ey = pby + 34.0f * pA;
        for (int k = 0; k < 2; ++k) {
            ImVec2 kc = Q(18.0f + 24.0f * k, ey + 36.0f);
            ImRect bx(kc - ImVec2(8.5f, 8.5f), kc + ImVec2(8.5f, 8.5f));
            ImGuiID id = Id("cp_vis", k);
            bool hov = HoverP(ImRect(bx.Min - ImVec2(3, 3), bx.Max + ImVec2(3, 3)), id);
            float sel = Anim(id, stop == k ? 1.0f : 0.0f, 16.0f), h = Anim(id + 1, hov ? 1.0f : 0.0f, 16.0f);
            Col one; one.c[0] = col->c[k]; one.a[0] = col->a[k];
            DrawColRect(bx, 4.0f, one);
            DL->AddRect(bx.Min, bx.Max, C(0x000000, 0.2f), 4.0f);
            float ring = ImMax(sel, h * 0.5f);
            if (ring > 0.003f) DL->AddRect(bx.Min - ImVec2(2.5f, 2.5f), bx.Max + ImVec2(2.5f, 2.5f), C(0xFFFFFF, 0.6f * ring), 6.0f, 0, 1.2f);
            if (hov && IN.click) { stop = k; load(); clickUsed = true; }
        }
        float ry0 = ey + 60.0f;
        if (espN) {
        ImRect card(Q(6, ry0), Q(W - 6, ry0 + 3 * 31.0f + 4));
        DL->AddRectFilled(card.Min, card.Max, C(0x17191F, 0.85f), 7.0f);
        static const char* RL[3] = { "Font", "Case", "Draw Avatar" };
        for (int i = 0; i < 3; ++i) {
            float cy = ry0 + 17.5f + 31.0f * i; rowY[i] = cy;
            ImRect rr(Q(8, cy - 14), Q(W - 8, cy + 14));
            ImGuiID id = Id("cp_row", i);
            bool hov = HoverP(rr, id);
            float h = Anim(id, (hov || dd == 3 + i) ? 1.0f : 0.0f, 16.0f);
            if (h > 0.003f && i < 2) DL->AddRectFilled(rr.Min, rr.Max, C(0x20222A, h), 6.0f);
            ImU32 ic = C(Mix(0xA9AAB1, 0xE6E7EB, h));
            if (i == 0) Icon("\xef\x80\xb1", 11.5f, Q(23, cy), ic);              // font f031
            else if (i == 1) { float tw = TextSize(F_SEMI, 12.0f, "Aa").x; Text(F_SEMI, 12.0f, Q(23 - tw * 0.5f, 0), o.y + cy, ic, "Aa"); }
            else Icon("\xef\x8a\xbd", 12.0f, Q(23, cy), ic);                     // circle-user f2bd
            Text(F_MED, 12.6f, Q(42, 0), o.y + cy, C(Mix(0xC9CAD0, 0xEDEEF2, h)), RL[i]);
            if (i < 2) {
                const char* v = i == 0 ? NAME_FONTS[ImClamp(EP.nameFont, 0, 3)] : NAME_CASES[ImClamp(EP.nameCase, 0, 2)];
                float tw = TextSize(F_MED, 12.6f, v).x;
                Text(F_MED, 12.6f, Q(W - 27 - tw, 0), o.y + cy, C(Mix(0xA9AAB1, 0xDADBE0, h)), v);
                ChevronRight(Q(W - 17 + h * 1.5f, cy), 4.0f, 8.0f, C(Mix(0xA9AAB1, 0xF0F1F4, h)), 1.5f);
                if (hov && IN.click) { dd = dd == 3 + i ? 0 : 3 + i; clickUsed = true; ddOpenedNow = true; }
            } else {
                ImVec2 so = O; O = o;
                bool si = g_inOverlay; g_inOverlay = true;
                Toggle("cp_drawav", &EP.avatar, W - 14, cy, block);
                g_inOverlay = si; O = so;
            }
        }
        }
    }
    if (edit && IN.click && !clickUsed) apply();   // click elsewhere commits the text

    // ---- inner dropdowns (mode / format)
    ddA = ImClamp(ddA + (dd ? 1 : -1) * g_dt * 9.0f, 0.0f, 1.0f);
    if (dd) ddShown = dd;
    if (ddA > 0.0f && ddShown) {
        static const char* MI[2] = { "Default", "Gradient" };
        static const char* FI[3] = { "HEX", "RGB", "HSV" };
        const char** items = ddShown == 1 ? MI : ddShown == 2 ? FI : ddShown == 3 ? NAME_FONTS : NAME_CASES;
        int n = ddShown == 1 ? 2 : ddShown == 3 ? 4 : 3;
        int sel = ddShown == 1 ? (col->grad ? 1 : 0) : ddShown == 2 ? fmt : ddShown == 3 ? EP.nameFont : EP.nameCase;
        const float IH = 24.0f;
        float h = n * IH + 8;
        ImRect m = ddShown == 1 ? ImRect(Q(9, 37), Q(109, 37 + h)) : ddShown == 2 ? ImRect(Q(9, by - 15 - h), Q(109, by - 15))
                 : ImRect(Q(W - 119, rowY[ddShown - 3] + 16), Q(W - 9, rowY[ddShown - 3] + 16 + h));
        float e = EaseOutCubic(ddA);
        int v0 = DL->VtxBuffer.Size;
        Shadow(m, 6.0f, 10.0f, 0.5f, ImVec2(0, 2));
        DL->AddRectFilled(m.Min, m.Max, C(0x191B21, 0.98f), 6.0f);
        DL->AddRect(m.Min, m.Max, C(0x24262D), 6.0f);
        bool clickedItem = false;
        for (int i = 0; i < n; ++i) {
            ImRect ir(ImVec2(m.Min.x + 4, m.Min.y + 4 + IH * i), ImVec2(m.Max.x - 4, m.Min.y + 4 + IH * (i + 1)));
            ImGuiID id = Id("cp_dd", ddShown * 10 + i);
            bool hov = dd && Hover(ir, id, true);
            float hh = Anim(id, hov ? 1.0f : 0.0f, 18.0f);
            if (hh > 0.003f) DL->AddRectFilled(ir.Min, ir.Max, C(0x24262E, hh), 4.0f);
            Text(F_MED, 12.5f, ImVec2(ir.Min.x + 8, 0), ir.GetCenter().y, C(Mix(Mix(0xA3A4AB, 0xE4E5EA, hh), 0xFFFFFF, i == sel ? 1.0f : 0.0f)), items[i]);
            if (i == sel) { ImVec2 c(ir.Max.x - 11, ir.GetCenter().y); ImVec2 pts[3] = { c + ImVec2(-4, 0), c + ImVec2(-1.2f, 3), c + ImVec2(4, -3.2f) }; DL->AddPolyline(pts, 3, C(0xFFFFFF), 0, 1.6f); }
            if (hov && IN.click) {
                clickedItem = true;
                if (ddShown == 1) {
                    bool g = i == 1;
                    if (g && !col->grad) { float h2, s2, v2; h2 = H; s2 = Sv; v2 = V; RgbToHsv(col->c[0], h2, s2, v2);
                        if (col->c[1] == col->c[0]) { col->c[1] = HsvToRgb(fmodf(h2 + 0.12f, 1.0f), ImMax(s2, 0.35f), ImMax(v2, 0.6f)); col->a[1] = col->a[0]; } }
                    col->grad = g; if (!g) { stop = 0; load(); }
                } else if (ddShown == 2) fmt = i;
                else if (ddShown == 3) EP.nameFont = i;
                else EP.nameCase = i;
                dd = 0;
            }
        }
        if (dd && IN.click && !clickedItem && !ddOpenedNow && !m.Contains(IN.m)) dd = 0;   // click elsewhere just closes it
        ImDrawVert* vv = DL->VtxBuffer.Data;   // fade + slide
        float dy = (1.0f - e) * (ddShown == 2 ? 4.0f : -4.0f);
        for (int i = v0; i < DL->VtxBuffer.Size; ++i) vv[i].pos.y += dy;
        FadeVerts(v0, e);
        if (dd) g_ov.rect.Add(m);
    }
}


// ---- ESP Items panel (list button above the preview): click an item to show / hide it on the preview
struct EspItem { const char* name; bool* v; int ci = 0; };
static ImRect DrawEspItems(float a)
{
    EspPrevCfg& E = EP;
    EspItem mainI[6] = { { "Bounding Box", &E.box, 0 }, { "Name", &E.name, 1 }, { "Distance", &E.distance, 6 }, { "Health Bar", &E.health, 2 }, { "Ammo Bar", &E.armor, 3 }, { "Skeleton", &E.skeleton, 8 } };
    EspItem flagI[15]; for (int i = 0; i < 15; ++i) flagI[i] = { FLAG_NAMES[i], &E.flag[i], 7 };
    EspItem wpnI[5] = { { "Text", &E.weapon, 4 }, { "Icon", &E.weaponIcon, 5 }, { "Readiness Bar", &E.readiness, 5 }, { "Bomb", &E.wBomb, 5 }, { "Defuser", &E.wDefuser, 5 } };
    struct Sec { const char* t; EspItem* it; int n; } secs[3] = { { "Main", mainI, 6 }, { "Flags", flagI, 15 }, { "Weapon", wpnI, 5 } };
    const float X0 = 491, X1 = 787, Y0 = 101;
    const float PADC = 8, CH = 26, GX = 6, GY = 7, TP = 9;   // card padding, chip height, gaps, chip text padding
    const float cw = (X1 - X0) - 16;                           // card width
    // layout pass
    float hgt[3];
    for (int k = 0; k < 3; ++k) {
        float x = 0, rows = 1;
        for (int i = 0; i < secs[k].n; ++i) {
            float w = TextSize(F_MED, 12.6f, secs[k].it[i].name).x + TP * 2;
            if (x > 0 && x + w > cw - PADC * 2) { rows += 1; x = 0; }
            x += w + GX;
        }
        hgt[k] = 32 + rows * CH + (rows - 1) * GY + PADC;
    }
    float HH = 44; for (float h : hgt) HH += h + 8;
    ImVec2 o = P(X0, Y0 + (1.0f - EaseOutCubic(a)) * 6.0f);
    ImRect r(o, o + ImVec2(X1 - X0, HH));
    if (g_ov.type == OV_ESPITEMS) g_ov.rect = r;
    Shadow(r, 10.0f, 14.0f, 0.6f, ImVec2(0, 3));
    Backdrop(r, 10.0f, 1.0f);
    DL->AddRectFilled(r.Min, r.Max, C(0x0F1016, 0.90f), 10.0f);
    DL->AddRect(r.Min, r.Max, C(0x1C1E25), 10.0f, 0, 1.0f);
    Text(F_SEMI, 14.0f, o + ImVec2(14, 0), o.y + 23.0f, C(0xE4E5EA), "ESP Items");
    float y = o.y + 42;
    for (int k = 0; k < 3; ++k) {
        ImRect card(ImVec2(o.x + 8, y), ImVec2(o.x + 8 + cw, y + hgt[k]));
        DL->AddRectFilled(card.Min, card.Max, C(0x14151B, 0.85f), 8.0f);
        DL->AddRect(card.Min, card.Max, C(0x191A21, 0.9f), 8.0f, 0, 1.0f);
        Text(F_SEMI, 13.0f, ImVec2(card.Min.x + 10, 0), y + 16.0f, C(0xDCDDE2), secs[k].t);
        float cx = card.Min.x + PADC, cy = y + 32;
        for (int i = 0; i < secs[k].n; ++i) {
            EspItem& it = secs[k].it[i];
            float w = TextSize(F_MED, 12.6f, it.name).x + TP * 2;
            if (cx > card.Min.x + PADC && cx + w > card.Max.x - PADC) { cx = card.Min.x + PADC; cy += CH + GY; }
            ImRect cr(ImVec2(cx, cy), ImVec2(cx + w, cy + CH));
            ImGuiID id = Id("espit", k * 32 + i);
            bool hov = Hover(cr, id, true) && !(g_ov.type == OV_COLOR && g_ovRectPrev.Contains(IN.m));
            float h = Anim(id, hov ? 1.0f : 0.0f, 16.0f);
            float on = Anim(id + 1, *it.v ? 1.0f : 0.0f, 14.0f);
            if (hov && IN.click) *it.v = !*it.v;
            if (hov && IN.rclick) {   // right click: colour picker, the panel stays under it
                if (g_ov.type == OV_ESPITEMS) { g_ovParent = g_ov; g_ovParent.open = true; g_ovParent.a = 1.0f; }
                if (g_ov.type == OV_COLOR && g_ov.open && g_ov.id == Id("esp_cp", it.ci)) { g_ov = g_ovParent; g_hasParent = false; g_active = 0; }   // same chip again: back to the panel
                else { g_hasParent = true; g_rcloseId = 0; OpenEspPicker(it.ci, cr, true); }
            }
            DL->AddRectFilled(cr.Min, cr.Max, C(Mix(Mix(0x18191F, 0x1F2128, h), Mix(0x22252E, 0x282B35, h), on)), 6.0f);
            if (on > 0.003f) DL->AddRect(cr.Min, cr.Max, C(ACCENT, 0.45f * on), 6.0f, 0, 1.0f);
            Text(F_MED, 12.6f, ImVec2(cx + TP, 0), cr.GetCenter().y, C(Mix(Mix(0x8F9199, 0xC9CAD0, h), 0xEEEFF3, on)), it.name);
            cx += w + GX;
        }
        y += hgt[k] + 8;
    }
    return r;
}

// ---- Limiters popup
static void DrawLimiters(float a)
{
    ImRect br = g_ov.opener;        // dots button (absolute)
    ImVec2 o = ImVec2(br.Max.x + 8, br.Min.y - 40);
    float slide = (1.0f - EaseOutCubic(a)) * 6.0f;
    o.y += slide;
    ImRect r(o, o + ImVec2(285, 162));
    g_ov.rect = r;
    ImRect ab(r.Min - ImVec2(4, 4), r.Max + ImVec2(4, 4)); (void)ab;
    Shadow(r, 9.0f, 12.0f, 0.55f, ImVec2(0, 2));
    Backdrop(r, 9.0f, 1.0f);
    DL->AddRectFilled(r.Min, r.Max, C(0x15141B, 0.80f), 9.0f);
    DL->AddRect(r.Min, r.Max, C(0x1D1C24, 0.95f), 9.0f, 0, 1.0f);
    Text(F_SEMI, 14.0f, o + ImVec2(15, 0), o.y + 21.5f, C(0xD9D8DD), "Smooth");
    ImRect inner(o + ImVec2(8, 42), o + ImVec2(277, 154));
    DL->AddRectFilled(inner.Min, inner.Max, C(0x131219, 0.80f), 7.0f);
    DL->AddRect(inner.Min, inner.Max, C(0x1B1A21, 0.95f), 7.0f);
    struct Row { const char* name; float* v; };
    Row rows[3] = { {"Aim Speed", &S.aimSpeed}, {"Near Target", &S.nearTarget}, {"Curve", &S.curve} };
    ImVec2 saveO = O; O = ImVec2(0, 0);   // use absolute coords inside popup helpers
    for (int i = 0; i < 3; ++i) {
        float top = inner.Min.y + 8 + 32.0f * i;
        ImRect rr(ImVec2(inner.Min.x + 8, top), ImVec2(inner.Max.x - 8, top + 32));
        ImGuiID id = Id("limrow", i);
        bool hov = Hover(rr, id, true) || (g_active == Id(rows[i].name));
        float h = Anim(id, hov ? 1.0f : 0.0f, 14.0f);
        if (h > 0.003f) DL->AddRectFilled(rr.Min, rr.Max, C(0x1D1C26, h * 0.9f), 5.0f);
        float cy = rr.GetCenter().y;
        Text(F_MED, 12.5f, ImVec2(rr.Min.x + 12, 0), cy, C(Mix(0xA3A2A9, 0xCFCED5, h)), rows[i].name);
        BarSlider(rows[i].name, rows[i].v, rr.Max.x - 113, cy, 101, h > 0.5f);
    }
    O = saveO;
}


// ---- profile popup (click on the profile in the sidebar)
struct ProfileCfg { int lang = 0, esp = 2, win = 1, units = 0; bool safe = false, sync = true; };
static ProfileCfg PF;
static bool g_unload = false;
static void WmDisable();
bool Menu_WantsUnload() { return g_unload; }
bool Menu_UnloadReady();
static const ImU32 THEME_PRESETS[] = { 0x9BB1E0, 0x8B7CF6, 0xE0457B, 0x45C28A, 0xF0A33C, 0xE5E5EA };
static const char* PctName(int i) { static const char* n[] = { "75%", "100%", "125%", "150%", "175%", "200%" }; return n[ImClamp(i, 0, 5)]; }
static float saveOy() { return g_snapO.y; }
// ---- "Enabled" popup (dots on MAIN > Enabled): Show FOV settings
static void CheckBox(const char* key, bool* v, ImVec2 c)
{
    ImGuiID id = Id(key);
    ImRect r(c - ImVec2(7.5f, 7.5f), c + ImVec2(7.5f, 7.5f));
    bool hov = Hover(ImRect(r.Min - ImVec2(4, 4), r.Max + ImVec2(4, 4)), id, true);
    if (hov && IN.click) *v = !*v;
    float t = Anim(id, *v ? 1.0f : 0.0f, 16.0f), h = Anim(id + 1, hov ? 1.0f : 0.0f, 16.0f);
    DL->AddRectFilled(r.Min, r.Max, C(Mix(Mix(0x0E1016, 0x15171E, h), ACCENT, t)), 4.0f);
    if (t < 0.999f) DL->AddRect(r.Min, r.Max, C(Mix(0x24262E, 0x30323B, h), 1.0f - t), 4.0f, 0, 1.0f);
    if (t > 0.01f) {
        ImVec2 pts[3] = { c + ImVec2(-3.6f, 0.2f), c + ImVec2(-1.1f, 2.8f), c + ImVec2(3.8f, -2.6f) };
        DL->AddPolyline(pts, 3, C(0xFFFFFF, t), 0, 1.7f);
    }
}
static ImRect DrawFovPopup(float a, ImRect br)
{
    ImVec2 o = ImVec2(br.Max.x + 8, br.Min.y - 40);
    o.y += (1.0f - EaseOutCubic(a)) * 6.0f;
    ImRect r(o, o + ImVec2(285, 98));
    Shadow(r, 9.0f, 12.0f, 0.55f, ImVec2(0, 2));
    Backdrop(r, 9.0f, 1.0f);
    DL->AddRectFilled(r.Min, r.Max, C(0x15141B, 0.80f), 9.0f);
    DL->AddRect(r.Min, r.Max, C(0x1D1C24, 0.95f), 9.0f, 0, 1.0f);
    Text(F_SEMI, 14.0f, o + ImVec2(15, 0), o.y + 21.5f, C(0xD9D8DD), "Enabled");
    ImRect inner(o + ImVec2(8, 42), o + ImVec2(277, 90));
    DL->AddRectFilled(inner.Min, inner.Max, C(0x131219, 0.80f), 7.0f);
    DL->AddRect(inner.Min, inner.Max, C(0x1B1A21, 0.95f), 7.0f);
    ImVec2 saveO = O; O = ImVec2(0, 0);   // absolute coords inside the popup
    bool saveIn = g_inOverlay; g_inOverlay = true;
    {   // Show FOV: colour (Fill / Thickness / Glow live in its colour picker) + switch
        ImRect rr(ImVec2(inner.Min.x + 8, inner.Min.y + 8), ImVec2(inner.Max.x - 8, inner.Min.y + 40));
        ImGuiID id = Id("fovrow", 0);
        bool hov = Hover(rr, id, true);
        float h = Anim(id, hov ? 1.0f : 0.0f, 14.0f);
        if (h > 0.003f) DL->AddRectFilled(rr.Min, rr.Max, C(0x1D1C26, h * 0.9f), 5.0f);
        float cy = rr.GetCenter().y;
        Text(F_MED, 12.5f, ImVec2(rr.Min.x + 12, 0), cy, C(Mix(0xC3C2C9, 0xDEDDE3, h)), "Show FOV");
        Swatch("fov_col", &S.fovCol, rr.Max.x - 60, cy, true);
        Toggle("fov_show", &S.showFov, rr.Max.x - 6, cy);
    }
    g_inOverlay = saveIn;
    O = saveO;
    return r;
}

// ---- FOV circle in the centre of the screen (drawn under the menu, visible with the menu closed too)
static void RingStrip(ImDrawList* dl, ImVec2 c, float r0, float r1, const Col& col, float a0, float a1, int N)
{
    if (r1 <= r0 || (a0 <= 0.0f && a1 <= 0.0f)) return;
    ImVec2 uv = dl->_Data->TexUvWhitePixel;
    dl->PrimReserve(N * 6, (N + 1) * 2);
    ImDrawIdx base = (ImDrawIdx)dl->_VtxCurrentIdx;
    for (int i = 0; i <= N; ++i) {
        float t = (float)i / N, ang = t * IM_PI * 2.0f;
        float g = col.grad ? 0.5f - 0.5f * cosf(ang) : 0.0f;   // conic: stop 1 -> stop 2 -> stop 1
        ImU32 rgb = Mix(col.c[0], col.c[1], g);
        float ca = ImLerp(col.a[0], col.a[1], g);
        ImVec2 d(cosf(ang - IM_PI * 0.5f), sinf(ang - IM_PI * 0.5f));
        dl->PrimWriteVtx(c + d * r0, uv, C(rgb, a0 * ca));
        dl->PrimWriteVtx(c + d * r1, uv, C(rgb, a1 * ca));
    }
    for (int i = 0; i < N; ++i) {
        ImDrawIdx k = (ImDrawIdx)(base + i * 2);
        dl->PrimWriteIdx(k); dl->PrimWriteIdx(k + 1); dl->PrimWriteIdx(k + 3);
        dl->PrimWriteIdx(k); dl->PrimWriteIdx(k + 3); dl->PrimWriteIdx(k + 2);
    }
}
static void DrawFovCircle()
{
    ImGuiIO& io = ImGui::GetIO();
    float vis = AnimS("fov_vis", (S.enabled && S.showFov && !g_unload) ? 1.0f : 0.0f, 10.0f);
    if (vis <= 0.003f) return;
    float rad = AnimS("fov_rad", S.fov / 180.0f * io.DisplaySize.y * 0.5f, 18.0f);
    if (rad < 1.0f) return;
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    ImVec2 c(floorf(io.DisplaySize.x * 0.5f) + 0.5f, floorf(io.DisplaySize.y * 0.5f) + 0.5f);
    int N = ImClamp((int)(rad * 0.6f), 64, 256);
    float th = 0.5f + S.fovThick * 5.5f;
    float glow = S.fovGlow * 22.0f;
    if (S.fovFill > 0.003f) RingStrip(dl, c, 0.0f, rad - th * 0.5f, S.fovCol, S.fovFill * 0.6f * vis, S.fovFill * 0.6f * vis, N);
    if (glow > 0.5f) {   // soft glow on both sides of the line
        int steps = 8;
        for (int k = 0; k < steps; ++k) {
            float t0 = (float)k / steps, t1 = (float)(k + 1) / steps;
            float ga = S.fovGlow * 0.55f * vis;
            float f0 = (1 - t0) * (1 - t0), f1 = (1 - t1) * (1 - t1);
            RingStrip(dl, c, rad + th * 0.5f + glow * t0, rad + th * 0.5f + glow * t1, S.fovCol, ga * f0, ga * f1, N);
            float i0 = ImMax(0.0f, rad - th * 0.5f - glow * 0.6f * t1), i1 = ImMax(0.0f, rad - th * 0.5f - glow * 0.6f * t0);
            RingStrip(dl, c, i0, i1, S.fovCol, ga * 0.7f * f1, ga * 0.7f * f0, N);
        }
    }
    // line with 1px anti-aliased edges
    RingStrip(dl, c, rad - th * 0.5f - 1.0f, rad - th * 0.5f, S.fovCol, 0.0f, vis, N);
    RingStrip(dl, c, rad - th * 0.5f, rad + th * 0.5f, S.fovCol, vis, vis, N);
    RingStrip(dl, c, rad + th * 0.5f, rad + th * 0.5f + 1.0f, S.fovCol, vis, 0.0f, N);
}

static void DrawProfilePopup(float a)
{
    (void)a;
    ImRect pr = g_ov.opener;
    const float W = 229.0f, H = 397.0f;
    ImVec2 o(pr.Max.x + 7.0f, floorf(pr.GetCenter().y - H * 0.5f + 0.5f));
    o.x -= (1.0f - EaseOutCubic(a)) * 6.0f;
    {   // keep the popup on screen (local space of the scaled menu)
        ImGuiIO& io = ImGui::GetIO();
        float top = saveOy(), bot = top + (io.DisplaySize.y - top) / g_dpi;
        float scrTop = top - top / g_dpi;  // screen y = 0 in local space
        o.y = ImClamp(o.y, scrTop + 8.0f, bot - H - 8.0f);
    }
    ImRect r(o, o + ImVec2(W, H));
    g_ov.rect = r;
    // (no shadow on the profile popup)
    Backdrop(r, 10.0f, 1.0f);                                   // blurred menu behind the popup
    DL->AddRectFilled(r.Min, r.Max, C(0x0D0E14, BG_ALPHA), 10.0f); // menu colour, see-through: blurred menu/game shows behind
    DL->AddRect(r.Min, r.Max, C(0x14161A), 10.0f, 0, 1.0f);
    ImVec2 saveO = O; O = ImVec2(0, 0);
    // header
    if (g_plat.avatarTex) DL->AddImageRounded(ImTextureRef(g_plat.avatarTex), o + ImVec2(19, 24), o + ImVec2(58, 63), ImVec2(0, 0), ImVec2(1, 1), C(0xFFFFFF), 19.5f);
    Text(F_MED, 12.5f, o + ImVec2(69, 0), o.y + 25.0f, C(0xE6E5EA), "Afraid");
    {
        static char till[64] = "";
        if (!till[0]) {
            time_t t = time(nullptr) + 7 * 24 * 3600; struct tm* tm = localtime(&t);
            static const char* mon[] = { "January","February","March","April","May","June","July","August","September","October","November","December" };
            if (tm) snprintf(till, sizeof(till), "Till: %s %d %d", mon[tm->tm_mon], tm->tm_mday, tm->tm_year + 1900); else snprintf(till, sizeof(till), "Till: -");
        }
        Text(F_MED, 12.5f, o + ImVec2(69, 0), o.y + 43.5f, C(0xDCDBE0), till);
        ImRect rn(o + ImVec2(67, 53), o + ImVec2(110, 70));
        float rh = Anim(Id("renew"), Hover(rn, Id("renew"), true) ? 1.0f : 0.0f, 14.0f);
        Text(F_MED, 12.0f, o + ImVec2(69, 0), o.y + 61.5f, C(Mix(0x66656C, 0xA9A8AF, rh)), "Renew");
    }
    // rows
    static const char* langs[] = { "English", "Russian" };
    static const char* units[] = { "Auto", "Metric", "Imperial" };
    struct Row { const char* icon; const char* name; float cy; int kind; };   // kind: 0 value, 1 style, 2 toggle, 3 plain
    Row rows[] = {
        { "\xef\x82\xac", "Language",        101.0f, 0 },   // globe
        { "\xef\xa2\x85", "Menu Scale",      133.5f, 0 },   // arrow-up-short-wide
        { "\xef\x80\xb4", "ESP Scale",       166.0f, 0 },   // text-height
        { "\xef\x8b\x92", "Windows Scale",   198.5f, 0 },   // window-restore
        { "\xef\x95\x86", "Units",           231.0f, 0 },   // ruler-combined
        { "\xef\x95\xb6", "Style",           263.5f, 1 },   // fill-drip
        { "\xef\x8f\xad", "Safe Mode",       303.0f, 0 },   // shield-halved
        { "\xef\x84\x88", "Synchronization", 335.5f, 2 },   // desktop
        { "\xef\x80\x91", "Unload",          375.0f, 4 },   // power-off
    };
    for (int i = 0; i < (int)IM_ARRAYSIZE(rows); ++i) {
        Row& rw = rows[i];
        float cy = o.y + rw.cy;
        ImRect rr(ImVec2(o.x + 7, cy - 15.5f), ImVec2(o.x + W - 9, cy + 15.5f));
        ImGuiID id = Id("pfrow", i);
        bool hov = Hover(rr, id, true);
        float h = Anim(id, hov ? 1.0f : 0.0f, 14.0f);
        if (h > 0.003f) DL->AddRectFilled(rr.Min, rr.Max, C(0x1E1E26, h * 0.95f), 6.0f);
        ImU32 hiC = rw.kind == 4 ? 0xF0646E : 0xEDEDF0;   // Unload turns red on hover
        Icon(rw.icon, 11.0f, ImVec2(o.x + 28, cy), C(Mix(0xC9C8CE, hiC, h)));
        Text(F_MED, 12.5f, ImVec2(o.x + 51, 0), cy, C(Mix(0xC4C3C9, hiC, h)), rw.name);
        if (rw.kind == 4 && hov && IN.click) { g_unload = true; g_ov.open = false; g_open = false; WmDisable(); }
        float rx = o.x + 209;
        bool click = hov && IN.click;
        if (rw.kind == 0) {
            const char* v = "";
            switch (i) {
            case 0: v = langs[PF.lang]; if (click) PF.lang = (PF.lang + 1) % 2; break;
            case 1: v = PctName(g_dpiIdx); if (click) { g_dpiIdx = (g_dpiIdx + 1) % 6; g_dpiTarget = 0.75f + 0.25f * g_dpiIdx; } break;
            case 2: v = PctName(PF.esp); if (click) PF.esp = (PF.esp + 1) % 6; break;
            case 3: v = PctName(PF.win); if (click) PF.win = (PF.win + 1) % 6; break;
            case 4: v = units[PF.units]; if (click) PF.units = (PF.units + 1) % 3; break;
            case 6: v = PF.safe ? "Enabled" : "Disabled"; if (click) PF.safe = !PF.safe; break;
            }
            ChevronRight(ImVec2(rx + 2 + h * 1.5f, cy), 3.5f, 8.0f, C(Mix(0xC9C8CE, 0xFFFFFF, h)), 1.5f);
            float tw = TextSize(F_MED, 12.5f, v).x;
            Text(F_MED, 12.5f, ImVec2(rx - 8 - tw, 0), cy, C(Mix(0xC4C3C9, 0xEDEDF0, h)), v);
        } else if (rw.kind == 1) {
            ImRect sw(ImVec2(rx - 12, cy - 8), ImVec2(rx + 4, cy + 8));
            DL->AddRectFilled(sw.Min, sw.Max, C(ACCENT), 4.0f);
            DL->AddRect(sw.Min, sw.Max, C(0xFFFFFF, 0.12f), 4.0f);
            static float spin = 0.0f; spin += g_dt * h * 2.0f;
            Icon("\xef\x80\x93", 11.0f, ImVec2(rx - 30, cy), C(Mix(0xC9C8CE, 0xFFFFFF, h)));   // gear
            if (click) {
                int k = 0; for (int j = 0; j < (int)IM_ARRAYSIZE(THEME_PRESETS); ++j) if (THEME_PRESETS[j] == ACCENT) k = j + 1;
                ACCENT = THEME_PRESETS[k % IM_ARRAYSIZE(THEME_PRESETS)];
            }
        } else if (rw.kind == 2) {
            if (click) PF.sync = !PF.sync;
            float e = EaseInOut(Anim(Id("pfsync"), PF.sync ? 1.0f : 0.0f, 14.0f));
            ImRect t(ImVec2(rx - 26, cy - 10), ImVec2(rx + 6, cy + 10));
            DL->AddRectFilled(t.Min, t.Max, C(Mix(0x06090F, ACCENT, e)), 10.0f);
            if (e < 0.999f) DL->AddRect(t.Min, t.Max, C(0x12151B, 1 - e), 10.0f);
            DL->AddCircleFilled(ImVec2(ImLerp(t.Min.x + 10, t.Max.x - 10, e), cy), 8.0f, C(Mix(0x7D8890, 0xFFFFFF, e)), 32);
        }
    }
    O = saveO;
}

// ---- dropdown list
static void DrawDropdown(float a)
{
    auto it = g_combos.find(g_ov.id);
    if (it == g_combos.end()) return;
    ComboDesc& d = it->second;
    const float IH = 31.0f, PAD = 7.0f, RND = 11.0f;   // row pitch, inner padding, corner radius (reference)
    const int vis = (d.maxVis > 0 && d.count > d.maxVis) ? d.maxVis : d.count;
    float contentH = d.count * IH + PAD * 2;
    float fullH = vis * IH + PAD * 2;
    static ImGuiID scFor = 0; static float sc = 0.0f, scT = 0.0f;
    if (scFor != g_ov.id) {   // opened: scroll so the selected row is visible
        scFor = g_ov.id; sc = scT = 0.0f;
        if (d.map && d.sel) for (int i = 0; i < d.count; ++i) if (d.map[i] == *d.sel) sc = scT = ImClamp((i - vis + 1.5f) * IH, 0.0f, contentH - fullH);
    }
    ImRect b = d.box;
    // multi select: check mark at the start of the row; the column for it opens only while something is selected
    bool anySel = false;
    if (d.multi) for (int i = 0; i < d.count; ++i) anySel |= d.multi[i];
    const float TX = 11.5f + 20.0f * EaseInOut(Anim(Id("dd_chkcol", (int)g_ov.id), anySel ? 1.0f : 0.0f, 14.0f));
    float w = ImMax(b.GetWidth(), 140.0f);
    for (int i = 0; i < d.count; ++i) w = ImMax(w, TextSize(F_MED, 12.5f, d.items[d.map ? d.map[i] : i]).x + (d.multi ? 31.5f : 11.5f) + 24.0f);
    float x = b.Min.x;
    bool up = !d.map && (b.Max.y + 4 + fullH) > (O.y + MENU_H - 6);
    float e = EaseOutCubic(a);
    float h = fullH * (0.6f + 0.4f * e);
    ImRect r = up ? ImRect(ImVec2(x, b.Min.y - 4 - h), ImVec2(x + w, b.Min.y - 4))
                  : ImRect(ImVec2(x, b.Max.y + 4), ImVec2(x + w, b.Max.y + 4 + h));
    g_ov.rect = up ? ImRect(ImVec2(x, b.Min.y - 4 - fullH), ImVec2(x + w, b.Min.y - 4)) : ImRect(ImVec2(x, b.Max.y + 4), ImVec2(x + w, b.Max.y + 4 + fullH));
    Shadow(r, RND, 14.0f, 0.6f, ImVec2(0, 3));
    Backdrop(r, RND, 1.0f);
    DL->AddRectFilled(r.Min, r.Max, C(0x141319, 0.86f), RND);
    DL->AddRect(r.Min, r.Max, C(0x1E1D25), RND);
    if (contentH > fullH) {
        if (g_ov.open && r.Contains(IN.m)) scT -= ImGui::GetIO().MouseWheel * IH * 1.5f;
        scT = ImClamp(scT, 0.0f, contentH - fullH);
        sc += (scT - sc) * (1.0f - expf(-20.0f * g_dt));
    } else sc = scT = 0.0f;
    DL->PushClipRect(ImVec2(r.Min.x, r.Min.y + 2), ImVec2(r.Max.x, r.Max.y - 2), true);
    for (int i = 0; i < d.count; ++i) {
        float top = (up ? r.Max.y - fullH : r.Min.y) + PAD + IH * i - sc;
        if (top + IH < r.Min.y || top > r.Max.y) continue;
        ImRect ir(ImVec2(r.Min.x + 6.5f, top + 0.5f), ImVec2(r.Max.x - 6.5f, top + IH - 0.5f));
        ImGuiID id = Id("dditem", (int)g_ov.id * 31 + i);
        const bool off = d.off && d.off[i];
        bool hov = !off && Hover(ir, id, true) && r.Contains(IN.m);
        const int val = d.map ? d.map[i] : i;
        bool sel = d.multi ? d.multi[i] : (d.sel && *d.sel == val);
        float hh = Anim(id, hov ? 1.0f : 0.0f, 18.0f);
        float ss = Anim(id + 1, sel ? 1.0f : 0.0f, 14.0f);
        if (hh > 0.003f) DL->AddRectFilled(ir.Min, ir.Max, C(0x1E1D25, hh), 6.0f);
        ImU32 tc = off ? 0x4E4D55 : Mix(Mix(0xBDBCC3, 0xD6D5DB, hh), 0xD6D5DB, ss);   // selected: soft white
        Text(F_MED, 12.5f, ImVec2(ir.Min.x + TX, 0), ir.GetCenter().y, C(tc), d.items[val]);
        if (d.multi && ss > 0.01f) {
            ImVec2 c(ir.Min.x + 15, ir.GetCenter().y);
            ImVec2 pts[3] = { c + ImVec2(-4, 0), c + ImVec2(-1.2f, 3), c + ImVec2(4, -3.2f) };
            DL->AddPolyline(pts, 3, C(0xD6D5DB, ss), 0, 1.6f);
        }
        if (hov && IN.click) {
            if (d.multi) d.multi[i] = !d.multi[i];
            else { if (d.sel) *d.sel = (d.map && sel) ? 0 : val; g_ov.open = false; }   // chams: selected again = off
        }
    }
    DL->PopClipRect();
    if (contentH > fullH) {   // scrollbar
        float th = ImMax(24.0f, (r.GetHeight() - 8) * fullH / contentH);
        float ty = r.Min.y + 4 + (r.GetHeight() - 8 - th) * (sc / (contentH - fullH));
        DL->AddRectFilled(ImVec2(r.Max.x - 5, ty), ImVec2(r.Max.x - 3, ty + th), C(0x3A3944, 0.9f), 1.0f);
    }
}


#include "misc_ui.inc"

// ---------------------------------------------------------------- watermark (always visible, configured in Debug)
struct WatermarkCfg {
    bool  enabled = false;
    int   pos = 0;                         // 0 bottom centre, 1 top centre, 2 top left, 3 top right
    bool  showLogo = true;
    int   kd = 18;
    bool  realFps = false; int fakeFps = 392;
    bool  showPing = true; int ping = 34;
    bool  showKd = true, showFps = true, showCloud = true, showAvatar = true;
    char  text[256] = ":sun: PREMIER CFG by gra1ncheats :arrow: NO VACLIVE | NICE VISUALS :check:";
};
static WatermarkCfg WM;
static void WmDisable() { WM.enabled = false; }
static ImRect g_wmRect; static bool g_wmBlurVis = false;
bool Menu_GetWmBackdrop(float* x, float* y, float* w, float* h) { if (!g_wmBlurVis) return false; *x = g_wmRect.Min.x; *y = g_wmRect.Min.y; *w = g_wmRect.GetWidth(); *h = g_wmRect.GetHeight(); return true; }
static float g_wmA = 0.0f; static ImVec2 g_wmPos(-1, -1); static float g_wmW = 0.0f;

// tokens -> coloured icons (FA6 solid)
struct WmTok { const char* name; const char* glyph; ImU32 col; ImU32 box; };
static const WmTok WM_TOKENS[] = {
    { ":sun:",   "\xef\x86\x85", 0xF2C14E, 0 },          // f185
    { ":arrow:", "\xef\x81\xa1", 0xFFFFFF, 0x2F8FE8 },   // f061 on blue square
    { ":check:", "\xef\x80\x8c", 0xFFFFFF, 0x36B65A },   // f00c on green square
    { ":cloud:", "\xef\x83\x82", 0xB9BDC6, 0 },          // f0c2
    { ":star:",  "\xef\x80\x85", 0xF2C14E, 0 },          // f005
    { ":fire:",  "\xef\x81\xad", 0xF27A3A, 0 },          // f06d
    { ":heart:", "\xef\x80\x84", 0xE8506A, 0 },          // f004
    { ":skull:", "\xef\x95\x8c", 0xC9CCD3, 0 },          // f54c
    { ":crown:", "\xef\x94\xa1", 0xF2C14E, 0 },          // f521
    { ":bolt:",  "\xef\x83\xa7", 0xF2C14E, 0 },          // f0e7
};

// draws (or measures, when dl == nullptr) the watermark contents starting at x; returns end x
static float WmContents(ImDrawList* dl, float x, float cy, float s, float a, float fps)
{
    const float FS = 15.0f * s, IS = 14.5f * s, GAP = 16.0f * s, IG = 8.0f * s;
    const ImU32 TXT = 0xB7B9BF;
    auto txt = [&](ImFont* f, float sz, const char* t, const char* te, ImU32 col) {
        float k = sz * K(f);
        ImVec2 ts = f->CalcTextSizeA(k, FLT_MAX, 0.0f, t, te);
        if (dl) {
            float asc = f->GetFontBaked(k)->Ascent;
            ImVec2 p(floorf(x + 0.5f), floorf(cy - asc + sz * (f == F_XB ? 0.727f : 0.714f) * 0.5f + 0.5f));
            dl->AddText(f, k, p + ImVec2(0, 1.0f * s), C(0x000000, a * 0.55f), t, te);   // drop shadow
            dl->AddText(f, k, p, C(col, a), t, te);
        }
        x += ts.x;
    };
    auto icon = [&](const char* g, float sz, ImU32 col, ImU32 box) {
        unsigned int cp = 0; ImTextCharFromUtf8(&cp, g, nullptr);
        float gsz = box ? sz * 0.72f : sz;
        const ImFontGlyph* gl = F_ICON->GetFontBaked(gsz)->FindGlyph((ImWchar)cp);
        float w = box ? sz : (gl ? gl->X1 - gl->X0 : sz);
        if (dl && gl) {
            ImVec2 c(x + w * 0.5f, cy);
            if (box) {
                dl->AddRectFilled(ImVec2(x, cy - w * 0.5f + 1.0f * s), ImVec2(x + w, cy + w * 0.5f + 1.0f * s), C(0x000000, a * 0.35f), 2.5f * s);
                dl->AddRectFilled(ImVec2(x, cy - w * 0.5f), ImVec2(x + w, cy + w * 0.5f), C(box, a), 2.5f * s);
            }
            ImVec2 p(floorf(c.x - (gl->X0 + gl->X1) * 0.5f + 0.5f), floorf(c.y - (gl->Y0 + gl->Y1) * 0.5f + 0.5f));
            if (!box) dl->AddText(F_ICON, gsz, p + ImVec2(0, 1.0f * s), C(0x000000, a * 0.5f), g);
            dl->AddText(F_ICON, gsz, p, C(col, a), g);
        }
        x += w;
    };
    // logo: the anime girl image (same texture as the menu logo)
    if (WM.showLogo && g_plat.logoTex) {
        float lh = 25.0f * s, lw = lh;
        if (dl) {
            dl->AddRectFilled(ImVec2(x, cy - lh * 0.5f + 1.0f * s), ImVec2(x + lw, cy + lh * 0.5f + 1.0f * s), C(0x000000, a * 0.35f), 5.0f * s);
            dl->AddImageRounded(ImTextureRef(g_plat.logoTex), ImVec2(x, cy - lh * 0.5f), ImVec2(x + lw, cy + lh * 0.5f), ImVec2(0.0278f, 0), ImVec2(0.9722f, 1), C(0xFFFFFF, a), 5.0f * s);   // square with slightly rounded corners
        }
        x += lw + GAP;
    }
    char buf[64];
    if (WM.showKd) {
        icon("\xef\x94\x9f", IS * 0.92f, ACCENT, 0); x += IG;                // compact-disc
        snprintf(buf, sizeof(buf), "%d KD", WM.kd); txt(F_MED, FS, buf, nullptr, TXT); x += GAP;
    }
    if (WM.showFps) {
        icon("\xee\x91\xb3", IS * 0.92f, ACCENT, 0); x += IG;                // chart-simple
        snprintf(buf, sizeof(buf), "%d FPS", (int)fps); txt(F_MED, FS, buf, nullptr, TXT); x += GAP;
    }
    if (WM.showPing) {
        static int pj = 0; static float pt = 0.0f; pt -= g_dt; if (pt <= 0.0f) { pt = 1.0f; pj = (rand() % 5) - 2; }
        icon("\xef\x87\xab", IS, ACCENT, 0); x += IG;                  // wifi
        snprintf(buf, sizeof(buf), "%d ms", ImMax(1, WM.ping + pj)); txt(F_MED, FS, buf, nullptr, TXT); x += GAP;
    }
    if (WM.showCloud) { icon("\xef\x83\x82", IS * 1.1f, ACCENT, 0); x += GAP; }
    const char* p = WM.text; bool any = false;
    while (*p) {
        const WmTok* tk = nullptr;
        if (*p == ':') for (const WmTok& t : WM_TOKENS) if (strncmp(p, t.name, strlen(t.name)) == 0) { tk = &t; break; }
        if (tk) {
            if (tk->box) icon(tk->glyph, IS, 0xFFFFFF, ACCENT); else icon(tk->glyph, IS, ACCENT, 0);   // icons follow the menu theme
            p += strlen(tk->name); any = true; continue;
        }
        const char* e = p + 1;
        for (;;) {
            while (*e && *e != ':') ++e;
            if (!*e) break;
            bool isTok = false; for (const WmTok& t : WM_TOKENS) if (strncmp(e, t.name, strlen(t.name)) == 0) isTok = true;
            if (isTok) break; ++e;
        }
        txt(F_MED, FS, p, e, TXT); p = e; any = true;
    }
    if (any) x += GAP;
    if (WM.showAvatar && g_plat.avatarTex) {
        float as = 22.0f * s;
        if (dl) {
            dl->AddRectFilled(ImVec2(x, cy - as * 0.5f + 1.0f * s), ImVec2(x + as, cy + as * 0.5f + 1.0f * s), C(0x000000, a * 0.35f), as * 0.5f);
            dl->AddImageRounded(ImTextureRef(g_plat.avatarTex), ImVec2(x, cy - as * 0.5f), ImVec2(x + as, cy + as * 0.5f), ImVec2(0, 0), ImVec2(1, 1), C(0xFFFFFF, a), as * 0.5f);
        }
        x += as + GAP;
    }
    return x - GAP;
}

// ---------------------------------------------------------------- fake weapon and hands (first-person AKR viewmodel, configured in Debug)
static ImTextureData* g_fpvTex = nullptr;
static std::mutex g_fpvMx; static std::condition_variable g_fpvCv;
static bool g_fpvJob = false, g_fpvBusy = false, g_fpvReady = false, g_fpvThread = false;
static M3DSettings g_fpvJobS; static int g_fpvJobW = 0, g_fpvJobH = 0;
struct FpvImg { std::vector<uint8_t> px; int w = 0, h = 0, x = 0, y = 0; };
static FpvImg g_fpvDone; static int g_fpvShowW = 0, g_fpvShowH = 0, g_fpvShowX = 0, g_fpvShowY = 0;
static float g_fpvT = 0.0f, g_fpvA = 0.0f;
// renders only the screen rectangle the arms cover, supersampled (SSxSS samples per pixel) and box-filtered down -> smooth edges
static void FpvRender(M3DSettings s, int DW, int DH, FpvImg& img, std::vector<uint8_t>& hi)
{
    float bb[4]; img.w = img.h = 0;
    if (!M3D_FpBounds(s, DW, DH, bb)) return;
    int x0 = ImMax(0, (int)floorf(bb[0]) - 3), y0 = ImMax(0, (int)floorf(bb[1]) - 3);
    int x1 = ImMin(DW, (int)ceilf(bb[2]) + 3), y1 = ImMin(DH, (int)ceilf(bb[3]) + 3);
    int w = x1 - x0, h = y1 - y0; if (w <= 0 || h <= 0) return;
    const int SS = (w * h <= 360000) ? 3 : 2;
    s.fpView[0] = (float)(x0 * SS); s.fpView[1] = (float)(y0 * SS); s.fpView[2] = (float)(DW * SS); s.fpView[3] = (float)(DH * SS);
    int HW = w * SS, HH = h * SS;
    hi.resize((size_t)HW * HH * 4);
    M3DOut o; M3D_Render(hi.data(), HW, HH, s, &o);
    img.px.resize((size_t)w * h * 4); img.w = w; img.h = h; img.x = x0; img.y = y0;
    const float inv = 1.0f / (SS * SS);
    for (int y = 0; y < h; ++y) for (int x = 0; x < w; ++x) {
        float r = 0, g = 0, b = 0, a = 0;
        for (int j = 0; j < SS; ++j) {
            const uint8_t* p = &hi[(((size_t)(y * SS + j)) * HW + x * SS) * 4];
            for (int i = 0; i < SS; ++i, p += 4) { float al = p[3]; r += p[0] * al; g += p[1] * al; b += p[2] * al; a += al; }
        }
        uint8_t* d = &img.px[((size_t)y * w + x) * 4];
        if (a <= 0) { d[0] = d[1] = d[2] = d[3] = 0; continue; }
        d[0] = (uint8_t)(r / a + 0.5f); d[1] = (uint8_t)(g / a + 0.5f); d[2] = (uint8_t)(b / a + 0.5f); d[3] = (uint8_t)(a * inv + 0.5f);
    }
}
static void FpvWorker()
{
    std::vector<uint8_t> hi; FpvImg img;
    for (;;) {
        M3DSettings js; int w, h;
        { std::unique_lock<std::mutex> lk(g_fpvMx); g_fpvCv.wait(lk, [] { return g_fpvJob; }); js = g_fpvJobS; w = g_fpvJobW; h = g_fpvJobH; g_fpvJob = false; }
        FpvRender(js, w, h, img, hi);
        std::lock_guard<std::mutex> lk(g_fpvMx);
        std::swap(g_fpvDone, img); g_fpvReady = true; g_fpvBusy = false;
    }
}
static void DrawFakeViewmodel()
{
    ImGuiIO& io = ImGui::GetIO();
    g_fpvA = ImClamp(g_fpvA + (FPV.enabled ? 1 : -1) * g_dt * 6.0f, 0.0f, 1.0f);
    if (g_fpvA <= 0.0f || io.DisplaySize.x < 16 || io.DisplaySize.y < 16) return;
    g_fpvT += g_dt;
    int W = (int)io.DisplaySize.x, H = (int)io.DisplaySize.y;   // native resolution (only the arms' rectangle is rendered)
    M3DSettings s; s.model = M3D_MODEL_FP; s.anim = g_fpvT; s.time = g_fpvT;
    s.mat = CHAMS_MAP[ImClamp(FPV.chams, 0, (int)IM_ARRAYSIZE(CHAMS_MAP) - 1)];
    for (int i = 0; i < 4; ++i) s.col[i] = FPV.col[i];
    for (int i = 0; i < 3; ++i) s.fpOff[i] = FPV.off[i];
    s.fov = FPV.fov;
    bool fresh = false;
    M3D_Init();
    if (g_mdlSync) {   // preview harness: render in place
        static std::vector<uint8_t> hi; FpvRender(s, W, H, g_fpvDone, hi); fresh = true;
    } else {
        if (!g_fpvThread) { g_fpvThread = true; std::thread(FpvWorker).detach(); }
        std::lock_guard<std::mutex> lk(g_fpvMx);
        if (!g_fpvBusy) { g_fpvJobS = s; g_fpvJobW = W; g_fpvJobH = H; g_fpvJob = true; g_fpvBusy = true; g_fpvCv.notify_one(); }
        if (g_fpvReady) { g_fpvReady = false; fresh = true; }
    }
    if (fresh) {
        if (!g_mdlSync) g_fpvMx.lock();
        const FpvImg& im = g_fpvDone;
        if (im.w > 0 && im.h > 0) {
            static ImVector<ImTextureData*> retired;   // old textures: freed by the backend, then released here
            for (int i = 0; i < retired.Size; ++i) if (retired[i]->Status == ImTextureStatus_Destroyed) { ImGui::UnregisterUserTexture(retired[i]); IM_DELETE(retired[i]); retired.erase(retired.Data + i); --i; }
            if (g_fpvTex && (g_fpvTex->Width < im.w || g_fpvTex->Height < im.h)) { g_fpvTex->SetStatus(ImTextureStatus_WantDestroy); retired.push_back(g_fpvTex); g_fpvTex = nullptr; }   // grow-only texture
            if (!g_fpvTex) { g_fpvTex = IM_NEW(ImTextureData)(); g_fpvTex->Create(ImTextureFormat_RGBA32, ImMax(W, im.w), ImMax(H, im.h)); ImGui::RegisterUserTexture(g_fpvTex); }
            for (int y = 0; y < im.h; ++y) memcpy(g_fpvTex->GetPixelsAt(0, y), &im.px[(size_t)y * im.w * 4], (size_t)im.w * 4);
            g_fpvShowW = im.w; g_fpvShowH = im.h; g_fpvShowX = im.x; g_fpvShowY = im.y;
            if (g_fpvTex->Status == ImTextureStatus_OK || g_fpvTex->Status == ImTextureStatus_WantUpdates) {
                ImTextureRect r = { 0, 0, (unsigned short)im.w, (unsigned short)im.h };
                g_fpvTex->Updates.resize(0); g_fpvTex->Updates.push_back(r); g_fpvTex->UpdateRect = r; g_fpvTex->UsedRect = r;
                g_fpvTex->SetStatus(ImTextureStatus_WantUpdates);
            }
        } else g_fpvShowW = 0;
        if (!g_mdlSync) g_fpvMx.unlock();
    }
    if (g_fpvTex && g_fpvShowW > 0) {
        ImVec2 p0((float)g_fpvShowX, (float)g_fpvShowY), p1 = p0 + ImVec2((float)g_fpvShowW, (float)g_fpvShowH);
        ImGui::GetBackgroundDrawList()->AddImage(g_fpvTex->GetTexRef(), p0, p1, ImVec2(0, 0), ImVec2((float)g_fpvShowW / g_fpvTex->Width, (float)g_fpvShowH / g_fpvTex->Height), IM_COL32(255, 255, 255, (int)(255 * g_fpvA)));
    }
}
static void DebugFakeViewmodelUI()
{
    if (!ImGui::CollapsingHeader("Fake weapon and hands", ImGuiTreeNodeFlags_DefaultOpen)) return;
    ImGui::Checkbox("Enabled##fpv", &FPV.enabled);
    static const char* names[IM_ARRAYSIZE(CHAMS_MAP)];
    for (int i = 0; i < (int)IM_ARRAYSIZE(CHAMS_MAP); ++i) names[i] = CHAMS_MAP[i] == 0 ? "Textured" : MODEL_ITEMS[CHAMS_MAP[i]];
    ImGui::SetNextItemWidth(160); ImGui::Combo("Chams##fpv", &FPV.chams, names, IM_ARRAYSIZE(CHAMS_MAP));
    ImGui::SetNextItemWidth(160); ImGui::ColorEdit4("Color##fpv", FPV.col, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_PickerHueWheel | ImGuiColorEditFlags_AlphaBar);
    ImGui::SetNextItemWidth(160); ImGui::SliderFloat("X##fpv", &FPV.off[0], -0.4f, 0.4f, "%.3f");
    ImGui::SetNextItemWidth(160); ImGui::SliderFloat("Y##fpv", &FPV.off[1], -0.4f, 0.4f, "%.3f");
    ImGui::SetNextItemWidth(160); ImGui::SliderFloat("Z##fpv", &FPV.off[2], -0.3f, 0.5f, "%.3f");
    ImGui::SetNextItemWidth(160); ImGui::SliderFloat("FOV##fpv", &FPV.fov, 40.0f, 90.0f, "%.0f");
    if (ImGui::SmallButton("Reset##fpv")) { bool en = FPV.enabled; int ch = FPV.chams; float c[4]; memcpy(c, FPV.col, sizeof c); FPV = FpvCfg(); FPV.enabled = en; FPV.chams = ch; memcpy(FPV.col, c, sizeof c); }
}
static void DrawWatermark()
{
    ImGuiIO& io = ImGui::GetIO();
    g_wmA = ImClamp(g_wmA + (WM.enabled ? 1 : -1) * g_dt * 5.0f, 0.0f, 1.0f);
    g_wmBlurVis = false;
    if (g_wmA <= 0.0f) return;
    static float fpsShown = 0.0f, fpsTimer = 0.0f; static int jitter = 0;
    fpsTimer -= g_dt;
    if (fpsTimer <= 0.0f) { fpsTimer = 0.5f; jitter = (rand() % 13) - 6; fpsShown = WM.realFps ? io.Framerate : (float)ImMax(1, WM.fakeFps + jitter); }
    float s = g_dpi;
    float a = g_wmA * g_wmA * (3 - 2 * g_wmA);
    float H = 39.0f * s, PADL = 7.0f * s, PADR = 8.5f * s, RND = H * 0.5f;
    float w = WmContents(nullptr, 0, 0, s, a, fpsShown) + PADL + PADR;
    if (g_wmW <= 0) g_wmW = w;
    g_wmW += (w - g_wmW) * (1.0f - expf(-18.0f * g_dt));
    float M = 16.0f * s;
    ImVec2 tgt;
    switch (WM.pos) {
    default:
    case 0: tgt = ImVec2((io.DisplaySize.x - g_wmW) * 0.5f, io.DisplaySize.y - H - 48.0f * s); break;
    case 1: tgt = ImVec2((io.DisplaySize.x - g_wmW) * 0.5f, M); break;
    case 2: tgt = ImVec2(M, M); break;
    case 3: tgt = ImVec2(io.DisplaySize.x - g_wmW - M, M); break;
    }
    if (g_wmPos.x < 0) g_wmPos = tgt;
    g_wmPos = g_wmPos + (tgt - g_wmPos) * (1.0f - expf(-14.0f * g_dt));
    ImVec2 mn(floorf(g_wmPos.x + 0.5f), floorf(g_wmPos.y + 0.5f)), mx(mn.x + floorf(g_wmW + 0.5f), mn.y + H);
    mn.y += (1.0f - a) * 6.0f * s; mx.y += (1.0f - a) * 6.0f * s;   // slide in
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    // Figma: drop shadow (offset 0, blur sigma 6, black 100%, outside only) -> exact gaussian falloff as 1px rings
    {
        const float sig = 6.0f * s; const int N = (int)ceilf(sig * 3.0f);
        for (int i = 0; i < N; ++i) {
            float d = i + 0.5f;
            float al = 0.5f * erfcf(d / (sig * 1.41421356f));
            dl->AddRect(mn - ImVec2(d, d), mx + ImVec2(d, d), C(0x000000, a * al), RND + d, 0, 1.0f);
        }
    }
    // Figma: fill #080B11 @ 71% over a 21.1 background blur (blur window placed under the overlay by the host)
    dl->AddRectFilled(mn, mx, C(0x080B11, a * 0.71f), RND);
    g_wmRect = ImRect(mn, mx); g_wmBlurVis = a > 0.5f;
    dl->PushClipRect(mn - ImVec2(4, 4), mx + ImVec2(4, 4), true);
    WmContents(dl, mn.x + PADL, mn.y + H * 0.5f, s, a, fpsShown);
    dl->PopClipRect();
}

bool Menu_UnloadReady() { return g_unload && g_wmA <= 0.0f && !Menu_IsVisible(); }
static void DebugWatermarkUI()
{
    if (!ImGui::CollapsingHeader("Watermark", ImGuiTreeNodeFlags_DefaultOpen)) return;
    static const char* posNames[] = { "Bottom center", "Top center", "Top left", "Top right" };
    ImGui::Checkbox("Enabled", &WM.enabled);
    ImGui::SetNextItemWidth(130); ImGui::Combo("Position", &WM.pos, posNames, IM_ARRAYSIZE(posNames));
    ImGui::Checkbox("Logo", &WM.showLogo);
    ImGui::Checkbox("KD", &WM.showKd); ImGui::SameLine(); ImGui::SetNextItemWidth(80); ImGui::InputInt("##kd", &WM.kd, 1, 5);
    ImGui::Checkbox("FPS", &WM.showFps); ImGui::SameLine(); ImGui::Checkbox("Real", &WM.realFps);
    if (!WM.realFps) { ImGui::SameLine(); ImGui::SetNextItemWidth(70); ImGui::DragInt("##fps", &WM.fakeFps, 1.0f, 1, 999); }
    ImGui::Checkbox("Ping", &WM.showPing); ImGui::SameLine(); ImGui::SetNextItemWidth(80); ImGui::DragInt("##ping", &WM.ping, 0.5f, 1, 999, "%d ms");
    ImGui::Checkbox("Cloud", &WM.showCloud); ImGui::SameLine(); ImGui::Checkbox("Avatar", &WM.showAvatar);
    ImGui::TextUnformatted("Text");
    ImGui::SetNextItemWidth(-1); ImGui::InputText("##wmtext", WM.text, sizeof(WM.text));
    ImGui::TextDisabled(":sun: :arrow: :check: :cloud: :star:\n:fire: :heart: :skull: :crown: :bolt:");
}

// ---------------------------------------------------------------- crosshair watermark (under the crosshair, configured in Debug)
struct XhCfg { bool enabled = false; float size = 1.0f, x = 0.0f, y = 0.0f, z = 1.0f; };
static XhCfg XH;
static bool g_keyLmb = false, g_keyRmb = false, g_keyW = false, g_keyA = false, g_keyS = false, g_keyD = false, g_keySpace = false;
void Menu_SetGameKeys(bool lmb, bool rmb, bool w, bool a, bool s, bool d, bool space) { g_keyLmb = lmb; g_keyRmb = rmb; g_keyW = w; g_keyA = a; g_keyS = s; g_keyD = d; g_keySpace = space; }
static void ItalicText(ImDrawList* dl, ImFont* f, float size, ImVec2 pos, ImU32 col, const char* t, float slant)
{
    int v0 = dl->VtxBuffer.Size;
    dl->AddText(f, size, pos, col, t);
    float base = pos.y + size * 0.75f;
    for (int i = v0; i < dl->VtxBuffer.Size; ++i) dl->VtxBuffer[i].pos.x += (base - dl->VtxBuffer[i].pos.y) * slant;
}
static void DrawCrosshairWm()
{
    static float fill = 1.0f, fillShown = 1.0f; static bool prevRmb = false, prevLmb = false;
    static int state = 0, prevState = 0; static float stT = 1.0f;
    float vis = AnimS("xh_vis", (XH.enabled && !g_unload) ? 1.0f : 0.0f, 10.0f);
    // right mouse: bar empties, then refills smoothly over 4 s (every press resets it)
    if (g_keyRmb && !prevRmb) fill = 0.0f;
    if (g_keyLmb && !prevLmb && !g_wantMousePrev) fill = 0.0f;   // shots (not clicks on the menu)
    prevRmb = g_keyRmb; prevLmb = g_keyLmb;
    fill = ImMin(1.0f, fill + g_dt / 4.0f);
    float target = fill * fill * (3.0f - 2.0f * fill);                       // smoothstep
    fillShown += (target - fillShown) * (1.0f - expf(-(target < fillShown ? 22.0f : 12.0f) * g_dt));
    // movement state
    int st = g_keySpace ? 5 : g_keyW ? 1 : g_keyS ? 2 : g_keyA ? 3 : g_keyD ? 4 : 0;
    if (st != state) { prevState = state; state = st; stT = 0.0f; }
    stT = ImMin(1.0f, stT + g_dt * 7.0f);
    if (vis <= 0.003f) return;
    static const char* ST[6] = { "idle", "running", "walking", "left", "right", "jumping" };

    ImGuiIO& io = ImGui::GetIO();
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    float s = XH.size, gap = XH.z;
    ImVec2 c(floorf(io.DisplaySize.x * 0.5f + XH.x), floorf(io.DisplaySize.y * 0.5f + XH.y));
    // title (pixel font, fake-bold, flowing theme gradient, black outline)
    const char* title = "Anesthysia";
    float fs = 13.0f * ImMax(1.0f, floorf(s + 0.25f));   // pixel font: integer multiples stay crisp
    float px = fs / 13.0f;
    ImVec2 tw = F_PIX->CalcTextSizeA(fs, FLT_MAX, 0.0f, title); tw.x += px;
    {   // right mouse (scoped): slide the whole block to the left of the crosshair line
        float sh = AnimS("xh_scope", g_keyRmb ? 1.0f : 0.0f, 12.0f);
        float half = ImMax(tw.x, F_PIX->CalcTextSizeA(fs, FLT_MAX, 0.0f, "jumping").x) * 0.5f;
        c.x = floorf(c.x - sh * (half + 12.0f * px) + 0.5f);
    }
    float ty = c.y + floorf(16.0f * s * gap);
    ImVec2 tp(floorf(c.x - tw.x * 0.5f), ty);
    ImU32 light = Mix(ACCENT, 0xFFFFFF, 0.45f);
    {
        static const ImVec2 d[12] = { {-1,0},{2,0},{0,-1},{1,-1},{0,1},{1,1},{-1,-1},{2,-1},{-1,1},{2,1},{0,0},{0,0} };
        for (int k = 0; k < 10; ++k) dl->AddText(F_PIX, fs, tp + d[k] * px, C(0x000000, 0.9f * vis), title);
        int v0 = dl->VtxBuffer.Size;
        dl->AddText(F_PIX, fs, tp, C(0xFFFFFF, vis), title);
        dl->AddText(F_PIX, fs, tp + ImVec2(px, 0), C(0xFFFFFF, vis), title);
        static float flow = 0.0f; flow += g_dt * 0.35f;
        ImU32 hi = Mix(ACCENT, 0xFFFFFF, 0.75f);
        float x0 = tp.x, w = ImMax(tw.x, 1.0f);
        for (int i = v0; i < dl->VtxBuffer.Size; ++i) {
            ImDrawVert& v = dl->VtxBuffer[i];
            float t = (v.pos.x - x0) / w - flow;
            float k = 0.5f + 0.5f * cosf(t * IM_PI * 2.0f);
            int a8 = (v.col >> IM_COL32_A_SHIFT) & 0xFF;
            v.col = C(Mix(ACCENT, hi, k), a8 / 255.0f);
        }
    }
    // bar under the title (2px black outline)
    float bw = floorf(tw.x), bh = ImMax(2.0f, floorf(2.0f * px + 0.5f));
    float by0 = ty + floorf(fs) + floorf(2.0f * s * gap);
    ImRect bar(ImVec2(floorf(c.x - bw * 0.5f), by0), ImVec2(floorf(c.x - bw * 0.5f) + bw, by0 + bh));
    float ol = 2.0f * px;
    dl->AddRectFilled(bar.Min - ImVec2(ol, ol), bar.Max + ImVec2(ol, ol), C(0x000000, 0.9f * vis));
    dl->AddRectFilled(bar.Min, bar.Max, C(0x15161B, 0.9f * vis));
    if (fillShown > 0.002f) {
        float fx = floorf(bar.Min.x + bw * fillShown + 0.5f);
        int v0 = dl->VtxBuffer.Size;
        dl->AddRectFilled(bar.Min, ImVec2(fx, bar.Max.y), C(0xFFFFFF, vis));
        ImGui::ShadeVertsLinearColorGradientKeepAlpha(dl, v0, dl->VtxBuffer.Size, bar.Min, ImVec2(bar.Max.x, bar.Min.y), C(ACCENT), C(light));
    }
    // state line (cross-fades + slides on change) and DMG line
    float ly = bar.Max.y + ol + floorf(3.0f * s * gap);
    auto line = [&](const char* t, float y, ImU32 col, float a, float dx) {
        ImVec2 sz = F_PIX->CalcTextSizeA(fs, FLT_MAX, 0.0f, t);
        ImVec2 p(floorf(c.x - sz.x * 0.5f + dx), floorf(y));
        float o = fs / 13.0f;
        for (int k = 0; k < 8; ++k) {   // 1px black outline (cheat style)
            static const ImVec2 d[8] = { {-1,0},{1,0},{0,-1},{0,1},{-1,-1},{1,-1},{-1,1},{1,1} };
            dl->AddText(F_PIX, fs, p + d[k] * o, C(0x000000, 0.85f * a * vis), t);
        }
        dl->AddText(F_PIX, fs, p, C(col, a * vis), t);
    };
    float e = EaseOutCubic(stT);
    if (e < 1.0f) line(ST[prevState], ly - e * 4.0f * s, 0xFFFFFF, 1.0f - e, 0);
    line(ST[state], ly + (1.0f - e) * 4.0f * s, 0xFFFFFF, e, 0);
    char dmg[32]; snprintf(dmg, sizeof dmg, "Min %d", (int)(S.minDamage + 0.5f));
    line(dmg, ly + floorf(fs + 1.0f + 1.0f * s * gap), Mix(ACCENT, 0xFFFFFF, 0.2f), 1.0f, 0);
}
static void DebugCrosshairUI()
{
    if (!ImGui::CollapsingHeader("Watermark crosshair", ImGuiTreeNodeFlags_DefaultOpen)) return;
    ImGui::Checkbox("Enabled##xh", &XH.enabled);
    ImGui::SetNextItemWidth(160); ImGui::SliderFloat("Size##xh", &XH.size, 0.5f, 2.5f, "%.2f");
    ImGui::SetNextItemWidth(160); ImGui::SliderFloat("X##xh", &XH.x, -400.0f, 400.0f, "%.0f");
    ImGui::SetNextItemWidth(160); ImGui::SliderFloat("Y##xh", &XH.y, -400.0f, 400.0f, "%.0f");
    ImGui::SetNextItemWidth(160); ImGui::SliderFloat("Z##xh", &XH.z, 0.3f, 3.0f, "%.2f");
    if (ImGui::SmallButton("Reset##xh")) { bool en = XH.enabled; XH = XhCfg(); XH.enabled = en; }
}

// ---------------------------------------------------------------- frame
void Menu_Toggle() { if (g_boot != 2) return; g_open = !g_open; if (!g_open) { g_ov.open = false; g_active = 0; g_dragging = false; } }
bool Menu_IsVisible() { return g_open || g_openA > 0.001f || g_boot == 1; }
bool Menu_WantsMouse() { return g_wantMouse; }
bool Menu_GetBackdrop(float* x, float* y, float* w, float* h, float* r)
{
    if (!Menu_IsVisible() || !g_backdropVisible) return false;
    *x = g_backdrop.Min.x; *y = g_backdrop.Min.y; *w = g_backdrop.GetWidth(); *h = g_backdrop.GetHeight(); *r = g_boot == 1 ? 23.0f * g_dpiTarget : MENU_ROUND * g_dpi;
    return true;
}
void Menu_DebugOpenLimiters() { O = g_pos; OpenOverlay(OV_LIMITERS, Id("limiters"), R(405, 85 + 39 * 3 + 20 - 11.5f, 427, 85 + 39 * 3 + 20 + 12.5f)); g_ov.a = 1.0f; }
void Menu_SetDpiScale(float s) { g_dpi = g_dpiTarget = s; g_dpiIdx = (int)floorf((s - 0.75f) / 0.25f + 0.5f); }
void Menu_DebugSetTab(int t, int group) { g_tab = t; g_plGroup = group; g_shownPage = PageKey(); g_pageFade = 1.0f;
    if (const char* e = getenv("INVPOP")) { int k = atoi(e); OpenSkins(k >= 10 ? 0 : k, k >= 10 ? k - 10 : 0, R(0, 0, 1, 1)); g_ov.a = 1.0f; if (getenv("INVQ")) snprintf(g_skSearch, sizeof g_skSearch, "%s", getenv("INVQ")); if (getenv("INVDROP")) g_skDrop = atoi(getenv("INVDROP")); }
    if (getenv("INVTEAM")) { InvInit(); g_invSlot[0] = 1; InvSyncTeam(); }
    for (const char* ev : { "INVITEM", "INVITEM2" }) if (const char* e = getenv(ev)) { InvInit(); int i = atoi(e); if (i >= 0 && i < INV_N) { const InvItem& it = INV_ITEMS[i]; if (it.cat == 0) { for (int k = 0; k < 15; ++k) if (!strcmp(it.weapon, INV_LOAD[k])) g_invEq[k] = i; } else for (int s2 = 1; s2 < 6; ++s2) if (INV_SLOT_CAT[s2] == it.cat) g_invSlot[s2] = i; } }
    if (getenv("INVEQ")) { InvInit(); for (int k = 0; k < 15; ++k) for (int i = INV_N - 1; i >= 0; --i) if (INV_ITEMS[i].cat == 0 && INV_ITEMS[i].rar >= 3 && !strcmp(INV_ITEMS[i].weapon, INV_LOAD[k])) { g_invEq[k] = i; break; } for (int s2 = 1; s2 < 6; ++s2) for (int i = 0; i < INV_N; ++i) if (INV_ITEMS[i].cat == INV_SLOT_CAT[s2]) { g_invSlot[s2] = i; break; } }
}
void Menu_SetPos(float x, float y) { g_pos = g_posTarget = ImVec2(x, y); g_posInit = true; }
// offline preview: open a Miscellaneous / presets popup (MSPOP=1 Air Strafe, 2 Hit Sound, 3 presets, 4 Log Events)
static void MsDebugPopup()
{
    static bool done = false; if (done) return; done = true;
    const char* e = getenv("MSPOP"); if (!e) return;
    if (getenv("MSDEMO")) { MS.superToss = MS.autoBuy = MS.autoGrenade = MS.hitSound = true; MS.logEv[0] = MS.logEv[1] = MS.logEv[2] = true; MS.hsEvent[0] = 2; MS.hsEvent[2] = 0; MS.asSubtick = true; }
    int k = atoi(e);
    if (k == 1) OpenOverlay(OV_AIRSTRAFE, Id("ms_as_dots"), R(405, RowCY(85, 1) - 11.5f, 427, RowCY(85, 1) + 12.5f));
    if (k == 2) OpenOverlay(OV_HITSOUND, Id("ms_hs_dots"), R(711, RowCY(85, 4) - 11.5f, 733, RowCY(85, 4) + 12.5f));
    if (k == 3) OpenOverlay(OV_CONFIG, Id("cfg"), R(180, 13, 379, 43));
    if (k == 4) OpenOverlay(OV_COMBO, Id("ms_log"), R(640, RowCY(85, 8) - 12, 772, RowCY(85, 8) + 12));
    if (k == 10) OpenOverlay(OV_FLYHACK, Id("ms_jb_dots"), R(405, RowCY(85, 2) - 11.5f, 427, RowCY(85, 2) + 12.5f));
    if (k == 9) OpenOverlay(OV_IDEBUG, Id("ms_sw_dots"), R(405, RowCY(85, 7) - 11.5f, 427, RowCY(85, 7) + 12.5f));
    if (k == 7 || k == 8) {
        if (k == 8) S.hitboxes[0] = S.hitboxes[1] = true;
        OpenOverlay(OV_COMBO, Id("hitboxes"), R(331, RowCY(356, 0) - 12, 466, RowCY(356, 0) + 12));
    }
    if (k == 5 || k == 6) {
        ImRect br = R(405, RowCY(85, 0) - 11.5f, 427, RowCY(85, 0) + 12.5f);
        S.enabled = S.showFov = true;
        OpenOverlay(OV_FOVPOP, Id("fovpop"), br); g_ov.a = 1.0f;
        if (k == 6) {
            ImVec2 sc(br.Max.x + 8 + 209, br.Min.y - 40 + 66);
            g_ovParent = g_ov; g_hasParent = true; g_espCPIdx = -1;
            g_swatches[Id("fov_col")] = &S.fovCol;
            OpenOverlay(OV_COLOR, Id("fov_col"), ImRect(sc - ImVec2(7, 7), sc + ImVec2(7, 7)));
        }
    }
    g_ov.a = 1.0f;
}

// ---- loader ("Anesthysia / Initialization in progress / N of 12" pill with a rotating glow), started by HOME / END
static bool  g_debugUi = true;      // Debug window + ESP Preview (NUM8 only)
static float g_ldT = 0.0f, g_ldA = 0.0f, g_ldDur = 14.0f, g_ldNumA = 1.0f; static int g_ldShown = 0;
void Menu_RequireLoader() { g_boot = 0; g_open = false; g_openA = 0.0f; }
void Menu_StartLoader(bool debug)
{
    if (g_boot != 0) return;
    g_boot = 1; g_debugUi = debug; g_ldT = 0.0f; g_ldA = 0.0f; g_ldDur = debug ? 3.0f : 23.0f; g_ldShown = 0; g_ldNumA = 1.0f;
}
bool Menu_LoaderActive() { return g_boot == 1; }
void Menu_SkipLoader()   // ALT: instant load (starts the loader if it is still waiting for the hotkey, then finishes it at once)
{
    if (g_boot == 0) Menu_StartLoader(false);
    if (g_boot != 1) return;
    g_ldT = g_ldDur; g_ldA = 0.0f; g_ldShown = 12;
    g_boot = 2; g_open = true;
}
static void LoaderSkip(float t) { g_ldT = t; g_ldA = 1.0f; g_ldShown = -1; }
static int LoaderStep(float t)   // 0..12: some steps fly by, some hang for seconds (23 s total, scaled for the 3 s debug load)
{
    static const float D[13] = { 2.0f, 0.3f, 0.05f, 4.5f, 0.9f, 0.05f, 0.06f, 3.4f, 0.5f, 4.6f, 0.12f, 5.6f, 0.92f };   // seconds on 0, 1, ... 12 (sum 23)
    float k = g_ldDur / 23.0f, acc = 0.0f;
    for (int i = 0; i < 13; ++i) { acc += D[i] * k; if (t < acc) return i; }
    return 12;
}
static void DrawLoader()
{
    ImGuiIO& io = ImGui::GetIO();
    g_ldT += g_dt;
    bool done = g_ldT >= g_ldDur;
    g_ldA = ImClamp(g_ldA + (done ? -1.0f : 1.0f) * g_dt * (done ? 3.5f : 4.0f), 0.0f, 1.0f);
    if (done && g_ldA <= 0.0f) { g_boot = 2; g_open = true; return; }
    int step = LoaderStep(g_ldT);
    if (step != g_ldShown) { g_ldShown = step; g_ldNumA = 0.0f; }
    g_ldNumA = ImMin(1.0f, g_ldNumA + g_dt * 5.0f);
    const float s = g_dpiTarget, A = g_ldA, ea = EaseOutCubic(A);
    const float W = 364.0f * s, H = 80.0f * s, R = 23.0f * s;
    ImVec2 p0(floorf(io.DisplaySize.x - 28.0f * s - W), floorf(28.0f * s - (1.0f - ea) * 16.0f * s)), p1 = p0 + ImVec2(W, H);
    g_backdrop = ImRect(p0, p1); g_backdropVisible = A > 0.3f; g_backdropAlpha = 1.0f;   // blurred game behind the pill (same blur window as the menu)
    ImDrawList* dl = ImGui::GetForegroundDrawList();
    // contour: (corner/edge centre, outward normal); offset d gives the exact rounded rect grown by d
    struct CV { ImVec2 c, n; float k; };
    static ImVector<CV> cv; cv.resize(0);
    const ImVec2 cc[4] = { ImVec2(p1.x - R, p0.y + R), ImVec2(p1.x - R, p1.y - R), ImVec2(p0.x + R, p1.y - R), ImVec2(p0.x + R, p0.y + R) };
    const float a0[4] = { -IM_PI * 0.5f, 0.0f, IM_PI * 0.5f, IM_PI };
    const ImVec2 ctr = (p0 + p1) * 0.5f;
    for (int k = 0; k < 4; ++k) {
        for (int i = 0; i <= 12; ++i) { float a = a0[k] + IM_PI * 0.5f * i / 12.0f; cv.push_back({ cc[k], ImVec2(cosf(a), sinf(a)), 0 }); }
        const ImVec2 e0 = cc[k], e1 = cc[(k + 1) & 3]; ImVec2 n(cosf(a0[k] + IM_PI * 0.5f), sinf(a0[k] + IM_PI * 0.5f));
        float len = sqrtf(ImLengthSqr(e1 - e0)); int ns = (int)(len / (6.0f * s));
        for (int i = 1; i < ns; ++i) cv.push_back({ ImLerp(e0, e1, (float)i / ns), n, 0 });
    }
    // rotating light: one soft bright arc travelling around the border (+ a faint one opposite)
    const float rot = g_ldT * 1.9f;
    for (auto& v : cv) {
        ImVec2 p = v.c + v.n * R - ctr; float th = atan2f(p.y / (H * 0.5f), p.x / (W * 0.5f));
        float h1 = powf(0.5f + 0.5f * cosf(th - rot), 6.0f), h2 = powf(0.5f + 0.5f * cosf(th - rot - IM_PI), 6.0f);
        v.k = 0.80f + 0.42f * h1 + 0.12f * h2;
    }
    auto GC = [&](float a, float k) {   // steel-blue glow, brighter + lighter where the light passes
        float l = ImClamp(k - 0.8f, 0.0f, 1.0f) * 0.5f;   // menu theme colour, lighter where the light passes
        const float br = ImLerp((float)((ACCENT >> 16) & 0xFF), 214.0f, 0.42f), bg = ImLerp((float)((ACCENT >> 8) & 0xFF), 220.0f, 0.42f), bb = ImLerp((float)(ACCENT & 0xFF), 228.0f, 0.42f);   // theme colour, a little whitish-grey
        int r = (int)ImLerp(br, 255.0f, l), g = (int)ImLerp(bg, 255.0f, l), b = (int)ImLerp(bb, 255.0f, l);
        return IM_COL32(r, g, b, (int)(ImClamp(a * ImMin(k, 1.0f) * A, 0.0f, 1.0f) * 255));
    };
    auto Ring = [&](float d0, float d1, float f0, float f1) {
        int n = cv.Size; dl->PrimReserve(n * 6, n * 2);
        ImDrawIdx base = (ImDrawIdx)dl->_VtxCurrentIdx; ImVec2 uv = dl->_Data->TexUvWhitePixel;
        for (int i = 0; i < n; ++i) { dl->PrimWriteVtx(cv[i].c + cv[i].n * (R + d0), uv, GC(f0, cv[i].k)); dl->PrimWriteVtx(cv[i].c + cv[i].n * (R + d1), uv, GC(f1, cv[i].k)); }
        for (int i = 0; i < n; ++i) { int j = (i + 1) % n; dl->PrimWriteIdx(base + i * 2); dl->PrimWriteIdx(base + i * 2 + 1); dl->PrimWriteIdx(base + j * 2 + 1); dl->PrimWriteIdx(base + i * 2); dl->PrimWriteIdx(base + j * 2 + 1); dl->PrimWriteIdx(base + j * 2); }
    };
    // outer glow (wide, soft)
    const int NO = 14; const float GO = 22.0f * s;
    for (int r = 0; r < NO; ++r) {
        float t0 = (float)r / NO, t1 = (float)(r + 1) / NO;
        auto f = [](float t) { float u = 1.0f - t; return 0.80f * u * u * (0.55f + 0.45f * u); };
        Ring(GO * t0, GO * t1, f(t0), r + 1 == NO ? 0.0f : f(t1));
    }
    // body
    dl->AddRectFilled(p0, p1, IM_COL32(0x12, 0x13, 0x1A, (int)(255 * 0.84f * A)), R);   // menu background colour, a bit more transparent
    // inner glow (the blue soaks ~10px into the body)
    const int NI = 12; const float GI = 12.0f * s;
    for (int r = 0; r < NI; ++r) {
        float t0 = (float)r / NI, t1 = (float)(r + 1) / NI;
        auto f = [](float t) { float u = 1.0f - t; return 0.66f * u * u * (0.4f + 0.6f * u); };
        Ring(-GI * t0, -GI * t1, f(t0), r + 1 == NI ? 0.0f : f(t1));
    }
    Ring(-2.0f * s, 0.0f, 0.62f, 0.80f);   // soft lit edge
    // soft light spot behind the counter
    {
        ImVec2 sp(p1.x - 27.0f * s, p0.y + H * 0.52f); const float SR = 17.0f * s; const int NS = 40;
        dl->PrimReserve(NS * 3, NS + 1); ImDrawIdx base = (ImDrawIdx)dl->_VtxCurrentIdx; ImVec2 uv = dl->_Data->TexUvWhitePixel;
        dl->PrimWriteVtx(sp, uv, IM_COL32(255, 255, 255, (int)(40 * A)));
        for (int i = 0; i < NS; ++i) { float a = IM_PI * 2 * i / NS; dl->PrimWriteVtx(sp + ImVec2(cosf(a), sinf(a)) * SR, uv, IM_COL32(255, 255, 255, 0)); }
        for (int i = 0; i < NS; ++i) { dl->PrimWriteIdx(base); dl->PrimWriteIdx(base + 1 + i); dl->PrimWriteIdx(base + 1 + (i + 1) % NS); }
    }
    // logo
    const float LS = 47.5f * s; ImVec2 l0(p0.x + 18.0f * s, p0.y + (H - LS) * 0.5f), l1 = l0 + ImVec2(LS, LS);
    dl->AddRectFilled(l0, l1, IM_COL32(0x0E, 0x16, 0x22, (int)(255 * A)), 10.0f * s);
    if (g_plat.logoTex) dl->AddImageRounded(ImTextureRef(g_plat.logoTex), l0, l1, ImVec2(0, 0), ImVec2(1, 1), IM_COL32(255, 255, 255, (int)(255 * A)), 10.0f * s);
    // text (Noto Sans: bold title, regular subtitle, medium counter)
    const float tx = p0.x + 83.0f * s;
    dl->AddText(F_NSB, 24.5f * s, ImVec2(tx, p0.y + 13.5f * s), IM_COL32(0xCF, 0xD0, 0xD1, (int)(255 * A)), "Anesthysia");
    dl->AddText(F_NR, 21.4f * s, ImVec2(tx, p0.y + 41.2f * s), IM_COL32(0x9C, 0x9C, 0xA1, (int)(255 * A)), "Initialization in progress");
    char nb[16]; snprintf(nb, sizeof nb, "%d of 12", g_ldShown);
    ImVec2 ts = F_NM->CalcTextSizeA(21.4f * s, FLT_MAX, 0.0f, nb);
    float na = EaseOutCubic(g_ldNumA);
    ImVec2 np(floorf(p1.x - 19.0f * s - ts.x + 0.5f), floorf(p0.y + 17.3f * s + 0.5f)); (void)na;
    dl->AddText(F_NM, 21.4f * s, np, IM_COL32(0x98, 0x9A, 0x9E, (int)(255 * A)), nb);
}


// plain text watermark at the top centre: "t.me/Anesthysia | fps: N | ping: Nms" (console font), toggled with the ` key
static bool g_textWm = true; static float g_textWmA = 0.0f;
void Menu_ToggleTextWm() { g_textWm = !g_textWm; }
// ---- rotating manji crosshair in the screen centre: each arm its own bright colour, black outline
static float g_manjiA = 0.0f, g_manjiRot = 0.0f;
static void DrawManji()
{
    ImGuiIO& io = ImGui::GetIO();
    g_manjiA = ImClamp(g_manjiA + (g_boot == 2 ? 1.0f : -1.0f) * g_dt * 6.0f, 0.0f, 1.0f);
    if (g_manjiA <= 0.0f) return;
    g_manjiRot = fmodf(g_manjiRot + g_dt * 2.6f, 6.2831853f);
    if (getenv("MANJIROT")) g_manjiRot = (float)atof(getenv("MANJIROT"));
    const float d = g_dpiTarget, L = 11.0f * d, Hk = 11.0f * d, w = 1.5f * d, o = 1.0f * d;   // arm length, hook length, half width, outline
    const ImVec2 c(floorf(io.DisplaySize.x * 0.5f), floorf(io.DisplaySize.y * 0.5f));
    static const ImU32 COL[4] = { IM_COL32(255, 30, 70, 255), IM_COL32(255, 230, 0, 255), IM_COL32(0, 255, 110, 255), IM_COL32(0, 170, 255, 255) };
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    const int a = (int)(255 * g_manjiA);
    auto rect = [&](float ang, float x0, float y0, float x1, float y1, float e, ImU32 col) {   // axis-aligned in arm space, then rotated
        float cs = cosf(ang), sn = sinf(ang);
        ImVec2 q[4] = { ImVec2(x0 - e, y0 - e), ImVec2(x1 + e, y0 - e), ImVec2(x1 + e, y1 + e), ImVec2(x0 - e, y1 + e) };
        for (auto& v : q) v = ImVec2(c.x + v.x * cs - v.y * sn, c.y + v.x * sn + v.y * cs);
        dl->AddQuadFilled(q[0], q[1], q[2], q[3], col);
    };
    // arm k: from the centre up to -L, then the hook to the left (卍)
    for (int pass = 0; pass < 2; ++pass)
        for (int k = 0; k < 4; ++k) {
            float ang = g_manjiRot + k * 1.5707963f;
            float e = pass == 0 ? o : 0.0f;
            ImU32 col = pass == 0 ? IM_COL32(0, 0, 0, a) : ((COL[k] & 0x00FFFFFF) | ((ImU32)a << 24));
            rect(ang, -w, -L - w, w, w, e, col);          // stem
            rect(ang, -w, -L - w, Hk + w, -L + w, e, col);  // hook (to the right: 卐)
        }
}
static void DrawTextWatermark()
{
    ImGuiIO& io = ImGui::GetIO();
    g_textWmA = ImClamp(g_textWmA + ((g_textWm && g_boot == 2) ? 1.0f : -1.0f) * g_dt * 6.0f, 0.0f, 1.0f);
    if (g_textWmA <= 0.0f) return;
    static float fps = 0.0f, ft = 0.0f; static int fj = 0, pj = 0;
    ft -= g_dt;
    if (ft <= 0.0f) { ft = 0.5f; fj = (rand() % 13) - 6; pj = (rand() % 5) - 2; fps = WM.realFps ? io.Framerate : (float)ImMax(1, WM.fakeFps + fj); }
    char buf[96]; snprintf(buf, sizeof buf, "t.me/Anesthysia | fps: %d | ping: %dms", (int)fps, ImMax(1, WM.ping + pj));
    ImFont* f = F_CON ? F_CON : F_PIX; const float fs = 14.0f * g_dpiTarget;
    ImVec2 ts = f->CalcTextSizeA(fs, FLT_MAX, 0.0f, buf);
    ImVec2 p(floorf((io.DisplaySize.x - ts.x) * 0.5f), floorf(6.0f * g_dpiTarget));
    int a = (int)(255 * g_textWmA);
    ImDrawList* dl = ImGui::GetForegroundDrawList();
    for (int dy = -2; dy <= 2; ++dy) for (int dx = -2; dx <= 2; ++dx) {   // thick black outline (2px)
        if ((dx == 0 && dy == 0) || dx * dx + dy * dy > 5) continue;
        dl->AddText(f, fs, p + ImVec2((float)dx, (float)dy), IM_COL32(0, 0, 0, a * 7 / 10), buf);
    }
    dl->AddText(f, fs, p, IM_COL32(255, 255, 255, a), buf);
}

// long black blurred bar at the bottom centre of the screen; click = open the menu
static void DrawOpenBar()
{
    ImGuiIO& io = ImGui::GetIO();
    const bool want = g_boot == 2 && !g_unload;   // stays while the menu is open; click toggles
    g_barA = ImClamp(g_barA + (want ? 1.0f : -1.0f) * g_dt * (want ? 4.0f : 7.0f), 0.0f, 1.0f);
    g_barBlur = false;
    if (g_barA <= 0.0f) return;
    const float s = g_dpiTarget, A = EaseOutCubic(g_barA);
    const float W = 340.0f * s, H = 14.0f * s;
    ImVec2 c(floorf(io.DisplaySize.x * 0.5f), floorf(io.DisplaySize.y - 16.0f * s - H * 0.5f + (1.0f - A) * 14.0f * s));
    ImRect r(ImVec2(c.x - W * 0.5f, c.y - H * 0.5f), ImVec2(c.x + W * 0.5f, c.y + H * 0.5f));
    ImRect hit(r.Min - ImVec2(6, 8) * s, r.Max + ImVec2(6, 8) * s);
    static float hov = 0.0f;
    bool h = want && g_barA > 0.5f && hit.Contains(io.MousePos);
    hov = ImClamp(hov + (h ? 1.0f : -1.0f) * g_dt * 8.0f, 0.0f, 1.0f);
    if (h) { g_wantMouse = true; if (io.MouseClicked[0]) Menu_Toggle(); }
    g_barRect = r; g_barBlur = want && g_barA > 0.3f;
    ImDrawList* dl = ImGui::GetForegroundDrawList();
    const float R = H * 0.5f;
    dl->AddRectFilled(r.Min, r.Max, IM_COL32(0, 0, 0, (int)((105 + 30 * hov) * A)), R);   // semi-transparent black over the blur, no outline
}
void Menu_Frame(float dt)
{
    ImGuiIO& io = ImGui::GetIO();
    g_dt = ImClamp(dt, 0.0001f, 0.1f);
    if (!g_posInit) { g_pos = g_posTarget = ImVec2(floorf((io.DisplaySize.x - MENU_W) * 0.5f), floorf((io.DisplaySize.y - MENU_H) * 0.5f)); g_posInit = true; }

    // open / close animation (time based, eased)
    float speed = g_open ? 4.2f : 5.0f;
    g_openA = ImClamp(g_openA + (g_open ? 1 : -1) * g_dt * speed, 0.0f, 1.0f);
    g_wantMousePrev = g_wantMouse || (Menu_IsVisible() && g_backdrop.Contains(ImGui::GetIO().MousePos));
    g_wantMouse = false;
    if (g_boot != 2) { g_blurRanges.clear(); g_backdropVisible = false; if (g_boot == 1) DrawLoader(); if (g_boot != 2) return; }
    DrawFakeViewmodel();
    DrawFovCircle();
    DrawCrosshairWm();
    DrawWatermark();
    DrawOpenBar();
    DrawManji();
    DrawTextWatermark();
    if (g_openA <= 0.0f && !g_open) { g_blurRanges.clear(); g_backdropVisible = false; return; }
    float ea = g_open ? EaseOutCubic(g_openA) : EaseInOut(g_openA);
    bool interactive = g_open && g_openA > 0.6f;

    // ---- Debug window (plain ImGui)
    {
        static const char* dpiNames[] = { "75%", "100%", "125%", "150%", "175%", "200%" };
        static const float dpiVals[]  = { 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f };
        ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ea);
        ImGui::SetNextWindowPos(ImVec2(20, 20), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowSize(ImVec2(300, 0), ImGuiCond_Always);
        ImGuiWindowFlags wf = ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings;
        if (!interactive) wf |= ImGuiWindowFlags_NoInputs;
        ImGui::PushFont(F_MED, 15.0f);
        if (g_debugUi && ImGui::Begin("Debug", nullptr, wf)) {
            ImGui::SetNextItemWidth(120);
            if (ImGui::Combo("Dpi scale", &g_dpiIdx, dpiNames, IM_ARRAYSIZE(dpiNames))) g_dpiTarget = dpiVals[g_dpiIdx];
            float col[3] = { ((ACCENT >> 16) & 0xFF) / 255.0f, ((ACCENT >> 8) & 0xFF) / 255.0f, (ACCENT & 0xFF) / 255.0f };
            ImGui::SetNextItemWidth(120);
            if (ImGui::ColorEdit3("Theme color", col, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_PickerHueWheel))
                ACCENT = ((ImU32)(col[0] * 255.0f + 0.5f) << 16) | ((ImU32)(col[1] * 255.0f + 0.5f) << 8) | (ImU32)(col[2] * 255.0f + 0.5f);
            ImGui::SameLine();
            if (ImGui::SmallButton("Reset")) ACCENT = ACCENT_DEFAULT;
            DebugWatermarkUI();
            DebugCrosshairUI();
            DebugFakeViewmodelUI();
        }
        if (g_debugUi) { ImGui::End(); EspPreviewWindow(interactive); }
        ImGui::PopFont();
        ImGui::PopStyleVar();
    }
    g_dpi += (g_dpiTarget - g_dpi) * (1.0f - expf(-16.0f * g_dt));
    if (fabsf(g_dpiTarget - g_dpi) < 0.001f) g_dpi = g_dpiTarget;
    // keep the (scaled) menu on screen
    // no clamping: the menu may be dragged partly / fully off screen and stays where it was dropped
    bool imguiMouse = io.WantCaptureMouse;

    // input
    ImVec2 rawM = io.MousePos;
    IN.click = interactive && io.MouseClicked[0];
    IN.rclick = interactive && io.MouseClicked[1];
    g_rcloseId = 0;
    IN.down = io.MouseDown[0];
    IN.release = io.MouseReleased[0];
    g_hotAny = false;

    // drag (smoothed)
    if (g_dragging) {
        if (IN.down) g_posTarget = rawM - g_dragOff; else g_dragging = false;
    }
    g_pos = g_pos + (g_posTarget - g_pos) * (1.0f - expf(-28.0f * g_dt));
    if (ImLengthSqr(g_posTarget - g_pos) < 0.01f) g_pos = g_posTarget;
    O = ImVec2(floorf(g_pos.x + 0.5f), floorf(g_pos.y + 0.5f));
    g_snapO = O;
    IN.m = O + (rawM - O) / g_dpi;   // mouse in local (unscaled) menu space
    if (imguiMouse && !R(0, 0, MENU_W, MENU_H).Contains(IN.m) && !g_ovRectPrev.Contains(IN.m)) IN.click = IN.rclick = false;

    // overlay anim + click-outside
    if (g_ov.type != OV_NONE) {
        g_ov.a = ImClamp(g_ov.a + (g_ov.open ? 1 : -1) * g_dt * (g_ov.open ? 7.0f : 9.0f), 0.0f, 1.0f);
        if (!g_ov.open && g_ov.a <= 0.0f) { g_ov.type = OV_NONE; g_hasParent = false; }
    }
    bool parentOn = g_hasParent && g_ov.type == OV_COLOR;
    g_blockMain = g_ov.type != OV_NONE && g_ov.a > 0.05f && (g_ovRectPrev.Contains(IN.m) || (parentOn && g_parentRect.Contains(IN.m)));
    bool consumed = false;
    if (g_ov.open && IN.click && !g_ovRectPrev.Contains(IN.m)) {
        if (parentOn && g_parentRect.Contains(IN.m)) {   // click on the parent popup: close the picker, back to the popup
            g_ov = g_ovParent; g_ov.open = true; g_ov.a = 1.0f; g_hasParent = false; g_active = 0;
        } else {
            g_ov.open = false; consumed = true;
            IN.click = false;   // click outside only closes the popup
        }
    } else if (g_ov.open && IN.rclick && !g_ovRectPrev.Contains(IN.m) && !(parentOn && g_parentRect.Contains(IN.m))) {
        if (EspPickerOpen()) g_rcloseId = g_ov.id;   // right click on the same element toggles it closed
        g_ov.open = false;                         // right click outside closes; another element may open its picker
    }
    if (!interactive) { g_blockMain = true; }

    DL = ImGui::GetForegroundDrawList();
    // geometry is drawn in unscaled local space and scaled afterwards: keep AA fringes 1 screen px and curves smooth
    DL->_FringeScale = 1.0f / g_dpi;
    DL->_Data->SetCircleTessellationMaxError(ImGui::GetStyle().CircleTessellationMaxError / g_dpi);
    int vtx0 = DL->VtxBuffer.Size;
    g_blurRanges.clear();

    ImRect menu = R(0, 0, MENU_W, MENU_H);
    // shadow
    ShadowRing(menu, MENU_ROUND, 22.0f, 0.75f);
    // body (slightly transparent; the host blurs whatever is behind the menu)
    DL->AddRectFilled(menu.Min, P(170, MENU_H), C(0x0A0C12, BG_ALPHA), MENU_ROUND, ImDrawFlags_RoundCornersLeft);
    // fill the small corner wedges between the sidebar and the rounded content panel
    // (only the area outside the panel's arc, so the semi-transparent layers never stack -> no dark squares)
    for (int k = 0; k < 2; ++k) {
        ImVec2 cn = k == 0 ? P(170, 0) : P(170, MENU_H);
        ImVec2 cc = k == 0 ? P(170 + MENU_ROUND, MENU_ROUND) : P(170 + MENU_ROUND, MENU_H - MENU_ROUND);
        DL->PathLineTo(cn);
        if (k == 0) DL->PathArcTo(cc, MENU_ROUND, IM_PI * 1.5f, IM_PI, 12);
        else        DL->PathArcTo(cc, MENU_ROUND, IM_PI, IM_PI * 0.5f, 12);
        DL->AddConcavePolyFilled(DL->_Path.Data, DL->_Path.Size, C(0x0A0C12, BG_ALPHA));
        DL->PathClear();
    }
    DL->AddRectFilled(P(170, 0), P(MENU_W, MENU_H), C(0x0D0E14, BG_ALPHA), MENU_ROUND);
    DL->AddRect(P(169, 0), P(MENU_W, MENU_H), C(0x14161A), MENU_ROUND, 0, 1.0f);
    DL->AddRect(menu.Min, menu.Max, C(0x10121A), MENU_ROUND, 0, 1.0f);

    DrawSidebar();
    DrawTopbar();
    {   // page content (animated switch: fade out -> fade/slide in)
        int pk = PageKey();
        if (pk != g_shownPage) { g_pageFade -= g_dt * 10.0f; if (g_pageFade <= 0.0f) { g_pageFade = 0.0f; g_shownPage = pk; } }
        else g_pageFade = ImMin(1.0f, g_pageFade + g_dt * 5.0f);
        float fe = EaseOutCubic(g_pageFade);
        int cv0 = DL->VtxBuffer.Size;
        DL->PushClipRect(P(171, 57), P(MENU_W - 1, MENU_H - 1), true);
        ImVec2 so = O;
        O.y += (1.0f - fe) * 10.0f;
        int page = g_shownPage / 10;
        switch (page) {
        case 0: DrawRage(); break;
        case 1: DrawPlayers(); break;
        case 3: DrawInventory(); break;
        case 4: DrawProjectiles(); break;
        case 5: DrawMisc(); break;
        default: DrawWorld(); break;
        }
        O = so;
        DL->PopClipRect();
        FadeVerts(cv0, fe);
    }

    // overlays
    MsDebugPopup();
    if (g_hasParent && g_ov.type == OV_COLOR) {   // parent popup stays under the colour picker
        int pv0 = DL->VtxBuffer.Size;
        g_parentRect = g_ovParent.type == OV_ESPITEMS ? DrawEspItems(1.0f) : DrawFovPopup(1.0f, g_ovParent.opener);
        if (!g_ov.open) FadeVerts(pv0, EaseInOut(g_ov.a));
    }
    SyncEspPicker();
    int ovV0 = DL->VtxBuffer.Size;
    if (g_ov.type == OV_FOVPOP) g_ov.rect = g_parentRect = DrawFovPopup(g_ov.a, g_ov.opener);
    else if (g_ov.type == OV_LIMITERS) DrawLimiters(g_ov.a);
    else if (g_ov.type == OV_PROFILE) DrawProfilePopup(g_ov.a);
    else if (g_ov.type == OV_COMBO) DrawDropdown(g_ov.a);
    else if (g_ov.type == OV_COLOR) DrawColorPicker(g_ov.a);
    else if (g_ov.type == OV_ESPITEMS) DrawEspItems(g_ov.a);
    else if (g_ov.type == OV_SKINS) DrawSkinsPopup(g_ov.a);
    else if (g_ov.type == OV_AIRSTRAFE) DrawAirStrafe(g_ov.a);
    else if (g_ov.type == OV_HITSOUND) DrawHitSound(g_ov.a);
    else if (g_ov.type == OV_CONFIG) DrawConfigPopup(g_ov.a);
    else if (g_ov.type == OV_IDEBUG) DrawInteractiveDebug(g_ov.a);
    else if (g_ov.type == OV_FLYHACK) DrawFlyhack(g_ov.a);
    if (g_ov.type != OV_NONE && g_ov.a < 1.0f) {
        float oe = g_ov.open ? EaseOutCubic(g_ov.a) : EaseInOut(g_ov.a);
        float os = g_ov.type == OV_SKINS ? 1.0f : 0.96f + 0.04f * oe;   // skin picker: same size as the panel, fade only
        ImVec2 piv = EspPickerOpen() ? ImVec2(g_ov.rect.GetCenter().x, g_ov.rect.Min.y) : (g_ov.type == OV_LIMITERS || g_ov.type == OV_FOVPOP || g_ov.type == OV_PROFILE || g_ov.type == OV_COLOR || g_ov.type == OV_AIRSTRAFE || g_ov.type == OV_HITSOUND || g_ov.type == OV_IDEBUG || g_ov.type == OV_FLYHACK) ? ImVec2(g_ov.rect.Min.x, g_ov.opener.GetCenter().y) : ImVec2(g_ov.rect.GetCenter().x, g_ov.rect.Min.y);
        ImDrawVert* vv = DL->VtxBuffer.Data;
        for (int i = ovV0; i < DL->VtxBuffer.Size; ++i) {
            vv[i].pos = piv + (vv[i].pos - piv) * os;
            ImU32 col = vv[i].col;
            int a8 = (int)(((col >> IM_COL32_A_SHIFT) & 0xFF) * oe);
            vv[i].col = (col & ~IM_COL32_A_MASK) | ((ImU32)a8 << IM_COL32_A_SHIFT);
        }
    }
    g_ovRectPrev = g_ov.type != OV_NONE ? g_ov.rect : ImRect();
    // apply popup fade/scale to its vertices is done by alpha in colours; additionally fade with g_ov.a:
    // (handled below via per-range alpha)

    // start dragging from empty menu area
    if (IN.click && !consumed && !g_hotAny && menu.Contains(IN.m) && !g_ovRectPrev.Contains(IN.m)) {
        g_dragging = true; g_dragOff = rawM - g_posTarget;
    }

    // open/close transform: scale around centre + global alpha
    float s = 0.94f + 0.06f * ea;
    float alpha = ea;
    ImVec2 c = O + (menu.GetCenter() - O) * g_dpi;
    ImDrawVert* v = DL->VtxBuffer.Data;
    for (int i = vtx0; i < DL->VtxBuffer.Size; ++i) {
        v[i].pos = c + (O + (v[i].pos - O) * g_dpi - c) * s;
        if (alpha < 1.0f) {
            ImU32 col = v[i].col;
            int a8 = (int)(((col >> IM_COL32_A_SHIFT) & 0xFF) * alpha);
            v[i].col = (col & ~IM_COL32_A_MASK) | ((ImU32)a8 << IM_COL32_A_SHIFT);
        }
    }
    // GPU clip rectangles must follow the same transform
    for (ImDrawCmd& cmd : DL->CmdBuffer) {
        ImVec2 a(cmd.ClipRect.x, cmd.ClipRect.y), b(cmd.ClipRect.z, cmd.ClipRect.w);
        a = c + (O + (a - O) * g_dpi - c) * s; b = c + (O + (b - O) * g_dpi - c) * s;
        cmd.ClipRect = ImVec4(floorf(a.x), floorf(a.y), ceilf(b.x), ceilf(b.y));
    }
    DL->_FringeScale = 1.0f; DL->_Data->SetCircleTessellationMaxError(ImGui::GetStyle().CircleTessellationMaxError);
    // re-map UVs of blurred backdrops to final screen positions
    for (auto& br : g_blurRanges)
        for (int i = br.v0; i < br.v1; ++i) v[i].uv = ImVec2(v[i].pos.x / io.DisplaySize.x, v[i].pos.y / io.DisplaySize.y);

    {   // profile popup: screen rect for the host's background blur
        g_popVisible = g_ov.type == OV_PROFILE && g_ov.a > 0.5f && g_ov.open && ea > 0.35f;
        if (g_popVisible) {
            ImVec2 a0 = c + (O + (g_ov.rect.Min - O) * g_dpi - c) * s, a1 = c + (O + (g_ov.rect.Max - O) * g_dpi - c) * s;
            g_popRect = ImRect(a0, a1);
        }
    }
    {
        ImVec2 mn = c + (O + (menu.Min - O) * g_dpi - c) * s, mx = c + (O + (menu.Max - O) * g_dpi - c) * s;
        g_backdrop = ImRect(mn, mx); g_backdropVisible = ea > 0.35f; g_backdropAlpha = 1.0f;
        float pad = 30.0f * g_dpi;
        g_animBlurRect = ImRect(mn - ImVec2(pad, pad), mx + ImVec2(pad, pad)); g_animBlur = 1.0f - ea;
    }
    g_wantMouse = g_wantMouse || interactive && (imguiMouse || menu.Contains(IN.m) || g_dragging || g_active != 0 || (g_ov.type != OV_NONE && g_ov.rect.Contains(IN.m)) || (g_hasParent && g_ov.type == OV_COLOR && g_parentRect.Contains(IN.m)));
}
