// software-rasterised 3D player model for the ESP preview (same output on every backend)
#pragma once
#include <vector>
#include <cstdint>

enum M3DMat { M3D_TEXTURED = 0, M3D_FLAT, M3D_GLOW, M3D_GLOW_OUTLINE, M3D_GLASS, M3D_WIREFRAME, M3D_WATERFLOW, M3D_GALAXY,
              M3D_DAMASCUS, M3D_GLITTER, M3D_LIGHTNING, M3D_FIRE, M3D_STARNEST, M3D_DISSOLVE, M3D_GHOST,
              M3D_HOLOGRAM, M3D_RAINBOW, M3D_PULSE, M3D_CRYSTAL, M3D_REAVER, M3D_SINGULARITY,
              M3D_ENCHANT, M3D_HEXSHIELD, M3D_GOLD, M3D_CAMO,
              M3D_LAVA, M3D_MERCURY, M3D_AURORA,
              M3D_RECON, M3D_VIPER, M3D_OMEN, M3D_GALAXYWIRE, M3D_COUNT };
enum { M3D_MODEL_COUNT = 4, M3D_MODEL_FP = 3 };   // 3 = first-person arms + AKR (fake viewmodel, camera from the model)          // 0 default agent, 1 Standoff 2 CT Michael + M4, 2 Standoff 2 T + AKR (build 1.0.0, lobby idle)
struct M3DSettings {
    int   model = 0;
    float yaw = 0.0f, pitch = 0.0f;
    int   mat = M3D_TEXTURED;
    float col[4] = { 1, 1, 1, 1 };       // chams colour (rgb 0..1, alpha)
    bool  overlay = false;               // Wireframe / Waterflow drawn on top of the textured model
    bool  halo = false;                  // outer glow ("Glow" row)
    float haloCol[4] = { 1, 1, 1, 1 };
    float time = 0.0f;
    float bright = 1.0f;                 // dims the model when ESP is disabled
    float anim = -1.0f;                  // idle animation time in seconds (< 0 = bind pose)
    float fpOff[3] = { 0, 0, 0 };        // first-person model: offset in camera space (x right, y up, z forward)
    float rag = -1.0f;                   // ragdoll: seconds since death (< 0 = alive)
    float ragA = 0.0f;                   // ragdoll: fall direction (model-space yaw)
    float fov = 62.0f;                   // first-person model: vertical field of view (degrees)
    float fpView[4] = { 0, 0, 0, 0 };    // first-person model: render a crop (x, y) of a virtual frame (w, h); w = 0 -> whole buffer
    uint32_t look = 0;                   // inventory agent: render with the skins set by M3D_SetLook (key), 0 = stock
};
struct M3DOut { float x0, y0, x1, y1; bool valid; };   // pixel bounds of the drawn model (buffer space)

bool M3D_Init();
// decode a PNG/JPEG from memory (stb_image); free with M3D_FreeImage
unsigned char* M3D_DecodeImage(const unsigned char* data, int size, int* w, int* h, int comp);
void M3D_FreeImage(unsigned char* p);
// rgba: W*H*4 bytes, straight alpha
void M3D_Render(uint8_t* rgba, int W, int H, const M3DSettings& s, M3DOut* out);
// project a model-space point (metres, Y up) into buffer pixels
void M3D_Project(float x, float y, float z, int W, int H, const M3DSettings& s, float* sx, float* sy);
int  M3D_BoneCount();
// skeleton segments for the pose at s.anim: out[i] = x0 y0 z0 x1 y1 z1 (model space)
void M3D_Bones(const M3DSettings& s, float (*out)[6]);
void M3D_HeadPoint(const M3DSettings& s, float* xyz);
float M3D_AnimLength();
void M3D_RagPoint(const M3DSettings& s, const float* in, float* out);   // model point -> ragdoll-deformed point
// first-person model: pixel bounds (x0 y0 x1 y1) of the model in a VW x VH frame; false if nothing is visible
bool M3D_FpBounds(const M3DSettings& s, int VW, int VH, float* bb);
// inventory agent (model 1 CT / 2 T) with skins: gloveMesh 0/1 = game glove skin mesh + gloveRGB (from M3D_GloveSkin),
// -1 = the agent's own gloves recoloured with gpal (16 rgb 0..1, dark -> light) if given; wpnRGB = held weapon texture (same UV as the stock one)
void M3D_SetLook(int model, uint32_t key, int gloveMesh, const uint8_t* gloveRGB, int gw, int gh, const float* gpal, const uint8_t* wpnRGB, int ww, int wh);
// game glove skin texture by inventory skin name -> glove mesh index, or -1 (not in the game files)
int M3D_GloveSkin(const char* name, std::vector<uint8_t>& rgb, int& w, int& h);
