// software renderer for Standoff 2 weapon / knife models (inventory inspect view)
#pragma once
#include <cstdint>
#include <vector>
int  W3D_ModelCount();
int  W3D_TexCount();
// skin painted from the item's in-game icon (orthographic projection fitted to the icon silhouette)
struct W3DProj { float roll, yaw, pitch, s, tx, ty; };
// renders model m with texture t (index into W3D_TEXS, -1 = none) into straight-alpha RGBA (W x H); yaw / pitch in radians.
// icon (straight RGBA, iw x ih) + proj: paint the model with the icon instead of t
void W3D_Render(uint8_t* rgba, int W, int H, int m, int t, float yaw, float pitch, float zoom = 1.0f,
                const uint8_t* icon = nullptr, int iw = 0, int ih = 0, const W3DProj* proj = nullptr, int ss = 2);   // ss: supersampling (ss x ss samples per pixel)
// offline: find the projection of model m that best matches the icon silhouette; returns IoU
float W3D_FitIcon(int m, const uint8_t* icon, int iw, int ih, W3DProj* out, bool gun);
// skin texture t as RGB (for another mesh with the same UV layout)
bool W3D_TexRGB(int t, std::vector<uint8_t>& rgb, int& w, int& h);
// icon-painted skin of model m baked into its UV space (S x S RGB, S = power of two)
bool W3D_BakeIcon(int m, int t, const uint8_t* icon, int iw, int ih, const W3DProj* proj, int S, std::vector<uint8_t>& rgb);
