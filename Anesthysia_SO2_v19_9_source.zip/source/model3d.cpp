// software rasteriser for the ESP preview model (model data converted from the noctua source assets)
#include "model3d.h"
#include "model_data.h"
#include "anim_data.h"
#include "model_ct.h"
#include "model_t.h"
#include "model_fp.h"
#include "sero_tex.h"
#include "model_gloves.h"
#include <cmath>
#include <cstring>
#include <vector>
#include <algorithm>
#include <thread>
#include <functional>
#include <mutex>
#define STB_IMAGE_IMPLEMENTATION
#define STBI_ONLY_JPEG
#define STBI_ONLY_PNG
#define STBI_NO_STDIO
#include "stb_image.h"
// glove skin textures for the inventory agent (JPEG blob from gen_agent_gloves.py)
asm(
#ifdef _WIN32
    ".section .rdata,\"dr\"\n"
#else
    ".section .rodata\n"
#endif
    ".global AGG_TEXBLOB\n.balign 16\nAGG_TEXBLOB:\n.incbin \"agg_tex.bin\"\n.byte 0\n.text\n");

namespace {
struct Tex { int w = 0, h = 0; std::vector<unsigned char> px; std::vector<Tex> lv; };
static void BuildMips(Tex& t)
{
    t.lv.clear(); const Tex* s = &t;
    while (s->w > 1 && s->h > 1 && t.lv.size() < 12) {
        Tex n; n.w = s->w / 2; n.h = s->h / 2; n.px.resize(n.w * n.h * 3);
        for (int y = 0; y < n.h; ++y) for (int x = 0; x < n.w; ++x) for (int c = 0; c < 3; ++c) {
            const unsigned char* a = &s->px[((2 * y) * s->w + 2 * x) * 3 + c]; const unsigned char* b = a + s->w * 3;
            n.px[(y * n.w + x) * 3 + c] = (unsigned char)((a[0] + a[3] + b[0] + b[3] + 2) >> 2);
        }
        t.lv.push_back(std::move(n)); s = &t.lv.back();
    }
}
Tex g_st[ST_COUNT];                         // serotonin chams textures
std::vector<float> g_snb;                   // star nest (low res)
std::vector<uint8_t> g_snm;
std::vector<float> g_tp, fl;                // dissolve: per-triangle progress; fire field
std::vector<uint32_t> g_seq;
bool g_ok = false;
// ---- models (selectable in the ESP preview)
struct MDef {
    int nv, ni, nprim, wnv, wne, ntex; const int (*prims)[3];
    const int16_t* pos; const int8_t* nrm; const uint16_t* uv; const uint16_t* idx; const int16_t* wpos; const uint16_t* wedge;
    const unsigned char* const* tex; const int* texsz;
    int nb, nf, fps; const float* rest; const int16_t* frames; const uint8_t *widx, *ww, *wwidx, *www; float head[3];
};
struct MState { const MDef* d = nullptr; Tex tex[16]; std::vector<float> pos, nrm, uv, wpos; std::vector<int> triTex; std::vector<uint32_t> idx;
                int nv = 0, ni = 0; const uint8_t* widx = nullptr; const uint8_t* ww = nullptr; std::vector<uint8_t> widxV, wwV; uint32_t key = 0; };
static const int MAIN_PRIMS[][3] = { { 0, 43770, 0 }, { 43770, 10605, 1 }, { 54375, 504, 2 }, { 54879, 6102, 2 } };
static const unsigned char* MAIN_TEX[] = { ::MD_TEX0, ::MD_TEX1, ::MD_TEX2 };
static const int MAIN_TEXSZ[] = { ::MD_TEX0_SIZE, ::MD_TEX1_SIZE, ::MD_TEX2_SIZE };
static const MDef DEFS[M3D_MODEL_COUNT] = {
    { ::MD_NV, ::MD_NI, 4, ::MD_WNV, ::MD_WNE, 3, MAIN_PRIMS, ::MD_POS, ::MD_NRM, ::MD_UV, ::MD_IDX, ::MD_WPOS, ::MD_WEDGE, MAIN_TEX, MAIN_TEXSZ,
      ::AN_NB, ::AN_NF, ::AN_FPS, ::AN_REST, ::AN_FRAMES, ::AN_WIDX, ::AN_WW, ::AN_WWIDX, ::AN_WWW, { 0.0f, 1.60f, 0.02f } },
    { CT_NV, CT_NI, CT_NPRIM, CT_WNV, CT_WNE, CT_NTEX, CT_PRIMS, CT_POS, CT_NRM, CT_UV, CT_IDX, CT_WPOS, CT_WEDGE, CT_TEX, CT_TEXSZ,
      CT_NB, CT_NF, CT_FPS, CT_REST, CT_FRAMES, CT_WIDX, CT_WW, CT_WWIDX, CT_WWW, { CT_HEADPT[0], CT_HEADPT[1], CT_HEADPT[2] } },
    { TR_NV, TR_NI, TR_NPRIM, TR_WNV, TR_WNE, TR_NTEX, TR_PRIMS, TR_POS, TR_NRM, TR_UV, TR_IDX, TR_WPOS, TR_WEDGE, TR_TEX, TR_TEXSZ,
      TR_NB, TR_NF, TR_FPS, TR_REST, TR_FRAMES, TR_WIDX, TR_WW, TR_WWIDX, TR_WWW, { TR_HEADPT[0], TR_HEADPT[1], TR_HEADPT[2] } },
    { FP_NV, FP_NI, FP_NPRIM, FP_WNV, FP_WNE, FP_NTEX, FP_PRIMS, FP_POS, FP_NRM, FP_UV, FP_IDX, FP_WPOS, FP_WEDGE, FP_TEX, FP_TEXSZ,
      FP_NB, FP_NF, FP_FPS, FP_REST, FP_FRAMES, FP_WIDX, FP_WW, FP_WWIDX, FP_WWW, { FP_HEADPT[0], FP_HEADPT[1], FP_HEADPT[2] } },
};
MState g_m[M3D_MODEL_COUNT];
MState g_look[M3D_MODEL_COUNT];          // inventory agent with skins applied (M3DSettings::look)
thread_local MState* g_cur = &g_m[0];   // per thread: the ESP preview and the fake viewmodel render from different threads
std::recursive_mutex g_renderMx, g_loadMx;
#define g_pos    (g_cur->pos)
#define g_nrm    (g_cur->nrm)
#define g_uv     (g_cur->uv)
#define g_wpos   (g_cur->wpos)
#define g_triTex (g_cur->triTex)
#define g_tex    (g_cur->tex)
#define MD_NV    (g_cur->nv)
#define MD_NI    (g_cur->ni)
#define MD_WNV   (g_cur->d->wnv)
#define MD_WNE   (g_cur->d->wne)
#define MD_IDX   (g_cur->idx.data())
#define MD_WEDGE (g_cur->d->wedge)
#define AN_NB    (g_cur->d->nb)
#define AN_NF    (g_cur->d->nf)
#define AN_FPS   (g_cur->d->fps)
#define AN_REST  (g_cur->d->rest)
#define AN_FRAMES (g_cur->d->frames)
#define AN_WIDX  (g_cur->widx)
#define AN_WW    (g_cur->ww)
#define AN_WWIDX (g_cur->d->wwidx)
#define AN_WWW   (g_cur->d->www)
// per-frame buffers
std::vector<float> zb, bA, bB, cm, wl, hm, ht, hacc;
std::vector<int>   tid;
std::vector<float> vs;                      // projected verts: sx sy depth nx ny nz
const float CY = 0.90f, CAM_D = 6.0f;

void ParFor(int n, const std::function<void(int, int)>& fn)
{
    static int nt = std::max(1, std::min(8, (int)std::thread::hardware_concurrency()));
    if (nt <= 1 || n < 64) { fn(0, n); return; }
    std::thread th[8]; int step = (n + nt - 1) / nt;
    MState* cur = g_cur;
    for (int i = 1; i < nt; ++i) { int b = i * step, e = std::min(n, b + step); if (b < e) th[i] = std::thread([&fn, cur](int bb, int ee) { g_cur = cur; fn(bb, ee); }, b, e); }
    fn(0, std::min(n, step));
    for (int i = 1; i < nt; ++i) if (th[i].joinable()) th[i].join();
}
inline float Hash2(int x, int y) { unsigned h = (unsigned)x * 374761393u + (unsigned)y * 668265263u; h = (h ^ (h >> 13)) * 1274126177u; return ((h ^ (h >> 16)) & 0xFFFFFF) / 16777216.0f; }
inline float VNoise(float x, float y)
{
    int ix = (int)floorf(x), iy = (int)floorf(y); float fx = x - ix, fy = y - iy;
    fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy);
    float a = Hash2(ix, iy), b = Hash2(ix + 1, iy), c = Hash2(ix, iy + 1), d = Hash2(ix + 1, iy + 1);
    return a + (b - a) * fx + (c - a) * fy + (a - b - c + d) * fx * fy;
}
inline float Fbm(float x, float y) { float v = 0, a = 0.5f; for (int i = 0; i < 4; ++i) { v += VNoise(x, y) * a; x = x * 2.03f + 17.1f; y = y * 2.03f + 5.3f; a *= 0.5f; } return v; }
inline float sat(float x) { return x < 0 ? 0 : (x > 1 ? 1 : x); }
inline float lerpf(float a, float b, float t) { return a + (b - a) * t; }


// ---- idle animation: per-bone rigid transforms (R | t), v' = R v + t
struct Pose { float m[128][12]; };
void GetPose(float t, Pose& P)
{
    if (t < 0) { for (int b = 0; b < AN_NB; ++b) { float* m = P.m[b]; memset(m, 0, 12 * sizeof(float)); m[0] = m[4] = m[8] = 1; } return; }
    float f = fmodf(t * AN_FPS, (float)AN_NF); if (f < 0) f += AN_NF;
    int f0 = (int)f % AN_NF, f1 = (f0 + 1) % AN_NF; float u = f - floorf(f);
    for (int b = 0; b < AN_NB; ++b) {
        const int16_t* A = &AN_FRAMES[(f0 * AN_NB + b) * 7]; const int16_t* B = &AN_FRAMES[(f1 * AN_NB + b) * 7];
        float q[4], sg = (A[0] * B[0] + A[1] * B[1] + A[2] * B[2] + A[3] * B[3]) < 0 ? -1.0f : 1.0f, l = 0;
        for (int i = 0; i < 4; ++i) { q[i] = A[i] * (1 - u) + B[i] * sg * u; l += q[i] * q[i]; }
        l = 1.0f / sqrtf(l); for (float& v : q) v *= l;
        float p[3]; for (int i = 0; i < 3; ++i) p[i] = (A[4 + i] * (1 - u) + B[4 + i] * u) / 16000.0f;
        float x = q[0], y = q[1], z = q[2], w = q[3]; float* m = P.m[b];
        m[0] = 1 - 2 * (y * y + z * z); m[1] = 2 * (x * y - z * w); m[2] = 2 * (x * z + y * w);
        m[3] = 2 * (x * y + z * w); m[4] = 1 - 2 * (x * x + z * z); m[5] = 2 * (y * z - x * w);
        m[6] = 2 * (x * z - y * w); m[7] = 2 * (y * z + x * w); m[8] = 1 - 2 * (x * x + y * y);
        const float* r = &AN_REST[b * 3];
        for (int i = 0; i < 3; ++i) m[9 + i] = p[i] - (m[i * 3] * r[0] + m[i * 3 + 1] * r[1] + m[i * 3 + 2] * r[2]);
    }
}
inline void XfP(const float* m, const float* v, float* o) { for (int i = 0; i < 3; ++i) o[i] = m[i * 3] * v[0] + m[i * 3 + 1] * v[1] + m[i * 3 + 2] * v[2] + m[9 + i]; }
void Skin(const Pose& P, const float* pos, const float* nrm, const uint8_t* wi, const uint8_t* ww, int n, float* op, float* on)
{
    ParFor(n, [&](int b, int e) {
        for (int i = b; i < e; ++i) {
            float M[12] = { 0 };
            for (int k = 0; k < 4; ++k) { int w = ww[i * 4 + k]; if (!w) continue; const float* m = P.m[wi[i * 4 + k]]; float f = w * (1.0f / 255.0f); for (int j = 0; j < 12; ++j) M[j] += m[j] * f; }
            XfP(M, &pos[i * 3], &op[i * 3]);
            if (nrm) { const float* v = &nrm[i * 3]; for (int j = 0; j < 3; ++j) on[i * 3 + j] = M[j * 3] * v[0] + M[j * 3 + 1] * v[1] + M[j * 3 + 2] * v[2]; }
        }
    });
}
std::vector<float> g_spos, g_snrm, g_swpos;


inline float Hash3(int x, int y, int z) { return Hash2(x * 7919 + z * 104729, y ^ (z * 31337)); }
inline float sstep(float a, float b, float x) { float t = sat((x - a) / (b - a)); return t * t * (3 - 2 * t); }
void SampleT(const Tex& t, float u, float v, float out[3]);
// triplanar lookup in model space (p, n: rest-pose position / normal)
void Tri(const Tex& t, const float* p, const float* n, float sc, float ou, float ov, float o[3])
{
    float ax = n[0] * n[0], ay = n[1] * n[1], az = n[2] * n[2]; ax *= ax; ay *= ay; az *= az;
    float s = 1.0f / (ax + ay + az + 1e-6f); ax *= s; ay *= s; az *= s;
    float a[3] = { 0, 0, 0 }, b[3] = { 0, 0, 0 }, c[3] = { 0, 0, 0 };
    if (ax > 0.02f) SampleT(t, p[2] * sc + ou, -p[1] * sc + ov, a);
    if (ay > 0.02f) SampleT(t, p[0] * sc + ou + 0.31f, p[2] * sc + ov, b);
    if (az > 0.02f) SampleT(t, p[0] * sc + ou, -p[1] * sc + ov, c);
    for (int i = 0; i < 3; ++i) o[i] = a[i] * ax + b[i] * ay + c[i] * az;
}
inline float gmod(float x, float y) { return x - y * floorf(x / y); }
// "Star Nest" by Pablo Roman Andrioli (Kali) - the shader used by the serotonin Galaxy chams
void StarNest(float u, float v, float T, float o[3])
{
    const int IT = 15, VS = 13;
    const float formu = 0.53f, stepsz = 0.1f, zoom = 0.8f, tile = 0.85f, bright = 0.0015f, dark = 0.3f, distf = 0.73f, satr = 0.85f;
    float dx = u * zoom, dy = v * zoom, dz = 1.0f;
    float tm = T * 0.01f + 0.25f;
    float fx = 1.0f + tm * 2.0f, fy = 0.5f + tm, fz = 0.5f - 2.0f;
    float s = 0.1f, fade = 1.0f, r = 0, g = 0, b = 0;
    for (int k = 0; k < VS; ++k) {
        float p0 = fx + s * dx * 0.5f, p1 = fy + s * dy * 0.5f, p2 = fz + s * dz * 0.5f;
        p0 = fabsf(tile - gmod(p0, tile * 2)); p1 = fabsf(tile - gmod(p1, tile * 2)); p2 = fabsf(tile - gmod(p2, tile * 2));
        float pa = 0, a = 0;
        for (int i = 0; i < IT; ++i) {
            float d = p0 * p0 + p1 * p1 + p2 * p2 + 1e-6f;
            p0 = fabsf(p0) / d - formu; p1 = fabsf(p1) / d - formu; p2 = fabsf(p2) / d - formu;
            float l = sqrtf(p0 * p0 + p1 * p1 + p2 * p2); a += fabsf(l - pa); pa = l;
        }
        float dm = std::max(0.0f, dark - a * a * 0.001f);
        a = a * a * a;
        if (k > 6) fade *= 1.0f - dm;
        float q = a * bright * fade;
        r += fade + s * q; g += fade + s * s * q; b += fade + s * s * s * s * q;
        fade *= distf; s += stepsz;
    }
    float len = sqrtf(r * r + g * g + b * b);
    o[0] = (len + (r - len) * satr) * 0.01f; o[1] = (len + (g - len) * satr) * 0.01f; o[2] = (len + (b - len) * satr) * 0.01f;
}
// fire inner colour from the chams colour: brighter, hue pulled towards yellow (red -> orange, blue -> cyan)
inline void FireInner(const float* c, float o[3]) { o[0] = std::min(1.0f, c[0] * 0.8f + c[1] * 0.3f + 0.12f); o[1] = std::min(1.0f, c[1] * 0.75f + c[0] * 0.38f + c[2] * 0.25f + 0.05f); o[2] = std::min(1.0f, c[2] * 0.85f + 0.02f); }
// fire colour ramp: black -> outer -> inner -> hot
// animated Voronoi: F1, F2 distances (cells drift with time)
inline void Voronoi(float x, float y, float t, float& f1, float& f2, float& cid)
{
    int cx = (int)floorf(x), cy = (int)floorf(y); f1 = f2 = 9.0f; cid = 0.0f;
    for (int j = -1; j <= 1; ++j) for (int i = -1; i <= 1; ++i) {
        int gx = cx + i, gy = cy + j;
        float h1 = Hash2(gx, gy), h2 = Hash2(gx + 73, gy - 41);
        float px = gx + 0.5f + 0.42f * sinf(t * (0.6f + h1) + h1 * 6.28f), py = gy + 0.5f + 0.42f * cosf(t * (0.5f + h2) + h2 * 6.28f);
        float d = sqrtf((px - x) * (px - x) + (py - y) * (py - y));
        if (d < f1) { f2 = f1; f1 = d; cid = h1; } else if (d < f2) f2 = d;
    }
}
inline void FireRamp(float t, const float* co, const float* ci, float o[3])
{
    for (int i = 0; i < 3; ++i) {
        float hot = ci[i] * 0.45f + 0.62f;
        o[i] = t < 0.45f ? co[i] * (t / 0.45f) : (t < 0.8f ? lerpf(co[i], ci[i], (t - 0.45f) / 0.35f) : lerpf(ci[i], hot, (t - 0.8f) / 0.2f));
    }
}

struct Xf { float cy, sy, cp, sp, f, cx0, cy0; bool fp; float c[12], off[3]; };
Xf MakeXf(int W, int H, const M3DSettings& s)
{
    Xf x; x.cy = cosf(s.yaw); x.sy = sinf(s.yaw); x.cp = cosf(s.pitch); x.sp = sinf(s.pitch);
    x.f = 0.93f * H * CAM_D / 1.86f; x.cx0 = W * 0.5f; x.cy0 = H * 0.5f;
    x.fp = s.model == M3D_MODEL_FP;
    if (x.fp) {   // first person: camera baked into the model, perspective with the given fov
        for (int i = 0; i < 12; ++i) x.c[i] = FP_CAM[i];
        for (int i = 0; i < 3; ++i) x.off[i] = s.fpOff[i];
        float VW = (float)W, VH = (float)H, ox = 0, oy = 0;
        if (s.fpView[2] > 0) { ox = s.fpView[0]; oy = s.fpView[1]; VW = s.fpView[2]; VH = s.fpView[3]; }
        x.f = VH * 0.5f / tanf(s.fov * 0.5f * 3.14159265f / 180.0f);
        x.cx0 = VW * 0.5f - ox; x.cy0 = VH * 0.5f - oy;
    }
    return x;
}
// model space -> view space (camera on +Z looking at -Z)
inline void Rot(const Xf& x, float px, float py, float pz, float& ox, float& oy, float& oz)
{
    if (x.fp) {
        float dx = px - x.c[0], dy = py - x.c[1], dz = pz - x.c[2];
        ox = dx * x.c[3] + dy * x.c[4] + dz * x.c[5] + x.off[0];
        oy = dx * x.c[6] + dy * x.c[7] + dz * x.c[8] + x.off[1];
        oz = -(dx * x.c[9] + dy * x.c[10] + dz * x.c[11]) - x.off[2];
        return;
    }
    float dx = px, dy = py - CY, dz = pz;
    float rx = x.cy * dx + x.sy * dz, rz = -x.sy * dx + x.cy * dz;
    ox = rx; oy = x.cp * dy - x.sp * rz; oz = x.sp * dy + x.cp * rz;
}
inline void RotN(const Xf& x, float px, float py, float pz, float& ox, float& oy, float& oz)
{
    if (x.fp) { ox = px * x.c[3] + py * x.c[4] + pz * x.c[5]; oy = px * x.c[6] + py * x.c[7] + pz * x.c[8]; oz = -(px * x.c[9] + py * x.c[10] + pz * x.c[11]); return; }
    float rx = x.cy * px + x.sy * pz, rz = -x.sy * px + x.cy * pz;
    ox = rx; oy = x.cp * py - x.sp * rz; oz = x.sp * py + x.cp * rz;
}
inline void Proj(const Xf& x, float vx, float vy, float vz, float& sx, float& sy, float& d)
{
    d = x.fp ? -vz : CAM_D - vz; float k = x.f / std::max(d, 0.005f);
    sx = x.cx0 + vx * k; sy = x.cy0 - vy * k;
}
void Sample(const Tex& t, float u, float v, float out[3])
{
    if (!t.w) { out[0] = out[1] = out[2] = 0.8f; return; }
    float fx = u * t.w - 0.5f, fy = v * t.h - 0.5f;
    int x0 = (int)floorf(fx), y0 = (int)floorf(fy); float ax = fx - x0, ay = fy - y0;
    int mx = t.w - 1, my = t.h - 1;
    const unsigned char* r0 = &t.px[((y0 & my) * t.w) * 3]; const unsigned char* r1 = &t.px[(((y0 + 1) & my) * t.w) * 3];
    int c0 = (x0 & mx) * 3, c1 = ((x0 + 1) & mx) * 3;
    float w00 = (1 - ax) * (1 - ay), w10 = ax * (1 - ay), w01 = (1 - ax) * ay, w11 = ax * ay;
    for (int c = 0; c < 3; ++c) out[c] = (r0[c0 + c] * w00 + r0[c1 + c] * w10 + r1[c0 + c] * w01 + r1[c1 + c] * w11) * (1.0f / 255.0f);
}
void SampleT(const Tex& t, float u, float v, float out[3]) { Sample(t, u, v, out); }
void SampleL(const Tex& t, float u, float v, float lod, float out[3])
{
    if (lod <= 0.0f || t.lv.empty()) { Sample(t, u, v, out); return; }
    int n = (int)t.lv.size(); if (lod >= n) { Sample(t.lv[n - 1], u, v, out); return; }
    int l = (int)lod; float f = lod - l;
    const Tex& A = l == 0 ? t : t.lv[l - 1]; const Tex& B = t.lv[l];
    float a[3], b[3]; Sample(A, u, v, a); Sample(B, u, v, b);
    for (int c = 0; c < 3; ++c) out[c] = a[c] + (b[c] - a[c]) * f;
}
// separable box blur (in place via tmp), radius r
void BoxBlur(std::vector<float>& a, std::vector<float>& tmp, int W, int H, int r)
{
    if (r < 1) return;
    float inv = 1.0f / (2 * r + 1);
    ParFor(H, [&](int yb, int ye) {
    for (int y = yb; y < ye; ++y) {
        const float* s = &a[y * W]; float* d = &tmp[y * W]; float acc = 0;
        for (int i = -r; i <= r; ++i) acc += s[std::min(std::max(i, 0), W - 1)];
        for (int x = 0; x < W; ++x) {
            d[x] = acc * inv;
            acc += s[std::min(x + r + 1, W - 1)] - s[std::max(x - r, 0)];
        }
    } });
    ParFor(W, [&](int xb, int xe) {
    for (int x = xb; x < xe; ++x) {
        float acc = 0;
        for (int i = -r; i <= r; ++i) acc += tmp[std::min(std::max(i, 0), H - 1) * W + x];
        for (int y = 0; y < H; ++y) {
            a[y * W + x] = acc * inv;
            acc += tmp[std::min(y + r + 1, H - 1) * W + x] - tmp[std::max(y - r, 0) * W + x];
        }
    } });
}
}

static void LoadModel(int mi)
{
    MState& m = g_m[mi]; if (m.d) return;
    const MDef& d = DEFS[mi]; m.d = &d;
    m.nv = d.nv; m.ni = d.ni; m.widx = d.widx; m.ww = d.ww;
    for (int k = 0; k < d.ntex && k < 16; ++k) {
        int w, h, c;
        unsigned char* p = stbi_load_from_memory(d.tex[k], d.texsz[k], &w, &h, &c, 3);
        if (p) { m.tex[k].w = w; m.tex[k].h = h; m.tex[k].px.assign(p, p + w * h * 3); stbi_image_free(p); BuildMips(m.tex[k]); }
    }
    m.pos.resize(d.nv * 3); m.nrm.resize(d.nv * 3); m.uv.resize(d.nv * 2);
    for (int i = 0; i < d.nv * 3; ++i) { m.pos[i] = d.pos[i] / 16000.0f; m.nrm[i] = d.nrm[i] / 127.0f; }
    for (int i = 0; i < d.nv * 2; ++i) m.uv[i] = d.uv[i] / 65535.0f;
    m.idx.assign(d.idx, d.idx + d.ni);
    m.triTex.assign(d.ni / 3, 0);
    for (int p = 0; p < d.nprim; ++p) for (int i = d.prims[p][0] / 3; i < (d.prims[p][0] + d.prims[p][1]) / 3; ++i) m.triTex[i] = d.prims[p][2];
    m.wpos.resize(d.wnv * 3);
    for (int i = 0; i < d.wnv * 3; ++i) m.wpos[i] = d.wpos[i] / 16000.0f;
}
static void UseModel(int mi) { mi = mi < 0 ? 0 : (mi >= M3D_MODEL_COUNT ? M3D_MODEL_COUNT - 1 : mi); { std::lock_guard<std::recursive_mutex> lk(g_loadMx); LoadModel(mi); } g_cur = &g_m[mi]; }

bool M3D_Init()
{
    std::lock_guard<std::recursive_mutex> lk(g_loadMx);
    if (g_ok) return true;
    for (int k = 0; k < ST_COUNT; ++k) {
        int w, h, cc;
        unsigned char* p = stbi_load_from_memory(ST_TEX[k], ST_SIZE[k], &w, &h, &cc, 3);
        if (p) { g_st[k].w = w; g_st[k].h = h; g_st[k].px.assign(p, p + w * h * 3); stbi_image_free(p); }
    }
    LoadModel(0);
    g_ok = true;
    return true;
}

unsigned char* M3D_DecodeImage(const unsigned char* d, int n, int* w, int* h, int comp) { int c; return stbi_load_from_memory(d, n, w, h, &c, comp); }
void M3D_FreeImage(unsigned char* p) { stbi_image_free(p); }

static const int BSEG[][2] = { {0,2},{2,3},{3,4},{4,5},{4,7},{7,8},{8,9},{4,11},{11,12},{12,13},{0,14},{14,15},{15,16},{16,17},{0,18},{18,19},{19,20},{20,21} };
int M3D_BoneCount() { return (int)(sizeof(BSEG) / sizeof(BSEG[0])); }
float M3D_AnimLength() { return (float)DEFS[0].nf / DEFS[0].fps; }
void M3D_Bones(const M3DSettings& s, float (*out)[6])
{
    M3D_Init(); UseModel(s.model);
    Pose P; GetPose(s.anim, P);
    for (int i = 0; i < M3D_BoneCount(); ++i) for (int e = 0; e < 2; ++e) { int b = BSEG[i][e]; XfP(P.m[b], &AN_REST[b * 3], &out[i][e * 3]); }
}
void M3D_HeadPoint(const M3DSettings& s, float* xyz)
{
    M3D_Init(); UseModel(s.model);
    Pose P; GetPose(s.anim, P); XfP(P.m[5], g_cur->d->head, xyz);
}

void M3D_Project(float px, float py, float pz, int W, int H, const M3DSettings& s, float* sx, float* sy)
{
    Xf x = MakeXf(W, H, s); float vx, vy, vz, d;
    Rot(x, px, py, pz, vx, vy, vz); Proj(x, vx, vy, vz, *sx, *sy, d);
}

bool M3D_FpBounds(const M3DSettings& s0, int VW, int VH, float* bb)
{
    std::lock_guard<std::recursive_mutex> rl(g_renderMx);
    M3D_Init(); UseModel(s0.model);
    M3DSettings s = s0; s.fpView[0] = s.fpView[1] = s.fpView[2] = s.fpView[3] = 0;
    Xf x = MakeXf(VW, VH, s);
    const float* VP = g_pos.data();
    if (s.anim >= 0) {
        Pose P; GetPose(s.anim, P);
        g_spos.resize(MD_NV * 3); g_snrm.resize(MD_NV * 3);
        Skin(P, g_pos.data(), g_nrm.data(), AN_WIDX, AN_WW, MD_NV, g_spos.data(), g_snrm.data());
        VP = g_spos.data();
    }
    float x0 = 1e9f, y0 = 1e9f, x1 = -1e9f, y1 = -1e9f;
    for (int i = 0; i < MD_NV; ++i) {
        float vx, vy, vz, sx, sy, d; Rot(x, VP[i * 3], VP[i * 3 + 1], VP[i * 3 + 2], vx, vy, vz); Proj(x, vx, vy, vz, sx, sy, d);
        if (d < 0.03f) continue;
        x0 = std::min(x0, sx); y0 = std::min(y0, sy); x1 = std::max(x1, sx); y1 = std::max(y1, sy);
    }
    x0 = std::max(x0, 0.0f); y0 = std::max(y0, 0.0f); x1 = std::min(x1, (float)VW); y1 = std::min(y1, (float)VH);
    bb[0] = x0; bb[1] = y0; bb[2] = x1; bb[3] = y1;
    return x1 > x0 && y1 > y0;
}


// ---- ragdoll: the body (posed by the frozen animation) collapses onto the ground.
// The model is bent like a rod along its height: shins, thighs, torso and head rotate about knee / hip / neck
// "joints" (by height) towards the fall direction D; a falling-pendulum timing with a small bounce on impact.
std::vector<float> g_rpos, g_rnrm, g_rwpos;
struct RagK { float D[3], Pp[3]; float tabA[256], tabH[256]; float shift[3]; float drop; float B, K, Hh, Nk; };
static float RagPhi(const RagK& r, float y)
{
    auto S = [](float a, float b, float x) { float t = std::min(1.0f, std::max(0.0f, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
    return r.B + r.K * S(0.40f, 0.58f, y) + r.Hh * S(0.86f, 1.04f, y) + r.Nk * S(1.42f, 1.56f, y);
}
static const float RAG_Y0 = -0.2f, RAG_Y1 = 2.4f;
static void RagSetup(RagK& r, float t, float A)
{
    r.D[0] = sinf(A); r.D[1] = 0; r.D[2] = -cosf(A);
    r.Pp[0] = -r.D[2]; r.Pp[1] = 0; r.Pp[2] = r.D[0];
    const float T = 0.78f;
    float f;
    if (t < T) { float u = t / T; f = u * u * (0.35f + 0.65f * u); }
    else { float q = t - T; f = 1.0f - 0.07f * fabsf(sinf(q * 11.0f)) * expf(-q * 6.0f); }
    float bk = sinf(3.14159f * std::min(1.0f, std::max(0.0f, t / 0.62f))) * (1.0f - 0.6f * f);   // knees buckle first
    r.B = 0.92f * f - 0.32f * bk;
    r.K = 0.95f * f + 0.75f * bk;
    r.Hh = -0.32f * f - 0.30f * bk;
    r.Nk = 0.12f * f + 0.10f * bk;
    // centre line: integrate the up direction along the height
    float a = 0, h = 0; const float dy = (RAG_Y1 - RAG_Y0) / 255.0f;
    { float ph = RagPhi(r, RAG_Y0); a = RAG_Y0 * sinf(ph); h = RAG_Y0 * cosf(ph); }
    for (int i = 0; i < 256; ++i) {
        r.tabA[i] = a; r.tabH[i] = h;
        float ph = RagPhi(r, RAG_Y0 + (i + 0.5f) * dy);
        a += sinf(ph) * dy; h += cosf(ph) * dy;
    }
    float sh = 0.85f * f;   // slide back so the body lies around the origin (stays in the preview)
    r.shift[0] = -r.D[0] * sh; r.shift[1] = 0; r.shift[2] = -r.D[2] * sh;
    r.drop = 0;
}
static inline void RagXf(const RagK& r, const float* p, const float* n, float* op, float* on)
{
    float y = p[1];
    float fi = (y - RAG_Y0) / (RAG_Y1 - RAG_Y0) * 255.0f; fi = std::min(254.999f, std::max(0.0f, fi));
    int i = (int)fi; float u = fi - i;
    float ca = r.tabA[i] + (r.tabA[i + 1] - r.tabA[i]) * u, ch = r.tabH[i] + (r.tabH[i + 1] - r.tabH[i]) * u;
    float ph = RagPhi(r, y), c = cosf(ph), s = sinf(ph);
    float od = p[0] * r.D[0] + p[2] * r.D[2], opp = p[0] * r.Pp[0] + p[2] * r.Pp[2];
    // forward F = c*D - s*Y, up U = c*Y + s*D
    float fd = od * c, fy = -od * s;
    for (int k = 0; k < 3; k += 2) op[k] = r.D[k] * (ca + fd) + r.Pp[k] * opp + r.shift[k];
    op[1] = ch + fy;
    if (n && on) {
        float nd = n[0] * r.D[0] + n[2] * r.D[2], np = n[0] * r.Pp[0] + n[2] * r.Pp[2], ny = n[1];
        float ad = nd * c + ny * s, ay = -nd * s + ny * c;
        for (int k = 0; k < 3; k += 2) on[k] = r.D[k] * ad + r.Pp[k] * np;
        on[1] = ay;
    }
}
static void RagApply(const M3DSettings& s, const float*& VP, const float*& VN, const float*& WPv, bool wire)
{
    RagK r; RagSetup(r, s.rag, s.ragA);
    const int n = MD_NV;
    g_rpos.resize(n * 3); g_rnrm.resize(n * 3);
    const float* P0 = VP; const float* N0 = VN;
    ParFor(n, [&](int b, int e) { for (int i = b; i < e; ++i) RagXf(r, &P0[i * 3], &N0[i * 3], &g_rpos[i * 3], &g_rnrm[i * 3]); });
    float mn = 1e9f; for (int i = 0; i < n; ++i) mn = std::min(mn, g_rpos[i * 3 + 1]);
    float lift = -mn; if (lift < 0) lift = 0;
    for (int i = 0; i < n; ++i) g_rpos[i * 3 + 1] += lift;
    VP = g_rpos.data(); VN = g_rnrm.data();
    if (wire) {
        g_rwpos.resize(MD_WNV * 3);
        for (int i = 0; i < MD_WNV; ++i) { RagXf(r, &WPv[i * 3], nullptr, &g_rwpos[i * 3], nullptr); g_rwpos[i * 3 + 1] += lift; }
        WPv = g_rwpos.data();
    }
}
void M3D_RagPoint(const M3DSettings& s, const float* in, float* out)
{
    if (s.rag < 0) { out[0] = in[0]; out[1] = in[1]; out[2] = in[2]; return; }
    RagK r; RagSetup(r, s.rag, s.ragA); RagXf(r, in, nullptr, out, nullptr);
}
static void GalaxyShade(int px, int py, int H, float T_, const float* C, float F, float& r, float& g, float& b)   // screen-space nebula + stars
{
                float T = T_;
                float u = (float)px / H * 4.0f + T * 0.05f, v = (float)py / H * 4.0f - T * 0.03f;
                float wx = Fbm(u * 0.7f + 3.1f, v * 0.7f), wy = Fbm(u * 0.7f, v * 0.7f + 7.7f);
                float n1 = Fbm(u + wx * 1.6f, v + wy * 1.6f), n2 = Fbm(u * 1.7f - wy * 1.2f + 9.0f, v * 1.7f + wx * 1.2f);
                float neb1 = sat((n1 - 0.32f) * 2.2f), neb2 = sat((n2 - 0.40f) * 2.6f);
                neb1 *= neb1; neb2 *= neb2 * neb2;
                float C2[3] = { C[2] * 0.9f + 0.1f, C[0] * 0.5f + 0.1f, C[1] * 0.6f + 0.35f };   // second nebula hue
                r = 0.015f + C[0] * neb1 * 1.25f + C2[0] * neb2 * 0.9f;
                g = 0.010f + C[1] * neb1 * 1.25f + C2[1] * neb2 * 0.9f;
                b = 0.045f + C[2] * neb1 * 1.25f + C2[2] * neb2 * 0.9f;
                // stars: one candidate per cell, twinkling
                float star = 0.0f;
                for (int L = 0; L < 2; ++L) {
                    float cs = L ? 9.0f : 5.0f;
                    float gx = px / cs + T * (L ? 0.35f : 0.6f), gy = py / cs;
                    int cx = (int)floorf(gx), cy = (int)floorf(gy);
                    float hsh = Hash2(cx + L * 911, cy);
                    if (hsh > (L ? 0.80f : 0.90f)) {
                        float sx = cx + 0.2f + 0.6f * Hash2(cx, cy + 77), sy = cy + 0.2f + 0.6f * Hash2(cx + 55, cy);
                        float dx = (gx - sx) * cs, dy = (gy - sy) * cs, d2 = dx * dx + dy * dy;
                        float tw = 0.55f + 0.45f * sinf(T * (2.0f + hsh * 5.0f) + hsh * 40.0f);
                        float rad = L ? 1.6f : 1.0f;
                        star += expf(-d2 / (rad * rad)) * tw * (L ? 1.0f : 0.7f);
                    }
                }
                r += star; g += star; b += star;
                float rim = F * F * 0.9f;
                r += C[0] * rim; g += C[1] * rim; b += C[2] * rim;
}
void M3D_Render(uint8_t* rgba, int W, int H, const M3DSettings& s, M3DOut* out)
{
    std::lock_guard<std::recursive_mutex> rl(g_renderMx);   // shared scratch buffers: one render at a time
    M3D_Init(); UseModel(s.model);
    if (s.look && s.model >= 1 && s.model <= 2 && g_look[s.model].key == s.look) g_cur = &g_look[s.model];
    const int N = W * H;
    zb.assign(N, 1e9f); tid.assign(N, -1); bA.resize(N); bB.resize(N);
    Xf x = MakeXf(W, H, s);
    // ---- vertices
    const float* VP = g_pos.data(); const float* VN = g_nrm.data(); const float* WPv = g_wpos.data();
    if (s.anim >= 0) {
        Pose P; GetPose(s.anim, P);
        g_spos.resize(MD_NV * 3); g_snrm.resize(MD_NV * 3); g_swpos.resize(MD_WNV * 3);
        Skin(P, g_pos.data(), g_nrm.data(), AN_WIDX, AN_WW, MD_NV, g_spos.data(), g_snrm.data());
        if (s.mat == M3D_WIREFRAME || s.mat == M3D_GALAXYWIRE) Skin(P, g_wpos.data(), nullptr, AN_WWIDX, AN_WWW, MD_WNV, g_swpos.data(), nullptr);
        VP = g_spos.data(); VN = g_snrm.data(); WPv = g_swpos.data();
    }
    if (s.rag >= 0 && !x.fp) RagApply(s, VP, VN, WPv, s.mat == M3D_WIREFRAME || s.mat == M3D_GALAXYWIRE);
    vs.resize(MD_NV * 6);
    for (int i = 0; i < MD_NV; ++i) {
        float vx, vy, vz; Rot(x, VP[i * 3], VP[i * 3 + 1], VP[i * 3 + 2], vx, vy, vz);
        float* o = &vs[i * 6]; Proj(x, vx, vy, vz, o[0], o[1], o[2]);
        RotN(x, VN[i * 3], VN[i * 3 + 1], VN[i * 3 + 2], o[3], o[4], o[5]);
    }
    // ---- raster: depth + triangle id + barycentrics
    const int NT = MD_NI / 3;
    const uint32_t* RI = MD_IDX;              // raster vertex indices (into vs)
    if (s.mat == M3D_DISSOLVE) {               // geometric dissolve: a band of triangles flies off the body and comes back
        g_tp.assign(NT, 0.0f); g_seq.resize(NT * 3);
        std::vector<float> ex(NT * 3 * 6);
        float front = gmod(s.time * 0.42f, 2.6f) - 0.4f;
        ParFor(NT, [&](int tb, int te) {
        for (int t = tb; t < te; ++t) {
            int ii[3] = { (int)MD_IDX[t * 3], (int)MD_IDX[t * 3 + 1], (int)MD_IDX[t * 3 + 2] };
            float cy = (g_pos[ii[0] * 3 + 1] + g_pos[ii[1] * 3 + 1] + g_pos[ii[2] * 3 + 1]) / 3.0f;
            float j = Hash2(t, 911);
            float p = sat(1.0f - fabsf(cy - front + (j - 0.5f) * 0.22f) / 0.20f); p = p * p * (3 - 2 * p);
            g_tp[t] = p;
            float c3[3] = { 0, 0, 0 }, nn[3] = { 0, 0, 0 };
            for (int e = 0; e < 3; ++e) for (int q = 0; q < 3; ++q) { c3[q] += VP[ii[e] * 3 + q] / 3.0f; nn[q] += VN[ii[e] * 3 + q]; }
            float nl = sqrtf(nn[0] * nn[0] + nn[1] * nn[1] + nn[2] * nn[2]) + 1e-6f;
            float trv = p * (0.10f + 0.12f * j), sc = 1.0f - p * 0.85f;
            for (int e = 0; e < 3; ++e) {
                float q3[3];
                for (int q = 0; q < 3; ++q) q3[q] = c3[q] + (VP[ii[e] * 3 + q] - c3[q]) * sc + nn[q] / nl * trv;
                q3[1] += p * 0.05f;
                float vx, vy, vz; Rot(x, q3[0], q3[1], q3[2], vx, vy, vz);
                float* o = &ex[(t * 3 + e) * 6]; Proj(x, vx, vy, vz, o[0], o[1], o[2]);
                RotN(x, VN[ii[e] * 3], VN[ii[e] * 3 + 1], VN[ii[e] * 3 + 2], o[3], o[4], o[5]);
                g_seq[t * 3 + e] = (uint32_t)(t * 3 + e);
            }
        } });
        vs.swap(ex); RI = g_seq.data();
    }
    ParFor(H, [&](int yb, int ye) {
    for (int t = 0; t < NT; ++t) {
        const float* a = &vs[RI[t * 3] * 6]; const float* b = &vs[RI[t * 3 + 1] * 6]; const float* c = &vs[RI[t * 3 + 2] * 6];
        if (a[2] < 0.03f || b[2] < 0.03f || c[2] < 0.03f) continue;   // near plane (first-person arms)
        float area = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
        if (fabsf(area) < 1e-8f) continue;
        const float iza = 1.0f / a[2], izb = 1.0f / b[2], izc = 1.0f / c[2];
        float ia = 1.0f / area;
        int x0 = std::max(0, (int)floorf(std::min({ a[0], b[0], c[0] }))), x1 = std::min(W - 1, (int)ceilf(std::max({ a[0], b[0], c[0] })));
        int y0 = std::max(yb, (int)floorf(std::min({ a[1], b[1], c[1] }))), y1 = std::min(ye - 1, (int)ceilf(std::max({ a[1], b[1], c[1] })));
        if (y0 > y1) continue;
        // edge functions as linear forms: w(x, y) = A x + B y + C
        float A1 = (c[1] - a[1]) * ia, B1 = -(c[0] - a[0]) * ia, C1 = (-a[0] * (c[1] - a[1]) + a[1] * (c[0] - a[0])) * ia;
        float A2 = -(b[1] - a[1]) * ia, B2 = (b[0] - a[0]) * ia, C2 = (-(b[0] - a[0]) * a[1] + (b[1] - a[1]) * a[0]) * ia;
        float dz1 = b[2] - a[2], dz2 = c[2] - a[2];
        for (int py = y0; py <= y1; ++py) {
            float fy = py + 0.5f, fx = x0 + 0.5f;
            float w1 = A1 * fx + B1 * fy + C1, w2 = A2 * fx + B2 * fy + C2;
            float* zr = &zb[py * W]; int* tr = &tid[py * W]; float* ar = &bA[py * W]; float* br = &bB[py * W];
            for (int px = x0; px <= x1; ++px, w1 += A1, w2 += A2) {
                if (w1 < -1e-5f || w2 < -1e-5f || w1 + w2 > 1.00001f) continue;
                float z = a[2] + dz1 * w1 + dz2 * w2;
                if (z < zr[px]) {
                    zr[px] = z; tr[px] = t;
                    if (x.fp) { float q0 = (1 - w1 - w2) * iza, q1 = w1 * izb, q2 = w2 * izc, qs = 1.0f / (q0 + q1 + q2); ar[px] = q1 * qs; br[px] = q2 * qs; }   // perspective-correct
                    else { ar[px] = w1; br[px] = w2; }
                }
            }
        }
    }
    });
    // ---- shading (premultiplied rgba)
    cm.assign(N * 4, 0.0f);
    const float L[3] = { 0.42f, 0.68f, 0.60f };
    const float Ln = 1.0f / sqrtf(L[0] * L[0] + L[1] * L[1] + L[2] * L[2]);
    const float lx = L[0] * Ln, ly = L[1] * Ln, lz = L[2] * Ln;
    float hx = lx, hy = ly, hz = lz + 1.0f; { float l = 1.0f / sqrtf(hx * hx + hy * hy + hz * hz); hx *= l; hy *= l; hz *= l; }
    const float* C = s.col; const float CA = s.col[3];
    const int SNS = 3, SW = (W + SNS - 1) / SNS, SH = (H + SNS - 1) / SNS;
    if (s.mat == M3D_STARNEST) {
        g_snm.assign(SW * SH, 0); g_snb.assign(SW * SH * 3, 0.0f);
        for (int py = 0; py < H; ++py) for (int px = 0; px < W; ++px) if (tid[py * W + px] >= 0) {
            int X = px / SNS, Y = py / SNS;
            for (int dy = -1; dy <= 1; ++dy) for (int dx = -1; dx <= 1; ++dx) { int a = X + dx, b = Y + dy; if (a >= 0 && b >= 0 && a < SW && b < SH) g_snm[b * SW + a] = 1; }
        }
        ParFor(SH, [&](int yb, int ye) {
            for (int Y = yb; Y < ye; ++Y) for (int X = 0; X < SW; ++X) if (g_snm[Y * SW + X])
                StarNest(((X + 0.5f) * SNS - W * 0.5f) / H, -((Y + 0.5f) * SNS - H * 0.5f) / H, s.time * 4.0f, &g_snb[(Y * SW + X) * 3]);
        });
    }
    ParFor(H, [&](int yb, int ye) {
    for (int py = yb; py < ye; ++py)
        for (int px = 0; px < W; ++px) {
            int k = py * W + px; int t = tid[k];
            if (t < 0) continue;
            int i0 = MD_IDX[t * 3], i1 = MD_IDX[t * 3 + 1], i2 = MD_IDX[t * 3 + 2];
            float w1 = bA[k], w2 = bB[k], w0 = 1.0f - w1 - w2;
            const float* n0 = &vs[RI[t * 3] * 6 + 3]; const float* n1 = &vs[RI[t * 3 + 1] * 6 + 3]; const float* n2 = &vs[RI[t * 3 + 2] * 6 + 3];
            float nx = n0[0] * w0 + n1[0] * w1 + n2[0] * w2, ny = n0[1] * w0 + n1[1] * w1 + n2[1] * w2, nz = n0[2] * w0 + n1[2] * w1 + n2[2] * w2;
            float nl = sqrtf(nx * nx + ny * ny + nz * nz); if (nl < 1e-6f) { nz = 1; nl = 1; }
            nx /= nl; ny /= nl; nz /= nl;
            if (nz < 0) { nx = -nx; ny = -ny; nz = -nz; }
            float F = 1.0f - nz;                        // fresnel term
            float ndl = std::max(0.0f, nx * lx + ny * ly + nz * lz);
            float spec = powf(std::max(0.0f, nx * hx + ny * hy + nz * hz), 36.0f);
            float r = 0, g = 0, b = 0, al = 1;
            auto textured = [&](float& rr, float& gg, float& bb) {
                float u = g_uv[i0 * 2] * w0 + g_uv[i1 * 2] * w1 + g_uv[i2 * 2] * w2, v = g_uv[i0 * 2 + 1] * w0 + g_uv[i1 * 2 + 1] * w1 + g_uv[i2 * 2 + 1] * w2;
                const Tex& TX = g_tex[g_triTex[t]];
                float lod = 0.0f;
                {
                    const float* A = &vs[RI[t * 3] * 6]; const float* B = &vs[RI[t * 3 + 1] * 6]; const float* Cc = &vs[RI[t * 3 + 2] * 6];
                    float sa = fabsf((B[0] - A[0]) * (Cc[1] - A[1]) - (B[1] - A[1]) * (Cc[0] - A[0]));
                    const float* q0 = &g_uv[i0 * 2]; const float* q1 = &g_uv[i1 * 2]; const float* q2 = &g_uv[i2 * 2];
                    float ta = fabsf((q1[0] - q0[0]) * (q2[1] - q0[1]) - (q1[1] - q0[1]) * (q2[0] - q0[0])) * TX.w * TX.h;
                    if (sa > 1e-6f && ta > 0) lod = 0.5f * log2f(ta / sa) - 0.35f;
                }
                float tc[3]; SampleL(TX, u, v, lod, tc);
                float lit = 0.40f + 0.10f * ny + 0.78f * ndl;
                float rim = powf(F, 3.0f) * 0.22f;
                rr = tc[0] * lit + spec * 0.12f + rim * 0.75f; gg = tc[1] * lit + spec * 0.12f + rim * 0.82f; bb = tc[2] * lit + spec * 0.12f + rim;
            };
            switch (s.mat) {
            default:
            case M3D_TEXTURED: textured(r, g, b); break;
            case M3D_FLAT: r = C[0]; g = C[1]; b = C[2]; al = CA; break;
            case M3D_GLOW: {
                float e = 0.10f + 1.25f * powf(F, 1.6f);
                float w = powf(F, 4.0f) * 0.45f;
                r = C[0] * e + w; g = C[1] * e + w; b = C[2] * e + w;
                al = CA * sat(0.30f + 0.85f * powf(F, 1.1f));
            } break;
            case M3D_GLOW_OUTLINE: {
                textured(r, g, b);
                float e = powf(F, 2.2f) * 1.1f;
                r = r * (1 - e * 0.5f) + C[0] * e; g = g * (1 - e * 0.5f) + C[1] * e; b = b * (1 - e * 0.5f) + C[2] * e;
            } break;
            case M3D_GLASS: {
                float e = powf(F, 1.5f);
                float sp = spec * 0.9f + powf(std::max(0.0f, nx * hx + ny * hy + nz * hz), 180.0f) * 0.8f;
                r = lerpf(C[0] * 0.55f, C[0], e) + sp; g = lerpf(C[1] * 0.55f, C[1], e) + sp; b = lerpf(C[2] * 0.55f, C[2], e) + sp;
                al = CA * sat(0.14f + 0.85f * e + sp);
            } break;
            case M3D_GALAXYWIRE: {   // wireframe with the galaxy texture: faint nebula body, the lines carry the galaxy
                GalaxyShade(px, py, H, s.time, C, F, r, g, b);
                r *= 0.55f; g *= 0.55f; b *= 0.55f; al = CA * (0.10f + 0.16f * powf(F, 2.0f));
            } break;
            case M3D_WIREFRAME: r = C[0] * 0.5f; g = C[1] * 0.5f; b = C[2] * 0.5f; al = CA * (0.06f + 0.12f * powf(F, 2.0f)); break;
            case M3D_WATERFLOW: {   // flowing water: running caustic web, rippled normals -> refraction tint, reflections, foam
                const float T = s.time;
                float mp[3];
                for (int q = 0; q < 3; ++q) mp[q] = g_pos[i0 * 3 + q] * w0 + g_pos[i1 * 3 + q] * w1 + g_pos[i2 * 3 + q] * w2;
                float u = (mp[0] + mp[2] * 0.7f) * 2.4f, v = mp[1] * 2.4f + T * 0.32f;                 // water runs down the body
                // ripple normal from noise gradient
                float e0 = Fbm(u * 3.0f, v * 3.0f), ex = Fbm(u * 3.0f + 0.04f, v * 3.0f), ey = Fbm(u * 3.0f, v * 3.0f + 0.04f);
                float gx = (ex - e0) * 12.0f, gy = (ey - e0) * 12.0f;
                float rnx = nx + gx * 0.35f, rny = ny + gy * 0.35f, rnz = nz; float rl = sqrtf(rnx * rnx + rny * rny + rnz * rnz); rnx /= rl; rny /= rl; rnz /= rl;
                // caustics (iterated trig web, flowing)
                const float TAU = 6.2831853f;
                float cpx = fmodf(u * 1.3f * TAU + 1000.0f, TAU) - 250.0f + gx * 0.6f, cpy = fmodf(v * 1.3f * TAU + 1000.0f, TAU) - 250.0f + gy * 0.6f;
                float ix = cpx, iy = cpy, cc = 1.0f; const float inten = 0.005f;
                for (int n = 0; n < 4; ++n) {
                    float tt = T * 0.55f * (1.0f - 3.5f / (n + 1));
                    float nix = cpx + cosf(tt - ix) + sinf(tt + iy), niy = cpy + sinf(tt - iy) + cosf(tt + ix);
                    ix = nix; iy = niy;
                    float ax = cpx / (sinf(ix + tt) / inten), ay = cpy / (cosf(iy + tt) / inten);
                    cc += 1.0f / std::max(1e-4f, sqrtf(ax * ax + ay * ay));
                }
                cc /= 4.0f; cc = 1.17f - powf(cc, 1.4f);
                float caus = sat(powf(fabsf(cc), 6.0f) * 1.4f);
                float Fw = 1.0f - std::max(0.0f, rnz);
                float sp = powf(std::max(0.0f, rnx * hx + rny * hy + rnz * hz), 60.0f) * 1.2f + powf(std::max(0.0f, rnx * hx + rny * hy + rnz * hz), 12.0f) * 0.15f;
                float depth = 0.55f + 0.45f * e0;                                                       // thicker / thinner water
                float foam = sstep(0.62f, 0.78f, Fbm(u * 6.0f, v * 2.0f + T * 0.4f)) * 0.35f;
                float deep[3] = { C[0] * 0.22f, C[1] * 0.30f, C[2] * 0.42f };
                for (int q = 0; q < 3; ++q) {
                    float c = deep[q] * depth + C[q] * (0.30f * (1.0f - depth) + caus * 1.1f) + C[q] * Fw * 0.8f + 0.55f * Fw * Fw * Fw;
                    c += sp + foam * 0.8f + caus * 0.30f;
                    (q == 0 ? r : q == 1 ? g : b) = c;
                }
                al = CA * sat(0.60f + 0.35f * Fw + caus * 0.35f + sp + foam);
            } break;
            case M3D_GALAXY: {   // screen-space nebula + twinkling stars (Rust-style galaxy chams)
                GalaxyShade(px, py, H, s.time, C, F, r, g, b);
                al = CA;
            } break;
            case M3D_GHOST: {   // spectral body: transparent core, bright fresnel edge, wisps drifting upwards, legs fading out
                const float T = s.time;
                float mp[3];
                for (int q = 0; q < 3; ++q) mp[q] = g_pos[i0 * 3 + q] * w0 + g_pos[i1 * 3 + q] * w1 + g_pos[i2 * 3 + q] * w2;
                float n1 = Fbm(mp[0] * 5.0f + mp[2] * 3.0f + sinf(T * 0.6f) * 0.4f, mp[1] * 4.0f - T * 0.55f);
                float n2 = Fbm(mp[0] * 9.0f - mp[2] * 7.0f + 4.7f, mp[1] * 7.0f - T * 0.9f + 2.3f);
                float wisp = sat((n1 * 0.65f + n2 * 0.45f - 0.38f) * 2.4f);
                float rim = powf(F, 1.7f), edge = powf(F, 4.0f);
                const float scan = 1.0f;
                float flick = 0.92f + 0.08f * sinf(T * 13.0f) * sinf(T * 5.3f + 1.0f);
                float legs = 0.25f + 0.75f * sstep(0.05f, 0.85f, mp[1]);
                float e = (0.10f + 0.45f * wisp + 1.05f * rim) * scan * flick;
                r = C[0] * e + edge * 0.40f; g = C[1] * e + edge * 0.40f; b = C[2] * e + edge * 0.40f;
                al = CA * sat((0.06f + 0.32f * wisp + 0.95f * rim) * flick * legs);
            } break;
            case M3D_HOLOGRAM: {   // Rust / Valorant style hologram: scanlines, sweeping scan band, glitch slices, bright fresnel
                const float T = s.time;
                float mp[3];
                for (int q = 0; q < 3; ++q) mp[q] = g_pos[i0 * 3 + q] * w0 + g_pos[i1 * 3 + q] * w1 + g_pos[i2 * 3 + q] * w2;
                float sl = powf(0.5f + 0.5f * sinf(mp[1] * 260.0f - T * 9.0f), 3.0f);              // fine scanlines crawling up
                float bpos = fmodf(T * 0.55f, 2.6f) - 0.4f;                                          // scan band sweeping bottom -> top
                float bd = (mp[1] - bpos) / 0.045f, band = expf(-bd * bd) + 0.35f * expf(-(mp[1] - bpos + 0.12f) * (mp[1] - bpos + 0.12f) / 0.012f);
                float gt = floorf(T * 9.0f), slice = floorf(mp[1] * 34.0f);
                float gl = Hash2((int)gt, 17) > 0.72f && Hash2((int)slice, (int)gt) > 0.80f ? 1.0f : 0.0f;   // glitch: random slices flash
                float flick = 0.93f + 0.07f * sinf(T * 31.0f) * sinf(T * 11.7f + 2.0f);
                float rim = powf(F, 1.8f), edge = powf(F, 5.0f);
                float e = (0.14f + 0.30f * sl + 1.05f * rim + 1.3f * band + 0.8f * gl) * flick;
                r = C[0] * e + edge * 0.35f + band * 0.30f + gl * 0.10f;
                g = C[1] * e + edge * 0.35f + band * 0.30f;
                b = C[2] * e + edge * 0.35f + band * 0.30f + gl * 0.25f;
                al = CA * sat((0.16f + 0.22f * sl + 0.85f * rim + band + 0.5f * gl) * flick);
            } break;
            case M3D_PULSE: {   // Valorant-style neon pulse: rings radiating from the chest on every heartbeat, neon fresnel
                const float T = s.time;
                float mp[3];
                for (int q = 0; q < 3; ++q) mp[q] = g_pos[i0 * 3 + q] * w0 + g_pos[i1 * 3 + q] * w1 + g_pos[i2 * 3 + q] * w2;
                float dx = mp[0], dy = mp[1] - 1.28f, dz = mp[2] - 0.05f, d = sqrtf(dx * dx + dy * dy + dz * dz);
                float wv = d * 2.6f - T * 1.1f; wv -= floorf(wv);
                float ring = powf(1.0f - wv, 7.0f) + 0.55f * expf(-wv * wv / 0.0012f);                    // bright leading edge + fading trail
                ring *= 0.35f + 0.65f * (1.0f - sstep(0.0f, 1.4f, d));
                float bt = fmodf(T, 1.1f), beat = expf(-bt * 9.0f) + 0.6f * expf(-(bt - 0.22f) * (bt - 0.22f) * 200.0f);   // lub-dub
                float rim = powf(F, 2.0f);
                float e = 0.10f + 0.95f * rim + 1.15f * ring + 0.35f * beat * (0.4f + rim);
                r = C[0] * e + ring * ring * 0.25f + spec * 0.2f; g = C[1] * e + ring * ring * 0.25f + spec * 0.2f; b = C[2] * e + ring * ring * 0.25f + spec * 0.2f;
                al = CA * sat(0.35f + 0.7f * rim + ring + 0.2f * beat);
            } break;
            case M3D_CRYSTAL: {   // Radianite crystal: faceted body, light sweep across facets, twinkling facets, deep core
                const float T = s.time;
                float mp[3];
                for (int q = 0; q < 3; ++q) mp[q] = g_pos[i0 * 3 + q] * w0 + g_pos[i1 * 3 + q] * w1 + g_pos[i2 * 3 + q] * w2;
                float fh = Hash2(t, 7), fh2 = Hash2(t, 131);
                float facet = 0.55f + 0.45f * fh;                                                  // each triangle its own tone
                float sw = mp[1] * 0.9f + mp[0] * 0.6f - T * 0.7f; sw -= floorf(sw / 2.2f) * 2.2f;    // diagonal sweep
                float sweep = expf(-(sw - 1.1f) * (sw - 1.1f) / 0.05f) * (0.5f + 0.5f * facet);
                float tw = fh2 > 0.93f ? powf(0.5f + 0.5f * sinf(T * (2.5f + fh * 3.0f) + fh2 * 50.0f), 6.0f) : 0.0f;
                float edge = sat(1.0f - std::min(w0, std::min(w1, w2)) / 0.06f);                     // facet edges
                float rim = powf(F, 1.6f);
                float core = 0.20f + 0.30f * facet * (0.5f + 0.5f * ndl);
                float sp2 = powf(std::max(0.0f, nx * hx + ny * hy + nz * hz), 90.0f);
                float wht = sweep * 0.22f + tw * 0.30f + sp2 * 0.6f + edge * 0.06f;
                float k = core + rim * 0.95f + sweep * 0.55f + tw * 0.45f + edge * 0.30f;
                r = C[0] * k + wht; g = C[1] * k + wht; b = C[2] * k + wht;
                al = CA * sat(0.62f + 0.35f * rim + 0.5f * sweep + 0.3f * tw);
            } break;
            case M3D_REAVER: {   // Valorant Reaver: dark gunmetal body, glowing veins flowing and pulsing up the body
                const float T = s.time;
                float mp[3];
                for (int q = 0; q < 3; ++q) mp[q] = g_pos[i0 * 3 + q] * w0 + g_pos[i1 * 3 + q] * w1 + g_pos[i2 * 3 + q] * w2;
                float u = (mp[0] + mp[2] * 0.8f) * 3.2f, v = mp[1] * 3.2f;
                float wx = Fbm(u * 0.8f + T * 0.07f, v * 0.8f), wy = Fbm(u * 0.8f + 5.2f, v * 0.8f - T * 0.05f);
                float n1 = Fbm(u + wx * 1.4f, v + wy * 1.4f - T * 0.12f);
                float ridge = 1.0f - fabsf(n1 * 2.0f - 1.0f);
                float vein = powf(sat(ridge), 18.0f), halo = powf(sat(ridge), 5.0f) * 0.35f;
                float n2 = Fbm(u * 2.3f - 3.0f, v * 2.3f + T * 0.2f);
                float vein2 = powf(sat(1.0f - fabsf(n2 * 2.0f - 1.0f)), 26.0f) * 0.6f;
                float pulse = 0.55f + 0.45f * powf(0.5f + 0.5f * sinf(mp[1] * 5.0f - T * 3.2f), 3.0f);   // energy travelling up
                float glow = (vein + vein2 + halo) * pulse;
                float metal = 0.035f + 0.10f * ndl + 0.06f * powf(F, 2.5f);
                float chrome = spec * 0.45f + powf(std::max(0.0f, nx * hx + ny * hy + nz * hz), 140.0f) * 0.5f;
                r = metal * 0.9f + chrome + C[0] * glow * 1.6f + glow * glow * 0.25f + C[0] * powf(F, 3.0f) * 0.35f;
                g = metal * 0.92f + chrome + C[1] * glow * 1.6f + glow * glow * 0.25f + C[1] * powf(F, 3.0f) * 0.35f;
                b = metal + chrome + C[2] * glow * 1.6f + glow * glow * 0.25f + C[2] * powf(F, 3.0f) * 0.35f;
                al = CA;
            } break;
            case M3D_SINGULARITY: {   // Valorant Singularity: void body, spiral vortex swirling into the chest, sparks pulled in
                const float T = s.time;
                float mp[3];
                for (int q = 0; q < 3; ++q) mp[q] = g_pos[i0 * 3 + q] * w0 + g_pos[i1 * 3 + q] * w1 + g_pos[i2 * 3 + q] * w2;
                float dx = mp[0] + mp[2] * 0.3f, dy = mp[1] - 1.15f;
                float rr = sqrtf(dx * dx + dy * dy), ang = atan2f(dy, dx);
                float sp1 = ang * 3.0f + logf(rr + 0.05f) * 7.0f + T * 2.0f;                          // log spiral arms turning inward
                float arms = powf(0.5f + 0.5f * sinf(sp1), 7.0f);
                float tur = Fbm(rr * 5.0f - T * 0.9f, ang * 1.6f + rr * 2.0f);
                float swirl = sat(arms * (0.5f + 1.1f * tur) * (0.45f + 0.9f * expf(-rr * 1.6f)));
                float sparks = 0.0f;
                {   // particles falling inward along the spiral
                    float pr = rr * 9.0f + T * 2.4f, cell = floorf(pr);
                    float pa = ang * 6.0f / 6.2831853f * 4.0f; float ca = floorf(pa);
                    float hsh = Hash2((int)cell, (int)ca + 40);
                    if (hsh > 0.84f) { float fx = pr - cell - 0.5f, fy = pa - ca - 0.5f; sparks = expf(-(fx * fx + fy * fy) * 40.0f) * (0.6f + 0.4f * sinf(T * 9.0f + hsh * 30.0f)); }
                }
                float core = expf(-rr * rr / 0.012f);                                                 // black-hole centre with a bright ring
                float ring = expf(-(rr - 0.13f) * (rr - 0.13f) / 0.0012f) * (0.7f + 0.3f * sinf(T * 4.0f));
                float C2[3] = { C[0] * 0.6f + C[2] * 0.4f, C[1] * 0.3f, C[2] * 0.9f + 0.1f };
                float rim = powf(F, 2.2f);
                for (int q = 0; q < 3; ++q) {
                    float c = 0.012f + C[q] * swirl * 1.2f + C2[q] * tur * 0.12f + C[q] * rim * 0.55f + (C[q] * 0.6f + 0.4f) * (ring + sparks) + swirl * swirl * 0.25f + spec * 0.15f;
                    c *= 1.0f - core * 0.95f;
                    (q == 0 ? r : q == 1 ? g : b) = c;
                }
                al = CA;
            } break;
            case M3D_ENCHANT: {   // Minecraft enchantment glint: textured model + two purple glint layers sliding diagonally
                const float T = s.time;
                textured(r, g, b);
                float mp[3];
                for (int q = 0; q < 3; ++q) mp[q] = g_pos[i0 * 3 + q] * w0 + g_pos[i1 * 3 + q] * w1 + g_pos[i2 * 3 + q] * w2;
                float u = (mp[0] + mp[2] * 0.7f) * 3.0f, v = mp[1] * 3.0f;
                auto layer = [&](float ang, float spd, float sc) {
                    float ca = cosf(ang), sa = sinf(ang);
                    float x = (u * ca - v * sa) * sc, y = (u * sa + v * ca) * sc;
                    float n = Fbm(x * 0.6f + T * spd, y * 7.0f);                                  // long streaks along x
                    return powf(sat((n - 0.38f) * 2.4f), 2.2f);
                };
                float gl = layer(0.52f, 0.55f, 1.0f) + layer(-0.95f, -0.42f, 1.3f) * 0.8f;
                float gc[3] = { C[0] * 0.75f + 0.12f, C[1] * 0.45f + 0.04f, C[2] * 0.9f + 0.10f };
                float k = gl * 0.85f + powf(F, 2.5f) * 0.25f;
                r = r * (1.0f - 0.25f * k) + gc[0] * k; g = g * (1.0f - 0.25f * k) + gc[1] * k; b = b * (1.0f - 0.25f * k) + gc[2] * k;
                al = 1.0f;
            } break;
            case M3D_HEXSHIELD: {   // Overwatch barrier: hex grid shield, impact ripples running across the cells
                const float T = s.time;
                float mp[3];
                for (int q = 0; q < 3; ++q) mp[q] = g_pos[i0 * 3 + q] * w0 + g_pos[i1 * 3 + q] * w1 + g_pos[i2 * 3 + q] * w2;
                float x = (mp[0] + mp[2] * 0.7f) * 11.0f, y = mp[1] * 11.0f;
                const float SY = 1.7320508f;
                auto md = [](float a, float m) { return a - m * floorf(a / m); };
                float ax = md(x, 1.0f) - 0.5f, ay = md(y, SY) - 0.5f * SY;
                float bx = md(x - 0.5f, 1.0f) - 0.5f, by = md(y - 0.5f * SY, SY) - 0.5f * SY;
                bool useA = ax * ax + ay * ay < bx * bx + by * by;
                float gx = useA ? ax : bx, gy = useA ? ay : by;
                float idx = x - gx, idy = y - gy;
                float hx2 = fabsf(gx), hy2 = fabsf(gy);
                float hd = std::max(hx2, hx2 * 0.5f + hy2 * 0.8660254f);                              // 0 centre .. 0.5 edge
                float line = sstep(0.40f, 0.48f, hd);
                float cid = Hash2((int)floorf(idx * 2.0f + 500.0f), (int)floorf(idy * 2.0f + 500.0f));
                float wvp = 0.0f;
                for (int w = 0; w < 2; ++w) {   // two impact ripples at random spots, restarting
                    float per = 2.3f, tt = T + w * 1.15f, cyc = floorf(tt / per), ph = tt - cyc * per;
                    float cx = (Hash2((int)cyc, 11 + w) - 0.5f) * 6.0f, cy = 4.0f + Hash2((int)cyc, 29 + w) * 12.0f;
                    float d = sqrtf((idx - cx) * (idx - cx) + (idy - cy) * (idy - cy));
                    float fr = d - ph * 9.0f;
                    wvp += expf(-fr * fr * 0.6f) * (1.0f - ph / per);
                }
                float flick = cid > 0.9f ? 0.5f + 0.5f * sinf(T * 6.0f + cid * 40.0f) : 0.0f;
                float rim = powf(F, 2.0f);
                float fill = 0.10f + 0.16f * cid + 0.55f * wvp + 0.30f * flick;
                float e = fill + line * (0.55f + 0.9f * wvp) + rim * 0.8f;
                r = C[0] * e + line * wvp * 0.35f; g = C[1] * e + line * wvp * 0.35f; b = C[2] * e + line * wvp * 0.35f;
                al = CA * sat(0.22f + 0.15f * cid + line * 0.6f + wvp * 0.5f + rim * 0.6f + flick * 0.2f);
            } break;
            case M3D_GOLD: {   // CS:GO trophy gold: polished gold matcap, glint sweeping over the body
                const float T = s.time;
                float mc[3]; SampleT(g_st[ST_MATCAP_I], nx * 0.48f + 0.5f, -ny * 0.48f + 0.5f, mc);
                float mp[3];
                for (int q = 0; q < 3; ++q) mp[q] = g_pos[i0 * 3 + q] * w0 + g_pos[i1 * 3 + q] * w1 + g_pos[i2 * 3 + q] * w2;
                const float au[3] = { 1.0f, 0.76f, 0.33f };
                float lum = (mc[0] + mc[1] + mc[2]) / 3.0f;
                float sw = mp[1] * 0.8f - mp[0] * 0.5f - T * 0.9f; sw -= floorf(sw / 2.4f) * 2.4f;
                float glint = expf(-(sw - 1.2f) * (sw - 1.2f) / 0.008f);
                float sp2 = powf(std::max(0.0f, nx * hx + ny * hy + nz * hz), 70.0f);
                for (int q = 0; q < 3; ++q) {
                    float base = au[q] * C[q];
                    float c = base * (0.10f + 1.25f * powf(lum, 1.3f)) + base * powf(F, 2.0f) * 0.35f + (sp2 * 0.8f + glint * 0.65f) * (0.6f + 0.4f * base);
                    (q == 0 ? r : q == 1 ? g : b) = c;
                }
                al = CA;
            } break;
            case M3D_CAMO: {   // Halo / Crysis active camo: near invisible, refraction ripples crawling up, shimmering edge
                const float T = s.time;
                float mp[3];
                for (int q = 0; q < 3; ++q) mp[q] = g_pos[i0 * 3 + q] * w0 + g_pos[i1 * 3 + q] * w1 + g_pos[i2 * 3 + q] * w2;
                float u = (mp[0] + mp[2] * 0.7f) * 4.0f, v = mp[1] * 4.0f - T * 0.6f;
                float n0 = Fbm(u, v), n1 = Fbm(u + 0.05f, v), n2 = Fbm(u, v + 0.05f);
                float dg = sqrtf((n1 - n0) * (n1 - n0) + (n2 - n0) * (n2 - n0)) * 22.0f;                 // ripple "lens" edges
                float wave = 0.5f + 0.5f * sinf(mp[1] * 18.0f - T * 4.0f + n0 * 6.0f);
                float rim = powf(F, 2.6f);
                float sh = sat(dg * (0.4f + 0.6f * wave));
                float e = sh * 0.55f + rim * 0.9f + spec * 0.6f;
                r = C[0] * e + sh * 0.12f; g = C[1] * e + sh * 0.12f; b = C[2] * e + sh * 0.12f;
                al = CA * sat(0.04f + sh * 0.35f + rim * 0.55f + spec * 0.5f);
            } break;
            case M3D_LAVA: {   // magma: dark cooling rock plates drifting on glowing lava, heat pulsing through the cracks
                const float T = s.time;
                float mp[3];
                for (int q = 0; q < 3; ++q) mp[q] = g_pos[i0 * 3 + q] * w0 + g_pos[i1 * 3 + q] * w1 + g_pos[i2 * 3 + q] * w2;
                float u = (mp[0] + mp[2] * 0.7f) * 5.5f, v = mp[1] * 5.5f;
                float wx = Fbm(u * 0.5f, v * 0.5f + T * 0.05f) - 0.5f, wy = Fbm(u * 0.5f + 7.3f, v * 0.5f) - 0.5f;
                float f1, f2, cid; Voronoi(u + wx * 1.2f, v + wy * 1.2f - T * 0.12f, T * 0.35f, f1, f2, cid);
                float crack = 1.0f - sstep(0.0f, 0.16f, f2 - f1);                                      // glowing seams
                float halo = 1.0f - sstep(0.0f, 0.45f, f2 - f1);
                float flow = Fbm(u * 1.4f + T * 0.25f, v * 1.4f - T * 0.6f);
                float heat = sat(crack * (0.75f + 0.6f * flow) + halo * 0.25f * flow);
                float pulse = 0.85f + 0.15f * sinf(T * 2.4f + cid * 12.0f);
                heat *= pulse;
                float co[3] = { C[0], C[1] * 0.55f, C[2] * 0.25f }; float ci[3]; FireInner(C, ci);
                float o3[3]; FireRamp(sat(heat * 1.15f), C, ci, o3);
                float rock = 0.045f + 0.06f * ndl + 0.05f * cid + spec * 0.12f;                       // basalt plates
                float ember = sat(1.0f - f1 * 2.2f) * 0.06f * (0.5f + 0.5f * sinf(T * 3.0f + cid * 20.0f));
                for (int q = 0; q < 3; ++q) {
                    float c = rock * (q == 0 ? 1.0f : q == 1 ? 0.9f : 0.85f) + o3[q] * heat * 1.6f + co[q] * (halo * 0.25f + ember) + co[q] * powf(F, 3.0f) * 0.25f;
                    (q == 0 ? r : q == 1 ? g : b) = c;
                }
                al = CA;
            } break;
            case M3D_MERCURY: {   // liquid metal (T-1000): flowing chrome, the surface ripples and reflects
                const float T = s.time;
                float mp[3];
                for (int q = 0; q < 3; ++q) mp[q] = g_pos[i0 * 3 + q] * w0 + g_pos[i1 * 3 + q] * w1 + g_pos[i2 * 3 + q] * w2;
                float u = (mp[0] + mp[2] * 0.7f) * 3.0f, v = mp[1] * 3.0f - T * 0.35f;
                float qx = Fbm(u + T * 0.15f, v), qy = Fbm(u + 5.2f, v + 1.3f - T * 0.1f);
                float e0 = Fbm(u + qx * 2.0f, v + qy * 2.0f), ex = Fbm(u + 0.03f + qx * 2.0f, v + qy * 2.0f), ey = Fbm(u + qx * 2.0f, v + 0.03f + qy * 2.0f);
                float px2 = nx + (ex - e0) * 30.0f * 0.28f, py2 = ny + (ey - e0) * 30.0f * 0.28f, pz2 = nz;
                float pl = sqrtf(px2 * px2 + py2 * py2 + pz2 * pz2); px2 /= pl; py2 /= pl; pz2 /= pl;
                float mc[3]; SampleT(g_st[ST_MATCAP_I], px2 * 0.48f + 0.5f, -py2 * 0.48f + 0.5f, mc);
                float lum = (mc[0] + mc[1] + mc[2]) / 3.0f;
                float hs = std::max(0.0f, px2 * hx + py2 * hy + pz2 * hz);
                float sp = powf(hs, 120.0f) * 1.2f + powf(hs, 20.0f) * 0.15f;
                float Fm = 1.0f - pz2;
                for (int q = 0; q < 3; ++q) {
                    float tint = 0.55f + 0.45f * C[q];
                    float c = (0.06f + powf(lum, 2.2f) * 0.75f + lum * 0.12f) * tint + sp * 0.7f + Fm * Fm * 0.22f * tint;
                    (q == 0 ? r : q == 1 ? g : b) = c;
                }
                al = CA;
            } break;
            case M3D_AURORA: {   // northern lights: glowing curtains rolling over a night-dark body, faint stars
                const float T = s.time;
                float mp[3];
                for (int q = 0; q < 3; ++q) mp[q] = g_pos[i0 * 3 + q] * w0 + g_pos[i1 * 3 + q] * w1 + g_pos[i2 * 3 + q] * w2;
                float u = (mp[0] + mp[2] * 0.7f) * 1.6f, v = mp[1] * 1.6f;
                float acc[3] = { 0, 0, 0 };
                float C2[3] = { C[2] * 0.7f + 0.15f, C[0] * 0.35f + 0.1f, C[1] * 0.5f + 0.45f };          // second hue for the curtain tops
                for (int L = 0; L < 3; ++L) {
                    float off = L * 1.7f, spd = 0.12f + L * 0.05f;
                    float cx = u * (1.0f + L * 0.4f) + Fbm(v * 0.8f + off, T * spd) * 2.2f + T * spd;
                    float curtain = powf(0.5f + 0.5f * sinf(cx * 2.2f + off), 6.0f);     // vertical folds
                    float rays = powf(Fbm(cx * 7.0f, v * 0.5f - T * 0.5f), 2.0f) * 2.2f;
                    float hgt = 0.35f + 0.65f * sstep(-0.6f, 0.6f, sinf(v * 1.6f + L * 1.3f + T * 0.25f) + Fbm(cx, v) - 0.4f);
                    float k = curtain * rays * hgt * (L == 0 ? 1.0f : 0.6f);
                    float m = sat(0.5f + 0.5f * sinf(v * 3.0f + off + T * 0.3f));
                    for (int q = 0; q < 3; ++q) acc[q] += k * lerpf(C[q], C2[q], m);
                }
                float star = Hash2((int)(px / 3), (int)(py / 3)) > 0.985f ? 0.5f + 0.5f * sinf(T * 5.0f + px) : 0.0f;
                float rim = powf(F, 2.4f);
                r = 0.012f + acc[0] * 1.7f + star * 0.5f + C[0] * rim * 0.45f;
                g = 0.016f + acc[1] * 1.7f + star * 0.5f + C[1] * rim * 0.45f;
                b = 0.040f + acc[2] * 1.7f + star * 0.6f + C[2] * rim * 0.45f;
                al = CA;
            } break;
            case M3D_RECON: {   // Valorant Sova recon reveal: red see-through silhouette, hot edges, scan wave sweeping up
                const float T = s.time;
                float mp[3];
                for (int q = 0; q < 3; ++q) mp[q] = g_pos[i0 * 3 + q] * w0 + g_pos[i1 * 3 + q] * w1 + g_pos[i2 * 3 + q] * w2;
                float ph = fmodf(T * 0.75f, 1.0f), sy = -0.2f + ph * 2.4f;                    // wave height (m)
                float dw = mp[1] - sy;
                float wave = expf(-dw * dw * 90.0f) + (dw < 0 ? expf(dw * 6.0f) * 0.25f : 0.0f); // bright front + fading wake
                float rim = powf(F, 1.7f);
                float scan = 0.82f + 0.18f * (((py >> 1) & 1) ? 1.0f : 0.0f);                // fine horizontal scanlines
                float ping = 0.75f + 0.25f * powf(0.5f + 0.5f * sinf(T * 7.0f), 3.0f);
                const float* RD = C;                                                            // chams colour (Valorant default #FF4655)
                for (int q = 0; q < 3; ++q) {
                    float c = RD[q] * (0.16f + rim * 1.15f * ping + wave * 0.9f) * scan + powf(F, 5.0f) * 0.55f + wave * 0.25f;
                    (q == 0 ? r : q == 1 ? g : b) = c;
                }
                al = CA * sat(0.42f + rim * 0.65f + wave * 0.5f);
            } break;
            case M3D_VIPER: {   // Valorant Viper toxin: glossy acid coating dripping down the body, glowing bubbles
                const float T = s.time;
                float mp[3];
                for (int q = 0; q < 3; ++q) mp[q] = g_pos[i0 * 3 + q] * w0 + g_pos[i1 * 3 + q] * w1 + g_pos[i2 * 3 + q] * w2;
                float u = (mp[0] + mp[2] * 0.7f), v = mp[1];
                int col = (int)floorf(u / 0.035f);
                float hc = Hash2(col, 41);
                float dl = fmodf(T * (0.10f + hc * 0.25f) + hc * 3.0f, 1.0f) * 2.2f;              // each drip runs down its own column
                float dripTop = 2.0f - dl;
                float fxc = u / 0.035f - col - 0.5f;
                float wdt = 0.28f + 0.12f * sinf(v * 30.0f + hc * 9.0f);
                float drip = (fabsf(fxc) < wdt && v > dripTop - 0.05f && v < dripTop + 0.35f + hc * 0.4f && hc > 0.45f) ? 1.0f : 0.0f;
                float goo = sstep(0.45f, 0.62f, Fbm(u * 4.0f, v * 4.0f + T * 0.6f));               // slow-flowing coating
                float bub = 0.0f;
                { int bx = (int)floorf(u / 0.05f), by = (int)floorf((v + T * 0.18f) / 0.05f); float h = Hash2(bx, by);
                  if (h > 0.86f) { float fx = u / 0.05f - bx - 0.5f, fy = (v + T * 0.18f) / 0.05f - by - 0.5f; bub = 1.0f - sstep(0.12f, 0.30f, sqrtf(fx * fx + fy * fy)); } }
                float wet = sat(goo + drip);
                float lit = 0.25f + 0.75f * ndl, rim = powf(F, 2.0f);
                float hs = std::max(0.0f, nx * hx + ny * hy + nz * hz);
                float sp = powf(hs, 90.0f) * 1.3f * (0.3f + 0.7f * wet);
                for (int q = 0; q < 3; ++q) {
                    float c = 0.015f + C[q] * 0.06f * lit + C[q] * wet * (0.35f + 0.55f * lit) + C[q] * drip * 0.5f + (C[q] * 0.5f + 0.5f) * bub * 0.9f + C[q] * rim * 0.75f + sp;
                    (q == 0 ? r : q == 1 ? g : b) = c;
                }
                al = CA;
            } break;
            case M3D_OMEN: {   // Valorant Omen: void-black body, shadow smoke boiling off it, ember edges flickering
                const float T = s.time;
                float mp[3];
                for (int q = 0; q < 3; ++q) mp[q] = g_pos[i0 * 3 + q] * w0 + g_pos[i1 * 3 + q] * w1 + g_pos[i2 * 3 + q] * w2;
                float u = (mp[0] + mp[2] * 0.7f) * 2.8f, v = mp[1] * 2.8f;
                float q1 = Fbm(u + T * 0.1f, v - T * 0.7f), q2 = Fbm(u * 1.7f - 4.0f, v * 1.7f - T * 1.1f);
                float smoke = sstep(0.30f, 0.72f, Fbm(u + q1 * 1.6f, v + q2 * 1.6f - T * 0.5f));
                float ember = powf(sat(1.0f - fabsf(smoke - 0.5f) * 4.0f), 3.0f) * (0.6f + 0.4f * sinf(T * 9.0f + u * 5.0f));
                float rim = powf(F, 2.2f);
                float voidk = 1.0f - smoke;
                for (int q = 0; q < 3; ++q) {
                    float c = 0.004f + C[q] * smoke * 0.55f + C[q] * ember * 1.4f + (C[q] * 0.7f + 0.3f) * rim * 0.9f * (0.7f + 0.3f * voidk);
                    (q == 0 ? r : q == 1 ? g : b) = c;
                }
                al = CA * sat(0.88f + rim * 0.12f);
            } break;
            case M3D_RAINBOW: {   // RGB / chroma chams: hue flowing over the body + shimmer bands, colour tints the highlights
                const float T = s.time;
                float mp[3];
                for (int q = 0; q < 3; ++q) mp[q] = g_pos[i0 * 3 + q] * w0 + g_pos[i1 * 3 + q] * w1 + g_pos[i2 * 3 + q] * w2;
                float h = mp[1] * 0.55f + (mp[0] + mp[2]) * 0.25f - T * 0.30f + Fbm(mp[0] * 2.0f + T * 0.1f, mp[1] * 2.0f) * 0.25f;
                h -= floorf(h);
                float h6 = h * 6.0f, rc = sat(fabsf(h6 - 3.0f) - 1.0f), gc = sat(2.0f - fabsf(h6 - 2.0f)), bc = sat(2.0f - fabsf(h6 - 4.0f));
                float lit = 0.45f + 0.20f * ny + 0.55f * ndl;
                float sh = powf(0.5f + 0.5f * sinf((mp[1] - mp[0] * 0.6f) * 9.0f - T * 4.0f), 14.0f);   // diagonal shimmer
                float rim = powf(F, 2.4f);
                float w = spec * 0.55f + sh * 0.35f;
                r = rc * lit + C[0] * rim * 0.9f + w; g = gc * lit + C[1] * rim * 0.9f + w; b = bc * lit + C[2] * rim * 0.9f + w;
                al = CA;
            } break;
            case M3D_DAMASCUS: case M3D_GLITTER: case M3D_LIGHTNING: case M3D_FIRE: case M3D_STARNEST: case M3D_DISSOLVE: {
                const float T = s.time;
                float mp[3], mn[3];
                for (int q = 0; q < 3; ++q) { mp[q] = g_pos[i0 * 3 + q] * w0 + g_pos[i1 * 3 + q] * w1 + g_pos[i2 * 3 + q] * w2; mn[q] = g_nrm[i0 * 3 + q] * w0 + g_nrm[i1 * 3 + q] * w1 + g_nrm[i2 * 3 + q] * w2; }
                float tx[3], ty[3];
                if (s.mat == M3D_DAMASCUS) {          // Enlighten DesignShader: moving caustic interior + glitter streaks + gradient + purple fresnel
                    Tri(g_st[ST_CAUSTIC_I], mp, mn, 2.2f, 0.0f, T * 0.10f, tx);
                    Tri(g_st[ST_CAUSTIC_I], mp, mn, 3.7f, 0.37f + nx * 0.05f, -T * 0.06f + ny * 0.05f, ty);
                    float c1 = powf(tx[0], 1.7f), c2 = powf(ty[0], 2.2f);
                    float st[3]; Tri(g_st[ST_STREAK_I], mp, mn, 1.3f, 0.0f, -T * 0.16f, st);
                    float gy = sat((mp[1] - 0.15f) / 1.5f);
                    const float top[3] = { 0.0f, 0.587f, 0.506f }, bot[3] = { 0.79f, 0.095f, 0.095f }, fr[3] = { 0.42f, 0.0f, 1.0f };
                    float fe = powf(F, 2.0f) * 1.15f;
                    float o3[3];
                    for (int q = 0; q < 3; ++q) o3[q] = 0.015f + C[q] * (c1 * 1.55f + c2 * 0.75f) + st[q] * 0.85f + lerpf(bot[q], top[q], gy) * 0.16f + fr[q] * fe + spec * 0.2f;
                    r = o3[0]; g = o3[1]; b = o3[2]; al = CA;
                } else if (s.mat == M3D_GLITTER) {    // Enlighten Glitter: scrolling swirl design + sparkles + cyan fresnel
                    Tri(g_st[ST_SWIRL_I], mp, mn, 1.5f, 0.0f, -T * 0.13f, tx);
                    int cx = (int)floorf(mp[0] * 85.0f), cy = (int)floorf(mp[1] * 85.0f), cz = (int)floorf(mp[2] * 85.0f);
                    float hsh = Hash3(cx, cy, cz);
                    float sp = 0.0f;
                    if (hsh > 0.80f) { float tw = 0.5f + 0.5f * sinf(T * (3.0f + hsh * 7.0f) + hsh * 60.0f + (nx + ny) * 6.0f); sp = powf(sstep(0.856f, 1.0f, tw), 1.5f) * 1.6f; }
                    float fe = powf(F, 1.8f);
                    float o3[3];
                    for (int q = 0; q < 3; ++q) o3[q] = 0.012f + (q == 2 ? 0.03f : 0.0f) + tx[q] * (0.25f + C[q] * 1.1f) + sp * (C[q] * 0.7f + 0.55f) + C[q] * fe * 0.95f + spec * 0.25f;
                    r = o3[0]; g = o3[1]; b = o3[2]; al = CA * sat(0.78f + 0.22f * fe + sp);
                } else if (s.mat == M3D_LIGHTNING) {  // Poiyomi: chrome matcap + scrolling lightning emission
                    float mc[3]; SampleT(g_st[ST_MATCAP_I], nx * 0.48f + 0.5f, -ny * 0.48f + 0.5f, mc);
                    Tri(g_st[ST_LIGHTNING_I], mp, mn, 1.1f, 0.0f, T * 0.035f, tx);
                    float lt = std::max(tx[0], std::max(tx[1], tx[2]));
                    float pulse = 0.25f + 0.75f * powf(0.5f + 0.5f * sinf(mp[1] * 7.0f - T * 5.0f), 2.0f);
                    float blink = 0.75f + 0.25f * sinf(T * 23.0f) * sinf(T * 7.3f);
                    float em = lt * pulse * blink;
                    float o3[3];
                    for (int q = 0; q < 3; ++q) o3[q] = mc[q] * (0.30f + 0.25f * C[q]) + C[q] * em * 2.4f + em * em * 0.5f + C[q] * powf(F, 3.0f) * 0.7f;
                    r = o3[0]; g = o3[1]; b = o3[2]; al = CA;
                } else if (s.mat == M3D_FIRE) {   // Rollthered/Fire: noise flames crawling up the body
                    const float* co = C; float ci[3]; FireInner(C, ci);
                    Tri(g_st[ST_NOISE_I], mp, mn, 1.1f, 0.0f, T * 0.32f, tx);
                    Tri(g_st[ST_WAVE_I], mp, mn, 0.8f, T * 0.05f, T * 0.45f, ty);
                    float f = sat(tx[0] * 0.95f + ty[0] * 0.55f + F * 0.55f - 0.42f);
                    float o3[3]; FireRamp(f, co, ci, o3);
                    r = o3[0] + co[0] * 0.05f; g = o3[1] + co[1] * 0.05f; b = o3[2] + co[2] * 0.05f; al = CA * sat(0.55f + f);
                } else if (s.mat == M3D_STARNEST) {   // Custom/Multi-Shader/StarNest (screen space)
                    float fx = (px + 0.5f) / SNS - 0.5f, fy = (py + 0.5f) / SNS - 0.5f;
                    int X0 = std::max(0, std::min(SW - 1, (int)floorf(fx))), Y0 = std::max(0, std::min(SH - 1, (int)floorf(fy)));
                    int X1 = std::min(SW - 1, X0 + 1), Y1 = std::min(SH - 1, Y0 + 1); float ax = sat(fx - X0), ay = sat(fy - Y0);
                    float sn[3];
                    for (int q = 0; q < 3; ++q) sn[q] = lerpf(lerpf(g_snb[(Y0 * SW + X0) * 3 + q], g_snb[(Y0 * SW + X1) * 3 + q], ax), lerpf(g_snb[(Y1 * SW + X0) * 3 + q], g_snb[(Y1 * SW + X1) * 3 + q], ax), ay);
                    float o3[3];
                    for (int q = 0; q < 3; ++q) o3[q] = sn[q] * (0.35f + 0.9f * C[q]) + C[q] * powf(F, 2.2f) * 0.8f;
                    r = o3[0]; g = o3[1]; b = o3[2]; al = CA;
                } else {                              // Poiyomi geometric dissolve
                    float p = g_tp[t];
                    float e = sat(1.0f - std::min(w0, std::min(w1, w2)) / 0.075f);
                    float o3[3];
                    for (int q = 0; q < 3; ++q) o3[q] = 0.02f + C[q] * (0.10f + 0.55f * powf(F, 2.0f)) + C[q] * e * (0.18f + 2.2f * p) + C[q] * p * 0.6f + spec * 0.15f;
                    r = o3[0]; g = o3[1]; b = o3[2]; al = CA * (1.0f - p * 0.25f);
                }
            } break;
            }
            if (s.overlay && (s.mat == M3D_WIREFRAME || s.mat == M3D_GALAXYWIRE || s.mat == M3D_WATERFLOW || s.mat == M3D_GALAXY)) {   // chams on top of the textured model
                float tr, tg, tb; textured(tr, tg, tb);
                al *= (s.mat == M3D_WIREFRAME || s.mat == M3D_GALAXYWIRE) ? 0.6f : (s.mat == M3D_GALAXY ? 0.8f : 0.72f);
                r = r * al + tr * (1 - al); g = g * al + tg * (1 - al); b = b * al + tb * (1 - al); al = 1.0f;
            }
            r *= s.bright; g *= s.bright; b *= s.bright;
            float* o = &cm[k * 4];
            o[0] = sat(r) * al; o[1] = sat(g) * al; o[2] = sat(b) * al; o[3] = al;
        } });
    float bx0 = 1e9f, by0 = 1e9f, bx1 = -1e9f, by1 = -1e9f;
    for (int py = 0; py < H; ++py) {
        const int* row = &tid[py * W]; int l = -1, r = -1;
        for (int px = 0; px < W; ++px) if (row[px] >= 0) { if (l < 0) l = px; r = px; }
        if (l >= 0) { bx0 = std::min(bx0, (float)l); bx1 = std::max(bx1, (float)r + 1); by0 = std::min(by0, (float)py); by1 = (float)py + 1; }
    }
    // ---- wireframe lines (depth tested against the full mesh)
    if (s.mat == M3D_WIREFRAME || s.mat == M3D_GALAXYWIRE) {
        wl.assign(N, 0.0f);
        std::vector<float> wv(MD_WNV * 3);
        for (int i = 0; i < MD_WNV; ++i) {
            float vx, vy, vz; Rot(x, WPv[i * 3], WPv[i * 3 + 1], WPv[i * 3 + 2], vx, vy, vz);
            Proj(x, vx, vy, vz, wv[i * 3], wv[i * 3 + 1], wv[i * 3 + 2]);
        }
        auto plot = [&](int px, int py, float z, float cov) {
            if (px < 0 || py < 0 || px >= W || py >= H) return;
            int k = py * W + px;
            float zz = zb[k];
            if (tid[k] >= 0 && z > zz + 0.035f) return;   // hidden behind the body
            if (tid[k] < 0) cov *= 0.5f;
            wl[k] = std::max(wl[k], cov);
        };
        for (int e = 0; e < MD_WNE; ++e) {
            const float* a = &wv[MD_WEDGE[e * 2] * 3]; const float* b = &wv[MD_WEDGE[e * 2 + 1] * 3];
            float dx = b[0] - a[0], dy = b[1] - a[1];
            bool steep = fabsf(dy) > fabsf(dx);
            float len = std::max(fabsf(dx), fabsf(dy));
            int n = std::max(1, (int)ceilf(len));
            for (int i = 0; i <= n; ++i) {
                float t = (float)i / n;
                float fx = a[0] + dx * t - 0.5f, fy = a[1] + dy * t - 0.5f, z = a[2] + (b[2] - a[2]) * t;
                if (steep) { int iy = (int)floorf(fy + 0.5f); int ix = (int)floorf(fx); float f = fx - ix; plot(ix, iy, z, 1 - f); plot(ix + 1, iy, z, f); }
                else       { int ix = (int)floorf(fx + 0.5f); int iy = (int)floorf(fy); float f = fy - iy; plot(ix, iy, z, 1 - f); plot(ix, iy + 1, z, f); }
            }
        }
        for (int k = 0; k < N; ++k) if (wl[k] > 0) {
            float a = sat(wl[k] * 1.25f) * CA;
            float* o = &cm[k * 4];
            float r = std::min(1.0f, C[0] * 1.1f + 0.08f) * s.bright, g = std::min(1.0f, C[1] * 1.1f + 0.08f) * s.bright, b = std::min(1.0f, C[2] * 1.1f + 0.08f) * s.bright;
            if (s.mat == M3D_GALAXYWIRE) {   // line colour = galaxy texture at this pixel (boosted so thin lines stay readable)
                float gr, gg, gb; GalaxyShade(k % W, k / W, H, s.time, C, 0.0f, gr, gg, gb);
                r = std::min(1.0f, gr * 2.1f + C[0] * 0.12f) * s.bright; g = std::min(1.0f, gg * 2.1f + C[1] * 0.12f) * s.bright; b = std::min(1.0f, gb * 2.1f + C[2] * 0.12f) * s.bright;
            }
            o[0] = r * a + o[0] * (1 - a); o[1] = g * a + o[1] * (1 - a); o[2] = b * a + o[2] * (1 - a); o[3] = a + o[3] * (1 - a);
        }
    }
    // ---- fire: flames rising off the silhouette
    if (s.mat == M3D_FIRE) {
        const float* co = s.col; float ci[3]; FireInner(s.col, ci);
        const int K = 16; const float stp = H / 260.0f, T = s.time;
        ParFor(H, [&](int yb, int ye) {
            for (int py = yb; py < ye; ++py) for (int px = 0; px < W; ++px) {
                int k = py * W + px;
                float acc = 0.0f;
                for (int i = 1; i <= K; ++i) {
                    float sy = py + i * stp;
                    float dx = (VNoise(px * 0.035f, (py + T * 110.0f) * 0.03f) - 0.5f) * i * 1.4f;
                    int qx = (int)(px + dx), qy = (int)sy;
                    if (qx < 0 || qy < 0 || qx >= W || qy >= H) continue;
                    if (tid[qy * W + qx] >= 0) { acc = 1.0f - (float)(i - 1) / K; break; }
                }
                if (acc <= 0.0f) continue;
                float n = Fbm(px / 20.0f, (py + T * 150.0f) / 20.0f);
                float f = sat(acc * (n * 1.9f - 0.38f) * 1.25f);
                if (f <= 0.01f) continue;
                float c3[3]; FireRamp(sat(f * 1.05f), co, ci, c3);
                float a = sat(f * 1.3f) * s.col[3] * s.bright;
                float* o = &cm[k * 4];
                if (tid[k] >= 0) { for (int q = 0; q < 3; ++q) o[q] = std::min(o[3], o[q] + c3[q] * a * 0.5f * o[3]); continue; }
                for (int q = 0; q < 3; ++q) o[q] = c3[q] * s.bright * a + o[q] * (1 - a); o[3] = a + o[3] * (1 - a);
            }
        });
    }
    // ---- halos (outer glow / glow outline)
    hacc.assign(N * 4, 0.0f);
    auto halo = [&](int rad, float strength, const float* col, float alpha) {
        hm.resize(N); ht.resize(N);
        for (int k = 0; k < N; ++k) hm[k] = tid[k] >= 0 ? 1.0f : 0.0f;
        BoxBlur(hm, ht, W, H, rad); BoxBlur(hm, ht, W, H, rad); BoxBlur(hm, ht, W, H, std::max(1, rad / 2));
        ParFor(N, [&](int kb, int ke) { for (int k = kb; k < ke; ++k) {
            float a = sat(hm[k] * strength) * alpha;
            if (a <= 0.002f) continue;
            float* o = &hacc[k * 4];
            o[0] = col[0] * a + o[0] * (1 - a); o[1] = col[1] * a + o[1] * (1 - a); o[2] = col[2] * a + o[2] * (1 - a); o[3] = a + o[3] * (1 - a);
        } });
    };
    if (s.halo) {   // outline glow: only outside the silhouette (never tints the chams themselves)
        const int rad = std::max(2, W / 40), rad2 = std::max(1, W / 320);
        std::vector<float> sm(N), st(N);
        hm.resize(N); ht.resize(N);
        for (int k = 0; k < N; ++k) sm[k] = hm[k] = tid[k] >= 0 ? 1.0f : 0.0f;
        BoxBlur(hm, ht, W, H, rad); BoxBlur(hm, ht, W, H, rad); BoxBlur(hm, ht, W, H, std::max(1, rad / 2));
        BoxBlur(sm, st, W, H, rad2); BoxBlur(sm, st, W, H, rad2);
        const float* col = s.haloCol; const float alpha = s.haloCol[3] * s.bright;
        ParFor(N, [&](int kb, int ke) { for (int k = kb; k < ke; ++k) {
            if (tid[k] >= 0) continue;
            float soft = sat(hm[k] * 1.9f), line = sat(sm[k] * 4.0f);
            float a = std::max(soft * 0.85f, line) * alpha;
            if (a <= 0.002f) continue;
            float wv = line * 0.35f;   // hotter core right at the edge
            float* o = &hacc[k * 4];
            for (int c = 0; c < 3; ++c) o[c] = std::min(1.0f, col[c] + wv * (1.0f - col[c])) * a;
            o[3] = a;
        } });
    }
    if (s.mat == M3D_GLOW_OUTLINE) {   // glow along every contour of the body (depth edges + fresnel), not just the silhouette
        hm.assign(N, 0.0f); ht.resize(N);
        const int d = std::max(1, W / 240);
        ParFor(H, [&](int yb, int ye) {
            for (int py = yb; py < ye; ++py) for (int px = 0; px < W; ++px) {
                int k = py * W + px; if (tid[k] < 0) continue;
                float z = zb[k], e = 0.0f;
                const int nx[4] = { px - d, px + d, px, px }, ny[4] = { py, py, py - d, py + d };
                for (int i = 0; i < 4; ++i) {
                    if (nx[i] < 0 || ny[i] < 0 || nx[i] >= W || ny[i] >= H) { e = 1.0f; break; }
                    int q = ny[i] * W + nx[i];
                    float dz = tid[q] < 0 ? 1.0f : fabsf(zb[q] - z);
                    e = std::max(e, sat((dz - 0.012f) / 0.05f));
                }
                hm[k] = e;
            }
        });
        BoxBlur(hm, ht, W, H, std::max(1, W / 160)); BoxBlur(hm, ht, W, H, std::max(1, W / 160));
        ParFor(N, [&](int kb, int ke) { for (int k = kb; k < ke; ++k) {
            float g = sat(hm[k] * 2.4f) * s.col[3] * s.bright;
            if (g <= 0.002f) continue;
            float* o = &cm[k * 4];
            if (tid[k] >= 0) { for (int c = 0; c < 3; ++c) o[c] = std::min(o[3], o[c] + s.col[c] * g * o[3]); }
            else { float a = g * 0.45f; for (int c = 0; c < 3; ++c) o[c] = s.col[c] * a + o[c] * (1 - a); o[3] = a + o[3] * (1 - a); }
        } });
    }
    // ---- ghost: analog TV glitch (row tearing, RGB split, scanlines, rolling bar, static)
    if (s.mat == M3D_GHOST || s.mat == M3D_HOLOGRAM) {
        static std::vector<float> gsrc; gsrc = cm;
        const float T = s.time, sc = W / 480.0f;
        const int slot = (int)floorf(T * 14.0f);
        const float burst = Hash2((int)floorf(T * 6.0f), 913) > (s.mat == M3D_HOLOGRAM ? 0.78f : 0.86f) ? 1.0f : 0.0f;          // short heavy-glitch moments
        const float split = (1.5f + 2.0f * burst + 0.8f * sinf(T * 3.1f)) * sc;
        const float roll = T * 0.22f - floorf(T * 0.22f);
        ParFor(H, [&](int yb, int ye) {
            for (int py = yb; py < ye; ++py) {
                int bh = (int)(6 + 18 * Hash2(py / 24, slot));                              // band height varies
                int band = py / std::max(1, bh);
                float hb = Hash2(band * 31 + 7, slot);
                float off = 0.0f, drop = 1.0f;
                if (hb > (burst > 0 ? 0.72f : 0.92f)) off = (Hash2(band, slot * 3 + 1) - 0.5f) * (burst > 0 ? 40.0f : 16.0f) * sc;
                if (Hash2(band + 400, slot) > 0.965f) drop = 0.35f;                            // dropped-out line
                off += sinf(py * 0.045f + T * 7.0f) * 0.8f * sc;                               // slight wobble
                float scan = 0.72f + 0.28f * (((int)(py / std::max(1.0f, 1.5f * sc))) & 1 ? 0.0f : 1.0f);
                float fy = (float)py / H - roll; fy -= floorf(fy + 0.5f);
                float bar = expf(-fy * fy * 900.0f) * 0.55f;
                for (int px = 0; px < W; ++px) {
                    float sx = px - off;
                    auto smp = [&](float x, int c) -> float { int xi = (int)floorf(x + 0.5f); if (xi < 0 || xi >= W) return 0.0f; return gsrc[(py * W + xi) * 4 + c]; };
                    float rr = smp(sx - split, 0), ra = smp(sx - split, 3);
                    float gg = smp(sx, 1), ga = smp(sx, 3);
                    float bb = smp(sx + split, 2), ba = smp(sx + split, 3);
                    float a = std::max(ga, std::max(ra, ba));
                    float* o = &cm[(py * W + px) * 4];
                    if (a <= 0.001f) { o[0] = o[1] = o[2] = o[3] = 0.0f; continue; }
                    float nz = Hash2(px + slot * 131, py * 3 + slot) * 0.18f;                    // static
                    float m = scan * drop;
                    o[0] = std::min(a, (rr + (nz + bar) * ra) * m);
                    o[1] = std::min(a, (gg + (nz + bar) * ga) * m);
                    o[2] = std::min(a, (bb + (nz + bar) * ba) * m);
                    o[3] = a * (0.85f + 0.15f * scan) * drop;
                }
            }
        });
    }
    // ---- composite + output (straight alpha)
    ParFor(N, [&](int kb, int ke) { for (int k = kb; k < ke; ++k) {
        const float* m = &cm[k * 4]; const float* h = &hacc[k * 4];
        float a = m[3] + h[3] * (1 - m[3]);
        uint8_t* o = &rgba[k * 4];
        if (a < 1e-4f) { o[0] = o[1] = o[2] = 0; o[3] = 0; continue; }
        float ia = 1.0f / a;
        for (int c = 0; c < 3; ++c) o[c] = (uint8_t)(sat((m[c] + h[c] * (1 - m[3])) * ia) * 255.0f + 0.5f);
        o[3] = (uint8_t)(sat(a) * 255.0f + 0.5f);
    } });
    if (out) { out->valid = bx1 > bx0; out->x0 = bx0; out->y0 = by0; out->x1 = bx1; out->y1 = by1; }
}

// ---- inventory agent look: glove skin + held weapon skin
int M3D_GloveSkin(const char* name, std::vector<uint8_t>& rgb, int& w, int& h)
{
    for (const AggSkin& k : AGG_SKINS) if (!strcmp(k.name, name)) {
        int c; unsigned char* p = stbi_load_from_memory(AGG_TEXBLOB + k.off, (int)k.size, &w, &h, &c, 3);
        if (!p) return -1;
        rgb.assign(p, p + (size_t)w * h * 3); stbi_image_free(p); return k.mesh;
    }
    return -1;
}
static Tex MakeTex(const uint8_t* rgb, int w, int h) { Tex t; t.w = w; t.h = h; t.px.assign(rgb, rgb + (size_t)w * h * 3); BuildMips(t); return t; }
void M3D_SetLook(int model, uint32_t key, int gloveMesh, const uint8_t* gloveRGB, int gw, int gh, const float* gpal, const uint8_t* wpnRGB, int ww, int wh)
{
    if (model < 1 || model > 2) return;
    std::lock_guard<std::recursive_mutex> rl(g_renderMx);
    M3D_Init(); { std::lock_guard<std::recursive_mutex> lk(g_loadMx); LoadModel(model); }
    const MState& B = g_m[model]; MState& L = g_look[model];
    const int ai = model - 1;
    L = MState(); L.d = B.d;
    for (int k = 0; k < 16; ++k) L.tex[k] = B.tex[k];
    L.pos = B.pos; L.nrm = B.nrm; L.uv = B.uv; L.wpos = B.wpos; L.triTex = B.triTex; L.idx = B.idx;
    L.widxV.assign(B.d->widx, B.d->widx + (size_t)B.d->nv * 4); L.wwV.assign(B.d->ww, B.d->ww + (size_t)B.d->nv * 4);
    if (wpnRGB && ww > 0) L.tex[1] = MakeTex(wpnRGB, ww, wh);
    if (gloveMesh >= 0 && gloveMesh < 2 && gloveRGB) {   // the skin's own glove mesh replaces the agent's gloves
        L.tex[2] = MakeTex(gloveRGB, gw, gh);
        std::vector<char> rm(L.triTex.size(), 0);
        for (int i = 0; i < AGG_NTRI[ai]; ++i) rm[AGG_TRIS[ai][i]] = 1;
        std::vector<uint32_t> idx; std::vector<int> tt; idx.reserve(L.idx.size()); tt.reserve(L.triTex.size());
        for (size_t t = 0; t < L.triTex.size(); ++t) if (!rm[t]) { idx.insert(idx.end(), &L.idx[t * 3], &L.idx[t * 3] + 3); tt.push_back(L.triTex[t]); }
        const AggMesh& G = AGG_MESH[gloveMesh]; const uint32_t off = (uint32_t)(L.pos.size() / 3);
        for (int i = 0; i < G.nv; ++i) {
            for (int q = 0; q < 3; ++q) { L.pos.push_back(G.pos[i * 3 + q] / 16000.0f); L.nrm.push_back(G.nrm[i * 3 + q] / 127.0f); }
            L.uv.push_back(G.uv[i * 2] / 65535.0f); L.uv.push_back(G.uv[i * 2 + 1] / 65535.0f);
            int src = G.src[ai][i];
            L.widxV.insert(L.widxV.end(), B.d->widx + src * 4, B.d->widx + src * 4 + 4); L.wwV.insert(L.wwV.end(), B.d->ww + src * 4, B.d->ww + src * 4 + 4);
        }
        for (int i = 0; i < G.ni; ++i) idx.push_back(off + G.idx[i]);
        for (int i = 0; i < G.ni / 3; ++i) tt.push_back(2);
        L.idx.swap(idx); L.triTex.swap(tt);
    } else if (gpal) {   // no game data for this skin: the agent's own gloves, recoloured with the skin's palette (gradient map by luminance)
        const Tex& A = B.tex[0];
        float lo = 1.0f, hi = 0.0f; std::vector<float> ls;
        for (int i = 0; i < AGG_NTRI[ai]; ++i) for (int e = 0; e < 3; ++e) {
            int v = (int)L.idx[AGG_TRIS[ai][i] * 3 + e]; float c[3]; Sample(A, L.uv[v * 2], L.uv[v * 2 + 1], c);
            ls.push_back(0.299f * c[0] + 0.587f * c[1] + 0.114f * c[2]);
        }
        if (!ls.empty()) { std::sort(ls.begin(), ls.end()); lo = ls[ls.size() * 3 / 100]; hi = ls[ls.size() * 97 / 100]; }
        if (hi - lo < 0.05f) { lo = 0.0f; hi = 1.0f; }
        Tex t; t.w = A.w; t.h = A.h; t.px.resize(A.px.size());
        for (size_t i = 0; i < A.px.size(); i += 3) {
            float l = (0.299f * A.px[i] + 0.587f * A.px[i + 1] + 0.114f * A.px[i + 2]) / 255.0f;
            float f = std::min(std::max((l - lo) / (hi - lo), 0.0f), 1.0f) * 15.0f; int k = std::min((int)f, 14); float a = f - k;
            for (int q = 0; q < 3; ++q) t.px[i + q] = (unsigned char)std::min(255.0f, (gpal[k * 3 + q] * (1 - a) + gpal[(k + 1) * 3 + q] * a) * 255.0f + 0.5f);
        }
        BuildMips(t); L.tex[2] = std::move(t);
        for (int i = 0; i < AGG_NTRI[ai]; ++i) L.triTex[AGG_TRIS[ai][i]] = 2;
    }
    L.nv = (int)(L.pos.size() / 3); L.ni = (int)L.idx.size(); L.widx = L.widxV.data(); L.ww = L.wwV.data(); L.key = key;
}
