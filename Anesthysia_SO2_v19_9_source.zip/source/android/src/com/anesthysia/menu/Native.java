package com.anesthysia.menu;
public class Native {
    static { System.loadLibrary("anesthysia"); }
    public static native void init();                       // GL thread, surface created
    public static native void resize(int w, int h);
    public static native int frame();                        // bit0 menu visible, bit1 unload finished
    public static native void touch(int action, float x, float y);   // 0 down, 1 move, 2 up, 3 hover (mouse), 4 wheel (y = steps)
    public static native void command(int cmd);              // 1 toggle menu, 2 toggle text watermark, 3 start loader, 4 start debug loader
}
