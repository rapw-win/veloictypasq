package com.anesthysia.menu;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.opengl.GLSurfaceView;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class OverlayService extends Service {
    private WindowManager wm;
    private GLSurfaceView gl;
    private ImageView btn;
    private WindowManager.LayoutParams glp, bp;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private volatile boolean touchable = false;
    private boolean started = false;

    @Override public IBinder onBind(Intent i) { return null; }

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public int onStartCommand(Intent intent, int flags, int id) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("ov", "Overlay", NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, "ov").setContentTitle("Anesthysia").setContentText("Overlay is running")
                .setSmallIcon(R.drawable.icon).setOngoing(true).build();
        startForeground(1, n);
        final boolean debug = intent != null && intent.getBooleanExtra("debug", false);
        final int delay = intent != null ? intent.getIntExtra("delay", 0) : 0;
        ui.removeCallbacksAndMessages(null);
        Runnable go = () -> {
            if (!started) { started = true; createOverlay(); }
            gl.queueEvent(() -> Native.command(debug ? 4 : 3));
        };
        if (delay > 0) {
            final long end = System.currentTimeMillis() + delay * 1000L;
            Runnable tick = new Runnable() { @Override public void run() {
                long left = (end - System.currentTimeMillis() + 999) / 1000;
                if (left <= 0) { setStatus(nm, "Overlay is running"); go.run(); return; }
                setStatus(nm, "Starting in " + left + " s"); ui.postDelayed(this, 250);
            } };
            tick.run();
        } else go.run();
        return START_NOT_STICKY;
    }

    private void setStatus(NotificationManager nm, String text) {
        nm.notify(1, new Notification.Builder(this, "ov").setContentTitle("Anesthysia").setContentText(text)
                .setSmallIcon(R.drawable.icon).setOngoing(true).setOnlyAlertOnce(true).build());
    }

    private void createOverlay() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        gl = new GLSurfaceView(this);
        gl.setEGLContextClientVersion(3);
        gl.setEGLConfigChooser(8, 8, 8, 8, 0, 0);
        gl.getHolder().setFormat(PixelFormat.TRANSLUCENT);
        gl.setZOrderOnTop(true);
        gl.setPreserveEGLContextOnPause(true);
        gl.setRenderer(new GLSurfaceView.Renderer() {
            int last = -1;
            @Override public void onSurfaceCreated(GL10 g, EGLConfig c) { Native.init(); }
            @Override public void onSurfaceChanged(GL10 g, int w, int h) { Native.resize(w, h); }
            @Override public void onDrawFrame(GL10 g) {
                int f = Native.frame();
                if (f != last) { last = f; final int ff = f; ui.post(() -> apply(ff)); }
            }
        });
        gl.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
        gl.setOnTouchListener((v, e) -> {
            int a = e.getActionMasked();
            int act = a == MotionEvent.ACTION_DOWN ? 0 : a == MotionEvent.ACTION_MOVE ? 1 : (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) ? 2 : -1;
            if (act >= 0) { final float x = e.getX(), y = e.getY(); gl.queueEvent(() -> Native.touch(act, x, y)); }
            return true;
        });

        glp = new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        glp.gravity = Gravity.TOP | Gravity.LEFT;
        glp.alpha = 0.8f;   // Android 12+: touches pass to the game only through overlays with alpha <= 0.8
        if (android.os.Build.VERSION.SDK_INT >= 28) glp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        wm.addView(gl, glp);

        btn = new ImageView(this);
        btn.setImageResource(R.drawable.icon);
        btn.setAlpha(0.75f);
        int pad = dp(7); btn.setPadding(pad, pad, pad, pad);
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setShape(android.graphics.drawable.GradientDrawable.OVAL); bg.setColor(0xD0101418); bg.setStroke(dp(1), 0x6051A5C1);
        btn.setBackground(bg);
        bp = new WindowManager.LayoutParams(dp(46), dp(46), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        bp.gravity = Gravity.TOP | Gravity.LEFT; bp.x = dp(16); bp.y = dp(90);
        if (android.os.Build.VERSION.SDK_INT >= 28) bp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        btn.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy; int ox, oy; boolean moved, longDone;
            final Runnable lp = () -> { longDone = true; gl.queueEvent(() -> Native.command(2)); };
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: sx = e.getRawX(); sy = e.getRawY(); ox = bp.x; oy = bp.y; moved = false; longDone = false; ui.postDelayed(lp, 600); return true;
                    case MotionEvent.ACTION_MOVE:
                        if (Math.abs(e.getRawX() - sx) > dp(6) || Math.abs(e.getRawY() - sy) > dp(6)) { if (!moved) ui.removeCallbacks(lp); moved = true; }
                        if (moved) { bp.x = ox + (int) (e.getRawX() - sx); bp.y = oy + (int) (e.getRawY() - sy); wm.updateViewLayout(btn, bp); }
                        return true;
                    case MotionEvent.ACTION_UP:
                        ui.removeCallbacks(lp);
                        if (!moved && !longDone) gl.queueEvent(() -> Native.command(1));
                        return true;
                    case MotionEvent.ACTION_CANCEL: ui.removeCallbacks(lp); return true;
                }
                return false;
            }
        });
        wm.addView(btn, bp);
    }

    private void apply(int f) {
        if (gl == null) return;
        if ((f & 2) != 0) { stopSelf(); return; }
        boolean want = (f & 1) != 0;   // menu open: overlay takes touches, closed: everything goes to the game
        if (want == touchable) return;
        touchable = want;
        if (want) { glp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE; glp.alpha = 1.0f; }
        else { glp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE; glp.alpha = 0.8f; }
        wm.updateViewLayout(gl, glp);
    }

    @Override public void onDestroy() {
        if (gl != null) { try { wm.removeView(gl); } catch (Exception ignored) {} gl = null; }
        if (btn != null) { try { wm.removeView(btn); } catch (Exception ignored) {} btn = null; }
        super.onDestroy();
        System.exit(0);   // native menu state is global: start clean next time
    }
}
