package com.anesthysia.menu;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.opengl.GLSurfaceView;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class OverlayService extends Service {
    private WindowManager wm;
    private GLSurfaceView gl;
    private View btn;
    private WindowManager.LayoutParams glp, bp;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private volatile boolean touchable = false;
    private boolean started = false;

    @Override public IBinder onBind(Intent i) { return null; }

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public int onStartCommand(Intent intent, int flags, int id) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel("ov", "Overlay", NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, "ov").setContentTitle("Anesthysia").setContentText("Overlay is running")
                .setSmallIcon(R.drawable.icon).setOngoing(true).build();
        startForeground(1, n);
        final boolean debug = intent != null && intent.getBooleanExtra("debug", false);
        final int delay = intent != null ? intent.getIntExtra("delay", 0) : 0;
        ui.removeCallbacksAndMessages(null);
        final Runnable go = new Runnable() { @Override public void run() {
            if (!started) { started = true; createOverlay(); }
            gl.queueEvent(new Runnable() { @Override public void run() { Native.command(debug ? 4 : 3); } });
        } };
        if (delay > 0) {
            final long end = System.currentTimeMillis() + delay * 1000L;
            Runnable tick = new Runnable() { @Override public void run() {
                long left = (end - System.currentTimeMillis() + 999) / 1000;
                if (left <= 0) { setStatus(nm, "Overlay is running"); go.run(); return; }
                setStatus(nm, "Starting in " + left + " s"); ui.postDelayed(this, 250);
            } };
            tick.run();
        } else go.run();
        return START_NOT_STICKY;
    }

    private void setStatus(NotificationManager nm, String text) {
        nm.notify(1, new Notification.Builder(this, "ov").setContentTitle("Anesthysia").setContentText(text)
                .setSmallIcon(R.drawable.icon).setOngoing(true).setOnlyAlertOnce(true).build());
    }

    private void createOverlay() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        gl = new GLSurfaceView(this);
        gl.setEGLContextClientVersion(3);
        gl.setEGLConfigChooser(8, 8, 8, 8, 0, 0);
        gl.getHolder().setFormat(PixelFormat.TRANSLUCENT);
        gl.setZOrderOnTop(true);
        gl.setPreserveEGLContextOnPause(true);
        gl.setRenderer(new GLSurfaceView.Renderer() {
            int last = -1;
            final int[] bar = new int[4], lastBar = new int[4];
            @Override public void onSurfaceCreated(GL10 g, EGLConfig c) { Native.init(); }
            @Override public void onSurfaceChanged(GL10 g, int w, int h) { Native.resize(w, h); }
            @Override public void onDrawFrame(GL10 g) {
                int f = Native.frame();
                if (f != last) { last = f; final int ff = f; ui.post(new Runnable() { @Override public void run() { apply(ff); } }); }
                Native.bar(bar);
                if (bar[0] != lastBar[0] || bar[1] != lastBar[1] || bar[2] != lastBar[2] || bar[3] != lastBar[3]) {
                    System.arraycopy(bar, 0, lastBar, 0, 4);
                    final int bx = bar[0], by = bar[1], bw = bar[2], bh = bar[3];
                    ui.post(new Runnable() { @Override public void run() { barNow[0] = bx; barNow[1] = by; barNow[2] = bw; barNow[3] = bh; applyBar(bx, by, bw, bh); } });
                }
            }
        });
        gl.setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
        gl.setOnTouchListener(new View.OnTouchListener() { @Override public boolean onTouch(View v, MotionEvent e) {
            int a = e.getActionMasked();
            final int act = a == MotionEvent.ACTION_DOWN ? 0 : a == MotionEvent.ACTION_MOVE ? 1 : (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) ? 2 : -1;
            if (act >= 0) { final float x = e.getX(), y = e.getY(); gl.queueEvent(new Runnable() { @Override public void run() { Native.touch(act, x, y); } }); }
            return true;
        } });
        // BlueStacks / mouse: hover moves the cursor, the wheel scrolls lists
        gl.setOnGenericMotionListener(new View.OnGenericMotionListener() { @Override public boolean onGenericMotion(View v, MotionEvent e) {
            final float x = e.getX(), y = e.getY();
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_HOVER_MOVE || a == MotionEvent.ACTION_HOVER_ENTER) { gl.queueEvent(new Runnable() { @Override public void run() { Native.touch(3, x, y); } }); return true; }
            if (a == MotionEvent.ACTION_SCROLL) {
                final float w = e.getAxisValue(MotionEvent.AXIS_VSCROLL);
                gl.queueEvent(new Runnable() { @Override public void run() { Native.touch(4, 0, w); } });
                return true;
            }
            return false;
        } });

        glp = new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        glp.gravity = Gravity.TOP | Gravity.LEFT;
        glp.alpha = 0.8f;   // Android 12+: touches pass to the game only through overlays with alpha <= 0.8
        if (android.os.Build.VERSION.SDK_INT >= 28) glp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        wm.addView(gl, glp);

        // invisible touch area over the black bar at the bottom: tap = open / close the menu, long press = text watermark.
        // (While the menu is open the overlay itself takes the touches, including the bar.)
        btn = new View(this);
        bp = new WindowManager.LayoutParams(1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        bp.gravity = Gravity.TOP | Gravity.LEFT;
        if (android.os.Build.VERSION.SDK_INT >= 28) bp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        btn.setOnTouchListener(new View.OnTouchListener() {
            boolean longDone;
            final Runnable lp = new Runnable() { @Override public void run() { longDone = true; gl.queueEvent(new Runnable() { @Override public void run() { Native.command(2); } }); } };
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: longDone = false; ui.postDelayed(lp, 600); return true;
                    case MotionEvent.ACTION_UP:
                        ui.removeCallbacks(lp);
                        if (!longDone) gl.queueEvent(new Runnable() { @Override public void run() { Native.command(1); } });
                        return true;
                    case MotionEvent.ACTION_CANCEL: ui.removeCallbacks(lp); return true;
                }
                return true;
            }
        });
        btn.setVisibility(View.GONE);
        wm.addView(btn, bp);
    }

    // bottom bar from the GL thread: place the touch area over it (only while the menu is closed)
    private final int[] barNow = new int[4];
    private void applyBar(int x, int y, int w, int h) {
        if (btn == null) return;
        boolean show = w > 0 && h > 0 && !touchable;
        if (show) {
            int px = dp(8), py = dp(10);
            bp.x = x - px; bp.y = y - py; bp.width = w + 2 * px; bp.height = h + 2 * py;
            wm.updateViewLayout(btn, bp);
        }
        btn.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    private void apply(int f) {
        if (gl == null) return;
        if ((f & 2) != 0) { stopSelf(); return; }
        boolean want = (f & 1) != 0;   // menu open: overlay takes touches, closed: everything goes to the game
        if (want == touchable) return;
        touchable = want;
        if (want) { glp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE; glp.alpha = 1.0f; }
        else { glp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE; glp.alpha = 0.8f; }
        wm.updateViewLayout(gl, glp);
        applyBar(barNow[0], barNow[1], barNow[2], barNow[3]);
    }

    @Override public void onDestroy() {
        if (gl != null) { try { wm.removeView(gl); } catch (Exception ignored) {} gl = null; }
        if (btn != null) { try { wm.removeView(btn); } catch (Exception ignored) {} btn = null; }
        super.onDestroy();
        System.exit(0);   // native menu state is global: start clean next time
    }
}
