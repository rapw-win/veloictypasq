package com.anesthysia.menu;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int MAX_DELAY = 120;   // seconds
    private SharedPreferences prefs;
    private TextView delayText;
    private int delay;

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private Button mkButton(String text, int color) {
        Button b = new Button(this);
        b.setText(text); b.setAllCaps(false); b.setTextColor(Color.WHITE); b.setTextSize(15);
        GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(9)); b.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(260), dp(48)); lp.topMargin = dp(10); b.setLayoutParams(lp);
        return b;
    }

    private void showDelay() { delayText.setText(delay == 0 ? "Overlay appears: immediately" : "Overlay appears in: " + delay + " s"); }

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        prefs = getSharedPreferences("anesthysia", MODE_PRIVATE);
        delay = Math.max(0, Math.min(MAX_DELAY, prefs.getInt("delay", 0)));
        getWindow().setStatusBarColor(0xFF0B0E12); getWindow().setNavigationBarColor(0xFF0B0E12);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER); root.setBackgroundColor(0xFF0B0E12);
        ImageView logo = new ImageView(this); logo.setImageResource(R.drawable.icon);
        root.addView(logo, new LinearLayout.LayoutParams(dp(64), dp(60)));
        TextView t = new TextView(this); t.setText("Anesthysia"); t.setTextColor(Color.WHITE); t.setTextSize(22); t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(8), 0, dp(4)); root.addView(t);
        TextView h = new TextView(this); h.setTextColor(0xFF8A93A0); h.setTextSize(12); h.setGravity(Gravity.CENTER);
        h.setText("Tap the black bar at the bottom of the screen to open / close the menu.\nLong press it to toggle the text watermark.");
        h.setPadding(dp(20), 0, dp(20), dp(14)); root.addView(h);

        // overlay delay (saved): how many seconds after Start the overlay appears
        delayText = new TextView(this); delayText.setTextColor(0xFFD9DBDF); delayText.setTextSize(14); delayText.setGravity(Gravity.CENTER);
        root.addView(delayText);
        SeekBar bar = new SeekBar(this); bar.setMax(MAX_DELAY); bar.setProgress(delay);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(dp(260), dp(36)); blp.topMargin = dp(4); bar.setLayoutParams(blp);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean user) { delay = p; showDelay(); }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) { prefs.edit().putInt("delay", delay).apply(); }
        });
        root.addView(bar);
        showDelay();

        Button start = mkButton("Start", 0xFF4F6FA8);
        Button dbg = mkButton("Start (Debug)", 0xFF1D2530);
        Button stop = mkButton("Stop", 0xFF1D2530);
        root.addView(start); root.addView(dbg); root.addView(stop);
        start.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { launch(false); } });
        dbg.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { launch(true); } });
        stop.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { stopService(new Intent(MainActivity.this, OverlayService.class)); } });
        setContentView(root);
    }

    private void launch(boolean debug) {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            return;
        }
        prefs.edit().putInt("delay", delay).apply();
        Intent i = new Intent(this, OverlayService.class); i.putExtra("debug", debug); i.putExtra("delay", delay);
        if (delay > 0) Toast.makeText(this, "Overlay starts in " + delay + " s", Toast.LENGTH_SHORT).show();
        startForegroundService(i);
        moveTaskToBack(true);
    }
}
