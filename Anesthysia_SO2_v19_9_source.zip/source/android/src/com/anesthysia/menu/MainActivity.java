package com.anesthysia.menu;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private Button mkButton(String text, int color) {
        Button b = new Button(this);
        b.setText(text); b.setAllCaps(false); b.setTextColor(Color.WHITE); b.setTextSize(15);
        GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(9)); b.setBackground(g);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(260), dp(48)); lp.topMargin = dp(10); b.setLayoutParams(lp);
        return b;
    }

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        getWindow().setStatusBarColor(0xFF0B0E12); getWindow().setNavigationBarColor(0xFF0B0E12);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER); root.setBackgroundColor(0xFF0B0E12);
        ImageView logo = new ImageView(this); logo.setImageResource(R.drawable.icon);
        root.addView(logo, new LinearLayout.LayoutParams(dp(64), dp(60)));
        TextView t = new TextView(this); t.setText("Anesthysia"); t.setTextColor(Color.WHITE); t.setTextSize(22); t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(8), 0, dp(4)); root.addView(t);
        TextView h = new TextView(this); h.setTextColor(0xFF8A93A0); h.setTextSize(12); h.setGravity(Gravity.CENTER);
        h.setText("Tap the floating icon to open / close the menu.\nLong press it to toggle the text watermark. Drag to move.");
        h.setPadding(dp(20), 0, dp(20), dp(10)); root.addView(h);
        Button start = mkButton("Start", 0xFF2C7A93);
        Button dbg = mkButton("Start (Debug)", 0xFF1D2530);
        Button stop = mkButton("Stop", 0xFF1D2530);
        root.addView(start); root.addView(dbg); root.addView(stop);
        start.setOnClickListener(v -> askDelay(false));
        dbg.setOnClickListener(v -> askDelay(true));
        stop.setOnClickListener(v -> stopService(new Intent(this, OverlayService.class)));
        setContentView(root);
    }

    private static final int[] DELAYS = { 0, 3, 5, 10, 15, 20, 30, 45, 60 };

    private void askDelay(boolean debug) {
        if (!Settings.canDrawOverlays(this)) { launch(debug, 0); return; }
        String[] items = new String[DELAYS.length];
        for (int i = 0; i < DELAYS.length; ++i) items[i] = DELAYS[i] == 0 ? "Immediately" : DELAYS[i] + " seconds";
        new android.app.AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Start overlay in")
                .setItems(items, (d, which) -> launch(debug, DELAYS[which]))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void launch(boolean debug, int delay) {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            return;
        }
        Intent i = new Intent(this, OverlayService.class); i.putExtra("debug", debug); i.putExtra("delay", delay);
        if (delay > 0) android.widget.Toast.makeText(this, "Overlay starts in " + delay + " s", android.widget.Toast.LENGTH_SHORT).show();
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        moveTaskToBack(true);
    }
}
