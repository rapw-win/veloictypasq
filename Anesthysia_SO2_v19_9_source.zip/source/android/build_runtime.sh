#!/bin/bash
# builds Android runtime pieces for one ABI: crtbegin_so.o, libbuiltins.a, libc++abi.a, libc++.a, stub .so files
set -u
T=$(cd "$(dirname "$0")" && pwd); A=$1   # aarch64 | x86_64
SR=$T/sysroot; O=$T/out/$A; mkdir -p $O/o $O/lib
TGT="--target=${A}-linux-android26 --sysroot=$SR -isystem $SR/usr/include/${A}-linux-android"
EXTRA=""; [ $A = aarch64 ] && EXTRA="-mno-outline-atomics"
CF="$TGT -fPIC -O2 -ffunction-sections -fdata-sections $EXTRA -w"
CXXF="$CF -std=c++23 -nostdinc++ -isystem $T/cxx -isystem $T/llvm/libcxx/include -isystem $T/llvm/libcxxabi/include -fno-exceptions"
fail=0
rm -f $O/skipped.txt $O/abi_err.txt $O/cxx_err.txt
# crt
clang $CF -c $T/bionic/libc/arch-common/bionic/crtbegin_so.c -o $O/lib/crtbegin_so.o || fail=1
# compiler-rt builtins (generic C files)
[ -f $O/lib/libbuiltins.a ] || { mkdir -p $O/o/rt; for f in $T/llvm/compiler-rt/lib/builtins/*.c; do b=$(basename $f .c); clang $CF -fno-builtin -c $f -o $O/o/rt/$b.o 2>/dev/null || echo "rt skip $b" >> $O/skipped.txt; done
llvm-ar rcs $O/lib/libbuiltins.a $O/o/rt/*.o; }
# libc++abi
mkdir -p $O/o/abi; for b in abort_message cxa_aux_runtime cxa_default_handlers cxa_demangle cxa_exception_storage cxa_guard cxa_handlers cxa_noexception cxa_thread_atexit cxa_vector cxa_virtual fallback_malloc private_typeinfo stdlib_exception stdlib_new_delete stdlib_stdexcept stdlib_typeinfo; do
  clang++ $CXXF -D_LIBCXXABI_BUILDING_LIBRARY -D_LIBCPP_BUILDING_LIBRARY -I$T/llvm/libcxxabi/src -c $T/llvm/libcxxabi/src/$b.cpp -o $O/o/abi/$b.o 2>>$O/abi_err.txt || { echo "abi FAIL $b" >> $O/skipped.txt; fail=1; }; done
llvm-ar rcs $O/lib/libc++abi.a $O/o/abi/*.o
# libc++
mkdir -p $O/o/cxx; for f in $T/llvm/libcxx/src/*.cpp; do b=$(basename $f .cpp); case $b in tz|tzdb_list|print) continue;; esac
  clang++ $CXXF -D_LIBCPP_BUILDING_LIBRARY -DLIBCXX_BUILDING_LIBCXXABI -D_LIBCPP_REMOVE_TRANSITIVE_INCLUDES -I$T/llvm/libcxx/src -c $f -o $O/o/cxx/$b.o 2>>$O/cxx_err.txt || echo "cxx skip $b" >> $O/skipped.txt; done
llvm-ar rcs $O/lib/libc++.a $O/o/cxx/*.o
# stub shared libraries (only SONAME matters: symbols stay undefined and resolve at load time)
echo "" > $O/o/empty.c
for l in c m dl log android EGL GLESv3; do clang $TGT -fPIC -shared -nostdlib -fuse-ld=lld -Wl,-soname,lib$l.so $O/o/empty.c -o $O/lib/lib$l.so || fail=1; done
echo "== $A done (fail=$fail)"; cat $O/skipped.txt 2>/dev/null | head -60
