// Anesthysia - Android overlay host (GLSurfaceView in a TYPE_APPLICATION_OVERLAY window)
#include <jni.h>
#include <GLES3/gl3.h>
#include <time.h>
#include <mutex>
#include <deque>
#include <float.h>
#include <math.h>
#include "imgui.h"
#include "backends/imgui_impl_opengl3.h"
#include "menu.h"
#include "res.h"

static bool g_inited = false, g_ctxMade = false;
static int g_w = 0, g_h = 0;
static GLuint g_logo = 0, g_soldier = 0, g_avatar = 0;
static double g_last = 0;
static bool g_placed = false;
static int g_pendingLoad = 3;   // the loader always starts on its own (3 normal, 4 debug); a command may arrive before the GL context exists
struct Ev { int type; float x, y; };   // 0 pos, 1 down, 2 up, 3 leave
static std::deque<Ev> g_ev;
static std::mutex g_evm;

static double Now() { timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + t.tv_nsec * 1e-9; }

static GLuint MakeTex(const unsigned char* rgba, int w, int h)
{
    GLuint t; glGenTextures(1, &t); glBindTexture(GL_TEXTURE_2D, t);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, rgba);
    return t;
}

static void InvalidateTextures()   // EGL context was recreated: every ImGui texture must be uploaded again
{
    for (ImTextureData* td : ImGui::GetPlatformIO().Textures)
        if (td->Status == ImTextureStatus_OK || td->Status == ImTextureStatus_WantUpdates) { td->SetTexID(ImTextureID_Invalid); td->SetStatus(ImTextureStatus_WantCreate); }
}

extern "C" JNIEXPORT void JNICALL Java_com_anesthysia_menu_Native_init(JNIEnv*, jclass)
{
    if (!g_ctxMade) {
        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
        ImGuiIO& io = ImGui::GetIO();
        io.IniFilename = nullptr; io.LogFilename = nullptr;
        io.ConfigFlags |= ImGuiConfigFlags_NoMouseCursorChange | ImGuiConfigFlags_IsTouchScreen;
        Menu_LoadFonts();
        Menu_RequireLoader();
        Menu_StartLoader(g_pendingLoad == 4);
        g_ctxMade = true;
    } else if (g_inited) {
        ImGui_ImplOpenGL3_Shutdown();
        InvalidateTextures();
    }
    ImGui_ImplOpenGL3_Init("#version 300 es");
    g_logo = MakeTex(logo_rgba, logo_w, logo_h);
    g_soldier = MakeTex(soldier_rgba, soldier_w, soldier_h);
    g_avatar = MakeTex(avatar_rgba, avatar_w, avatar_h);
    g_inited = true;
    g_last = Now();
}

extern "C" JNIEXPORT void JNICALL Java_com_anesthysia_menu_Native_resize(JNIEnv*, jclass, jint w, jint h)
{
    g_w = w; g_h = h;
    glViewport(0, 0, w, h);
    if (!g_placed && w > 0 && h > 0) {   // fit the 798x612 menu on a phone screen (DPI steps of 0.25)
        g_placed = true;
        float s = fminf((float)h * 0.92f / 612.0f, (float)w * 0.92f / 798.0f);
        s = floorf(s * 4.0f) / 4.0f; if (s < 0.75f) s = 0.75f; if (s > 3.0f) s = 3.0f;
        Menu_SetDpiScale(s);
        Menu_SetPos(floorf(((float)w - 798.0f * s) * 0.5f), floorf(((float)h - 612.0f * s) * 0.5f));
    }
}

extern "C" JNIEXPORT void JNICALL Java_com_anesthysia_menu_Native_touch(JNIEnv*, jclass, jint a, jfloat x, jfloat y)
{
    std::lock_guard<std::mutex> lk(g_evm);
    g_ev.push_back({ 0, x, y });
    if (a == 0) g_ev.push_back({ 1, x, y });
    else if (a == 2) { g_ev.push_back({ 2, x, y }); g_ev.push_back({ 3, x, y }); }
}

extern "C" JNIEXPORT void JNICALL Java_com_anesthysia_menu_Native_command(JNIEnv*, jclass, jint c)
{
    if (!g_ctxMade) { if (c == 3 || c == 4) g_pendingLoad = c; return; }
    if (c == 1) { if (!Menu_WantsUnload()) Menu_Toggle(); }
    else if (c == 2) Menu_ToggleTextWm();
    else if (c == 3) Menu_StartLoader(false);
    else if (c == 4) Menu_StartLoader(true);
}

extern "C" JNIEXPORT jint JNICALL Java_com_anesthysia_menu_Native_frame(JNIEnv*, jclass)
{
    if (!g_inited || g_w <= 0) return 0;
    double now = Now(); float dt = (float)(now - g_last); g_last = now;
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2((float)g_w, (float)g_h);
    io.DeltaTime = dt > 0.0f && dt < 0.5f ? dt : 1.0f / 60.0f;
    {   // one button transition per frame: hover is resolved before the press, the press before the release
        std::lock_guard<std::mutex> lk(g_evm);
        while (!g_ev.empty()) {
            Ev e = g_ev.front();
            if (e.type == 0) { io.AddMouseSourceEvent(ImGuiMouseSource_TouchScreen); io.AddMousePosEvent(e.x, e.y); g_ev.pop_front(); continue; }
            if (e.type == 1) { io.AddMouseSourceEvent(ImGuiMouseSource_TouchScreen); io.AddMouseButtonEvent(0, true); g_ev.pop_front(); break; }
            if (e.type == 2) { io.AddMouseSourceEvent(ImGuiMouseSource_TouchScreen); io.AddMouseButtonEvent(0, false); g_ev.pop_front(); break; }
            if (e.type == 3) { io.AddMousePosEvent(-FLT_MAX, -FLT_MAX); g_ev.pop_front(); break; }
        }
    }
    MenuPlatform mp; mp.avatarTex = (ImTextureID)(intptr_t)g_avatar; mp.logoTex = (ImTextureID)(intptr_t)g_logo; mp.soldierTex = (ImTextureID)(intptr_t)g_soldier;
    Menu_SetPlatform(mp);

    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();
    Menu_Frame(io.DeltaTime);
    ImGui::Render();
    glViewport(0, 0, g_w, g_h);
    glClearColor(0, 0, 0, 0);
    glClear(GL_COLOR_BUFFER_BIT);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    int f = 0;
    if (Menu_IsVisible()) f |= 1;
    if (Menu_UnloadReady()) f |= 2;
    return f;
}
