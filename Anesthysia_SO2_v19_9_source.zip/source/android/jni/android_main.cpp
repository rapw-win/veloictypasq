// Anesthysia - Android overlay host (GLSurfaceView in a TYPE_APPLICATION_OVERLAY window)
// Same menu as the Windows overlay. Android (BlueStacks Pie 64 / Android 9) cannot blur other apps' windows, so:
//  - the blur of the menu itself (popups over the menu, open / close animation) is done here in GLES3, like the D3D11 host does;
//  - the menu is told there is no blur of the game behind it (Menu_SetHostBlur(false)) and uses denser panels instead.
#include <jni.h>
#include <GLES3/gl3.h>
#include <time.h>
#include <mutex>
#include <deque>
#include <float.h>
#include <math.h>
#include "imgui.h"
#include "backends/imgui_impl_opengl3.h"
#include "menu.h"
#include "res.h"

static bool g_inited = false, g_ctxMade = false;
static int g_w = 0, g_h = 0;
static GLuint g_logo = 0, g_soldier = 0, g_avatar = 0;
static double g_last = 0;
static bool g_placed = false;
static int g_pendingLoad = 3;   // the loader always starts on its own (3 normal, 4 debug); a command may arrive before the GL context exists
struct Ev { int type; float x, y; };   // 0 pos, 1 down, 2 up, 3 leave, 4 wheel (y = steps)
static std::deque<Ev> g_ev;
static std::mutex g_evm;

static double Now() { timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + t.tv_nsec * 1e-9; }

static GLuint MakeTex(const unsigned char* rgba, int w, int h)
{
    GLuint t; glGenTextures(1, &t); glBindTexture(GL_TEXTURE_2D, t);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, rgba);
    return t;
}

// ---------------------------------------------------------------- blur (port of the D3D11 host: downsample, 2x separable gaussian, mix)
// g_copy: full-size copy of the framebuffer (GL orientation); g_bt[0..1]: half-size ping-pong targets, stored top-down
// so ImGui can sample g_bt[0] with screen-space UVs (v = 0 at the top), exactly like the Windows blur texture.
static GLuint g_prog[3] = {};                 // 0 down (flips), 1 blur, 2 mix
static GLint  g_uTexel[3], g_uDir, g_uMix, g_uTex0[3], g_uTex1, g_uSize;
static GLuint g_copy = 0, g_bt[2] = {}, g_fbo[2] = {}, g_vao = 0;
static int g_cw = 0, g_ch = 0, g_bw = 0, g_bh = 0;
static const char* kVS = "#version 300 es\nout vec2 uv;\nvoid main(){ vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2)); uv = p; gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0); }\n";
static const char* kFS[3] = {
    // downsample (4 bilinear taps), flipped vertically: output row 0 = top of the screen
    "#version 300 es\nprecision mediump float;\nin vec2 uv; out vec4 o; uniform sampler2D tex0; uniform vec2 texel;\n"
    "void main(){ vec2 u = vec2(uv.x, 1.0 - uv.y); vec2 t = texel * 0.5;\n"
    " o = 0.25 * (texture(tex0, u + vec2(-t.x,-t.y)) + texture(tex0, u + vec2(t.x,-t.y)) + texture(tex0, u + vec2(-t.x,t.y)) + texture(tex0, u + vec2(t.x,t.y))); }\n",
    // 9-tap gaussian with linear sampling
    "#version 300 es\nprecision mediump float;\nin vec2 uv; out vec4 o; uniform sampler2D tex0; uniform vec2 texel; uniform vec2 dir;\n"
    "void main(){ const float w0 = 0.1964825501511404, w1 = 0.2969069646728344, w2 = 0.09447039785044732, w3 = 0.010381362401148057;\n"
    " const float o1 = 1.411764705882353, o2 = 3.2941176470588234, o3 = 5.176470588235294; vec2 d = dir * texel;\n"
    " o = texture(tex0, uv) * w0 + (texture(tex0, uv + d * o1) + texture(tex0, uv - d * o1)) * w1\n"
    "   + (texture(tex0, uv + d * o2) + texture(tex0, uv - d * o2)) * w2 + (texture(tex0, uv + d * o3) + texture(tex0, uv - d * o3)) * w3; }\n",
    // open / close animation: cross-fade sharp -> blurred inside the scissor rect
    "#version 300 es\nprecision mediump float;\nout vec4 o; uniform sampler2D tex0; uniform sampler2D tex1; uniform float mixv; uniform vec2 size;\n"
    "void main(){ vec2 f = gl_FragCoord.xy / size; o = mix(texture(tex0, f), texture(tex1, vec2(f.x, 1.0 - f.y)), mixv); }\n",
};
static GLuint Compile(GLenum type, const char* src)
{
    GLuint s = glCreateShader(type); glShaderSource(s, 1, &src, nullptr); glCompileShader(s);
    GLint ok = 0; glGetShaderiv(s, GL_COMPILE_STATUS, &ok); if (!ok) { glDeleteShader(s); return 0; }
    return s;
}
static void CreateBlurPipeline()
{
    GLuint vs = Compile(GL_VERTEX_SHADER, kVS);
    for (int i = 0; i < 3; ++i) {
        GLuint fs = Compile(GL_FRAGMENT_SHADER, kFS[i]);
        if (!vs || !fs) { g_prog[i] = 0; continue; }
        GLuint p = glCreateProgram(); glAttachShader(p, vs); glAttachShader(p, fs); glLinkProgram(p); glDeleteShader(fs);
        GLint ok = 0; glGetProgramiv(p, GL_LINK_STATUS, &ok); if (!ok) { glDeleteProgram(p); p = 0; }
        g_prog[i] = p;
        if (p) { g_uTexel[i] = glGetUniformLocation(p, "texel"); g_uTex0[i] = glGetUniformLocation(p, "tex0"); }
    }
    if (vs) glDeleteShader(vs);
    if (g_prog[1]) g_uDir = glGetUniformLocation(g_prog[1], "dir");
    if (g_prog[2]) { g_uMix = glGetUniformLocation(g_prog[2], "mixv"); g_uTex1 = glGetUniformLocation(g_prog[2], "tex1"); g_uSize = glGetUniformLocation(g_prog[2], "size"); }
    glGenVertexArrays(1, &g_vao);
}
static GLuint NewTarget(int w, int h)
{
    GLuint t; glGenTextures(1, &t); glBindTexture(GL_TEXTURE_2D, t);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    return t;
}
static void EnsureBlurTargets()
{
    if (g_cw == g_w && g_ch == g_h && g_copy) return;
    if (g_copy) { glDeleteTextures(1, &g_copy); glDeleteTextures(2, g_bt); glDeleteFramebuffers(2, g_fbo); }
    g_cw = g_w; g_ch = g_h; g_bw = g_w / 2 > 0 ? g_w / 2 : 1; g_bh = g_h / 2 > 0 ? g_h / 2 : 1;
    g_copy = NewTarget(g_w, g_h);
    glGenFramebuffers(2, g_fbo);
    for (int i = 0; i < 2; ++i) {
        g_bt[i] = NewTarget(g_bw, g_bh);
        glBindFramebuffer(GL_FRAMEBUFFER, g_fbo[i]);
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, g_bt[i], 0);
    }
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
}
static void Pass(int prog, GLuint src, int dst, float tx, float ty, float dx, float dy)
{
    glBindFramebuffer(GL_FRAMEBUFFER, g_fbo[dst]);
    glUseProgram(g_prog[prog]);
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, src);
    glUniform1i(g_uTex0[prog], 0);
    glUniform2f(g_uTexel[prog], tx, ty);
    if (prog == 1) glUniform2f(g_uDir, dx, dy);
    glDrawArrays(GL_TRIANGLES, 0, 3);
}
// copy the framebuffer and blur it into g_bt[0]; radius steps as in the D3D11 host
static bool BlurFramebuffer(int iters, float radius0, float radiusStep)
{
    if (!g_prog[0] || !g_prog[1] || g_w <= 0) return false;
    EnsureBlurTargets();
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, g_copy);
    glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, g_w, g_h);
    glDisable(GL_BLEND); glDisable(GL_SCISSOR_TEST); glDisable(GL_CULL_FACE); glDisable(GL_DEPTH_TEST);
    glBindVertexArray(g_vao);
    glViewport(0, 0, g_bw, g_bh);
    Pass(0, g_copy, 0, 1.0f / g_w, 1.0f / g_h, 0, 0);
    const float tx = 1.0f / g_bw, ty = 1.0f / g_bh;
    for (int it = 0; it < iters; ++it) {
        float s = radius0 + radiusStep * it;
        Pass(1, g_bt[0], 1, tx, ty, s, 0);
        Pass(1, g_bt[1], 0, tx, ty, 0, s);
    }
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glViewport(0, 0, g_w, g_h);
    return true;
}
// ImDrawCallback: blur whatever has been drawn so far (the menu under a popup); the menu then draws g_bt[0] with screen UVs
static void BlurCallback(const ImDrawList*, const ImDrawCmd*) { BlurFramebuffer(2, 1.0f, 0.75f); }
// after the UI is rendered: blur the menu itself during its open / close animation
static void AnimBlurMenu(float t, float x0, float y0, float x1, float y1)
{
    if (!g_prog[2]) return;
    t = t * t * (3.0f - 2.0f * t);
    if (!BlurFramebuffer(3, t, t * 1.25f)) return;
    glEnable(GL_SCISSOR_TEST);
    int sx = (int)fmaxf(0.0f, x0), sy = (int)fmaxf(0.0f, y0);
    glScissor(sx, g_h - (int)y1 - 1, (int)(x1 - sx) + 1, (int)(y1 - sy) + 1);   // GL scissor is bottom-up
    glUseProgram(g_prog[2]);
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, g_copy);
    glActiveTexture(GL_TEXTURE1); glBindTexture(GL_TEXTURE_2D, g_bt[0]);
    glUniform1i(g_uTex0[2], 0); glUniform1i(g_uTex1, 1);
    glUniform1f(g_uMix, t < 1.0f ? fminf(1.0f, t * 4.0f) : 1.0f);
    glUniform2f(g_uSize, (float)g_w, (float)g_h);
    glDrawArrays(GL_TRIANGLES, 0, 3);
    glActiveTexture(GL_TEXTURE0);
    glDisable(GL_SCISSOR_TEST);
}

static void InvalidateTextures()   // EGL context was recreated: every ImGui texture must be uploaded again
{
    for (ImTextureData* td : ImGui::GetPlatformIO().Textures)
        if (td->Status == ImTextureStatus_OK || td->Status == ImTextureStatus_WantUpdates) { td->SetTexID(ImTextureID_Invalid); td->SetStatus(ImTextureStatus_WantCreate); }
}

extern "C" JNIEXPORT void JNICALL Java_com_anesthysia_menu_Native_init(JNIEnv*, jclass)
{
    if (!g_ctxMade) {
        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
        ImGuiIO& io = ImGui::GetIO();
        io.IniFilename = nullptr; io.LogFilename = nullptr;
        io.ConfigFlags |= ImGuiConfigFlags_NoMouseCursorChange;
        Menu_LoadFonts();
        Menu_SetHostBlur(false);
        Menu_RequireLoader();
        Menu_StartLoader(g_pendingLoad == 4);
        g_ctxMade = true;
    } else if (g_inited) {
        ImGui_ImplOpenGL3_Shutdown();
        InvalidateTextures();
    }
    ImGui_ImplOpenGL3_Init("#version 300 es");
    g_logo = MakeTex(logo_rgba, logo_w, logo_h);
    g_soldier = MakeTex(soldier_rgba, soldier_w, soldier_h);
    g_avatar = MakeTex(avatar_rgba, avatar_w, avatar_h);
    g_copy = 0; g_cw = g_ch = 0;   // GL objects of a lost context are gone
    CreateBlurPipeline();
    g_inited = true;
    g_last = Now();
}

extern "C" JNIEXPORT void JNICALL Java_com_anesthysia_menu_Native_resize(JNIEnv*, jclass, jint w, jint h)
{
    g_w = w; g_h = h;
    glViewport(0, 0, w, h);
    if (!g_placed && w > 0 && h > 0) {   // fit the 798x612 menu on the screen (DPI steps of 0.25); this is also "Auto" in profile > Menu Scale
        g_placed = true;
        float s = fminf((float)h * 0.92f / 612.0f, (float)w * 0.92f / 798.0f);
        s = floorf(s * 4.0f) / 4.0f; if (s < 0.75f) s = 0.75f; if (s > 3.0f) s = 3.0f;
        Menu_SetAutoScale(s);
        Menu_SetDpiScale(s);
        Menu_SetPos(floorf(((float)w - 798.0f * s) * 0.5f), floorf(((float)h - 612.0f * s) * 0.5f));
    }
}

// touch / mouse from Java: 0 down, 1 move, 2 up, 3 hover (mouse moving without a button: BlueStacks), 4 wheel (y = steps)
extern "C" JNIEXPORT void JNICALL Java_com_anesthysia_menu_Native_touch(JNIEnv*, jclass, jint a, jfloat x, jfloat y)
{
    std::lock_guard<std::mutex> lk(g_evm);
    if (a == 4) { g_ev.push_back({ 4, 0, y }); return; }
    g_ev.push_back({ 0, x, y });
    if (a == 0) g_ev.push_back({ 1, x, y });
    else if (a == 2) { g_ev.push_back({ 2, x, y }); g_ev.push_back({ 3, x, y }); }
}

extern "C" JNIEXPORT void JNICALL Java_com_anesthysia_menu_Native_command(JNIEnv*, jclass, jint c)
{
    if (!g_ctxMade) { if (c == 3 || c == 4) g_pendingLoad = c; return; }
    if (c == 1) { if (!Menu_WantsUnload()) Menu_Toggle(); }
    else if (c == 2) Menu_ToggleTextWm();
    else if (c == 3) Menu_StartLoader(false);
    else if (c == 4) Menu_StartLoader(true);
}

extern "C" JNIEXPORT jint JNICALL Java_com_anesthysia_menu_Native_frame(JNIEnv*, jclass)
{
    if (!g_inited || g_w <= 0) return 0;
    double now = Now(); float dt = (float)(now - g_last); g_last = now;
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2((float)g_w, (float)g_h);
    io.DeltaTime = dt > 0.0f && dt < 0.5f ? dt : 1.0f / 60.0f;
    {   // one button transition per frame: hover is resolved before the press, the press before the release
        std::lock_guard<std::mutex> lk(g_evm);
        while (!g_ev.empty()) {
            Ev e = g_ev.front();
            if (e.type == 0) { io.AddMousePosEvent(e.x, e.y); g_ev.pop_front(); continue; }
            if (e.type == 4) { io.AddMouseWheelEvent(0.0f, e.y); g_ev.pop_front(); continue; }
            if (e.type == 1) { io.AddMouseButtonEvent(0, true); g_ev.pop_front(); break; }
            if (e.type == 2) { io.AddMouseButtonEvent(0, false); g_ev.pop_front(); break; }
            if (e.type == 3) { g_ev.pop_front(); break; }   // finger lifted: keep the last position (mouse hover keeps working on BlueStacks)
        }
    }
    MenuPlatform mp; mp.avatarTex = (ImTextureID)(intptr_t)g_avatar; mp.logoTex = (ImTextureID)(intptr_t)g_logo; mp.soldierTex = (ImTextureID)(intptr_t)g_soldier;
    if (g_prog[0] && g_prog[1]) { EnsureBlurTargets(); mp.blurTex = (ImTextureID)(intptr_t)g_bt[0]; mp.blurCallback = BlurCallback; }
    Menu_SetPlatform(mp);

    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();
    Menu_Frame(io.DeltaTime);
    ImGui::Render();
    glViewport(0, 0, g_w, g_h);
    glClearColor(0, 0, 0, 0);
    glClear(GL_COLOR_BUFFER_BIT);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    { float t, x0, y0, x1, y1; if (Menu_GetAnimBlur(&t, &x0, &y0, &x1, &y1)) AnimBlurMenu(t, x0, y0, x1, y1); }
    int f = 0;
    if (Menu_IsVisible()) f |= 1;
    if (Menu_UnloadReady()) f |= 2;
    return f;
}
