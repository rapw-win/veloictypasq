#!/bin/bash
# Builds libanesthysia.so for one ABI with clang + lld against an Android sysroot.
#   $1 = arm64-v8a | x86_64     env: SYSROOT (bionic headers), RT (dir with crtbegin_so.o, libc++.a, libc++abi.a, libbuiltins.a, stub .so),
#   CXXINC (libc++ include dirs, ':' separated), IMGUI (Dear ImGui source dir), SRC (menu sources), OUT (output dir)
set -e
case $1 in arm64-v8a) A=aarch64; EXTRA="-mno-outline-atomics";; x86_64) A=x86_64; EXTRA="";; *) echo "abi?"; exit 1;; esac
TGT="--target=${A}-linux-android26 --sysroot=$SYSROOT -isystem $SYSROOT/usr/include/${A}-linux-android"
INC="-nostdinc++"; IFS=: read -ra CI <<< "$CXXINC"; for d in "${CI[@]}"; do INC="$INC -isystem $d"; done
CXXF="$TGT $INC -std=c++17 -O2 -fPIC -fno-exceptions -ffunction-sections -fdata-sections -fvisibility=hidden $EXTRA -w -I$SRC -I$IMGUI -I$IMGUI/backends -Wa,-I$SRC"
O=$OUT/obj/$1; mkdir -p $O $OUT/lib/$1
cd $SRC
pids=""
for f in menu model3d w3d; do clang++ $CXXF -c $f.cpp -o $O/$f.o & pids="$pids $!"; done
for f in imgui imgui_draw imgui_tables imgui_widgets; do clang++ $CXXF -c $IMGUI/$f.cpp -o $O/$f.o & pids="$pids $!"; done
clang++ $CXXF -DIMGUI_IMPL_OPENGL_ES3 -c $IMGUI/backends/imgui_impl_opengl3.cpp -o $O/gl3.o & pids="$pids $!"
clang++ $CXXF -DIMGUI_IMPL_OPENGL_ES3 -c android/jni/android_main.cpp -o $O/main.o & pids="$pids $!"
for p in $pids; do wait $p; done
clang++ $TGT -shared -nostdlib -fuse-ld=lld -Wl,-soname,libanesthysia.so -Wl,--gc-sections -Wl,--exclude-libs,ALL -Wl,-z,max-page-size=16384 -Wl,--build-id \
    $RT/crtbegin_so.o $O/*.o $RT/libc++.a $RT/libc++abi.a $RT/libbuiltins.a -L$RT -landroid -lEGL -lGLESv3 -llog -lm -ldl -lc \
    -o $OUT/lib/$1/libanesthysia.so
llvm-strip --strip-unneeded $OUT/lib/$1/libanesthysia.so
echo built $1
