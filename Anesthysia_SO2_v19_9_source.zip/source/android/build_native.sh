#!/bin/sh
# $1 = abi (arm64-v8a | x86_64)
NDK=/data/android/sdk/ndk/26.3.11579264/toolchains/llvm/prebuilt/linux-x86_64/bin
case $1 in arm64-v8a) CXX=$NDK/aarch64-linux-android26-clang++;; x86_64) CXX=$NDK/x86_64-linux-android26-clang++;; esac
B=/data/build; O=/data/apk/obj/$1; mkdir -p $O lib/$1
for f in menu model3d imgui imgui_draw imgui_tables imgui_widgets; do $CXX -O2 -std=c++17 -fPIC -w -I$B -c $B/$f.cpp -o $O/$f.o & done
$CXX -O2 -std=c++17 -fPIC -w -I$B -DIMGUI_IMPL_OPENGL_ES3 -c $B/backends/imgui_impl_opengl3.cpp -o $O/gl3.o &
$CXX -O2 -std=c++17 -fPIC -w -I$B -DIMGUI_IMPL_OPENGL_ES3 -c jni/android_main.cpp -o $O/main.o &
wait
$CXX -shared -static-libstdc++ -Wl,--no-undefined -Wl,-z,max-page-size=16384 -o lib/$1/libanesthysia.so $O/*.o -landroid -lEGL -lGLESv3 -llog -lm && echo built $1
