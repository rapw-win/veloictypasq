#include "w3d.h"
#include "inv_data.h"
#include "model3d.h"
#include <cstdio>
#include <vector>
#include <thread>
#include <atomic>
int main() {
    std::vector<std::pair<int,int>> jobs; int a, b; while (scanf("%d %d", &a, &b) == 2) jobs.push_back({a, b});
    std::vector<W3DProj> res(jobs.size()); std::vector<float> iou(jobs.size()); std::atomic<int> nx(0);
    W3DProj dummy; { int w,h; } 
    auto work = [&]() { for (;;) { int j = nx++; if (j >= (int)jobs.size()) break; const InvItem& it = INV_ITEMS[jobs[j].first]; int w, h;
        unsigned char* px = M3D_DecodeImage(INV_BLOB + it.off, it.size, &w, &h, 4); if (!px) continue;
        iou[j] = W3D_FitIcon(jobs[j].second, px, w, h, &res[j], jobs[j].second < 15); M3D_FreeImage(px); } };
    // warm InitFlip single-threaded
    { const InvItem& it = INV_ITEMS[jobs[0].first]; int w,h; unsigned char* px = M3D_DecodeImage(INV_BLOB + it.off, it.size, &w, &h, 4); W3D_FitIcon(jobs[0].second, px, w, h, &res[0], jobs[0].second < 15); M3D_FreeImage(px); }
    std::vector<std::thread> th; for (int i = 0; i < (int)std::thread::hardware_concurrency(); ++i) th.emplace_back(work); for (auto& t : th) t.join();
    for (size_t j = 0; j < jobs.size(); ++j) printf("%d %.3f %.5f %.5f %.5f %.4f %.3f %.3f\n", jobs[j].first, iou[j], res[j].roll, res[j].yaw, res[j].pitch, res[j].s, res[j].tx, res[j].ty);
}
