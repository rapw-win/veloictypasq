#include "w3d.h"
#include <vector>
#include <cstdio>
#include <cstdlib>
int main(int c, char** v) { int W=320,H=140; std::vector<uint8_t> b(W*H*4);
 for (int m=0;m<W3D_ModelCount();++m){ W3D_Render(b.data(),W,H,m, c>m+1? atoi(v[m+1]) : -1, 0.0f, 0.0f); char n[64]; snprintf(n,64,"/tmp/w3d_%02d.rgba",m); FILE*f=fopen(n,"wb"); fwrite(b.data(),1,b.size(),f); fclose(f);} }
