import UnityPy, numpy as np, pickle
from UnityPy.helpers.MeshHelper import MeshHandler
env=UnityPy.load('so2/obb/assets/CustomDLC/DefaultCollection/defaultcollection_content_mesh.bundle')
out={}
for o in env.objects:
    if o.type.name=="Mesh" and o.peek_name() in ("LOD0_M4","LOD1_M4","LOD1_M4_Magazine","LOD1_M4_ChargingHandle","LOD0_M4_Magazine","LOD0_M4_ChargingHandle"):
        m=o.read(); hd=MeshHandler(m); hd.process()
        V=np.array(hd.m_Vertices).reshape(-1,3); n=len(V)
        N=np.array(hd.m_Normals).reshape(n,-1)[:,:3]; UV=np.array(hd.m_UV0).reshape(n,-1)[:,:2]
        print(m.m_Name, n, sum(len(t) for t in hd.get_triangles())//3, V.min(0).round(3), V.max(0).round(3))
        out[m.m_Name]=dict(V=V,N=N,UV=UV,tris=hd.get_triangles())
pickle.dump(out,open('ex/m4.pkl','wb'))
env=UnityPy.load('so2/obb/assets/CustomDLC/DefaultCollection/defaultcollection_content_materials.bundle')
for o in env.objects:
    if o.type.name=="Texture2D" and o.peek_name() in("M4_A","M4_D"):
        t=o.read(); t.image.save(f'ex/{t.m_Name}.png'); print(t.m_Name,t.image.size)
