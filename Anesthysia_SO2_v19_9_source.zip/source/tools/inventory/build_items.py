import json,re,collections
d=json.load(open('allimages.json')); byname={x['name']:x for x in d}
sk=json.load(open('skins.json'))
known={}
for o in sk: known[o['file']]=o
W={'USP':['usp'],'P350':['p350'],'F/S':['f_s','fs','five-seven','five_seven'],'Berettas':['berettas'],'Desert Eagle':['desert_eagle','deagle'],
'MP7':['mp7'],'P90':['p90'],'UMP45':['ump45','ump-45','ump_45'],'MP5':['mp5'],'SM1014':['sm1014'],
'FAMAS':['famas'],'M4':['m4'],'M4A1':['m4a1'],'M16':['m16'],'AWM':['awm'],
'Karambit':['karambit'],'M9 Bayonet':['m9_bayonet'],'Butterfly':['butterfly'],'Kunai':['kunai'],'Tanto':['tanto'],'Stiletto':['stiletto'],'Fang':['fang'],'Kukri':['kukri'],'Sting':['sting'],'Flip':['flip_knife','flipknife','flip'],'Scorpion':['scorpion'],'Mantis':['mantis'],'Dual Daggers':['dual_daggers'],'jKommando':['jkommando'],
'Gloves':['gloves'],'Graffiti':['graffiti'],'Charm':['charm']}
KN=['Karambit','M9 Bayonet','Butterfly','Kunai','Tanto','Stiletto','Fang','Kukri','Sting','Flip','Scorpion','Mantis','Dual Daggers','jKommando']
JUNK=re.compile(r'^(|\(\d\)|\d|info|new|thumb|default_animation|rare_animation|animation_\d|skins|collection_logo|box|case|cam|unknown|old_name|.*proof.*|.*_old|2|1)$',re.I)
items=[];seen={}
for x in d:
    n=x['name']
    if n.lower().endswith('.gif'): continue
    b=re.sub(r'\.(png|jpg|jpeg)$','',n,flags=re.I); bl=b.lower().replace(' ','_')
    for w,ps in W.items():
        hit=None
        for p in sorted(ps,key=len,reverse=True):
            if bl.startswith(p+'_') or bl==p: hit=p;break
        if not hit: continue
        if w=='M4' and bl.startswith('m4a1'): break
        if w=='Graffiti' and bl.startswith('graffiti_thumbs'): pass
        s=b[len(hit):].strip('_ -').replace('"','').replace('_',' ').strip()
        if JUNK.match(s.replace(' ','_')): 
            if s.lower()=='new' and w not in('Gloves','Graffiti','Charm'): items.append(dict(cat='default',weapon=w,skin='',file=n,url=x['url'],w=x['width'],h=x['height']))
            break
        s=re.sub(r'\s+new$','',s,flags=re.I); s=re.sub(r'^(4Y|4 years)$','4 Years',s,flags=re.I)
        s=re.sub(r'(?<=[a-z])(?=[A-Z])',' ',s)   # CamelCase -> words
        s=' '.join(t[:1].upper()+t[1:] for t in s.split())
        cat='knife' if w in KN else ('gloves' if w=='Gloves' else ('graffiti' if w=='Graffiti' else ('charm' if w=='Charm' else 'weapon')))
        k=(w,s.lower())
        it=dict(cat=cat,weapon=w,skin=s,file=n,url=x['url'],w=x['width'],h=x['height'])
        if n in known: it['rarity']=known[n]['rarity']; it['coll']=known[n]['coll']
        if k in seen:   # prefer bigger / newer image
            j=seen[k]
            if x['width']*x['height']>items[j]['w']*items[j]['h']: it.setdefault('rarity',items[j].get('rarity')); it.setdefault('coll',items[j].get('coll')); items[j]=it
            continue
        seen[k]=len(items); items.append(it); break
# medals
M=json.load(open('medals.json'))
for p,t in M.items():
    for fm in re.finditer(r'\[\[File:([^|\]]+)\|[^\]]*?\|([^|\]]*)\]\]',t):
        fn=fm.group(1).strip(); cap=fm.group(2)
        x=byname.get(fn.replace(' ','_')) or byname.get(fn)
        if not x: continue
        mm=re.search(r'["“](.+?)["”]',cap); s=mm.group(1) if mm else re.sub(r'\.(png|jpg)$','',fn,flags=re.I).replace('_',' ')
        items.append(dict(cat='medal',weapon='Medal',skin=s,file=x['name'],url=x['url'],w=x['width'],h=x['height'],coll=p.replace(' Medals','')))
json.dump(items,open('items.json','w'),indent=0)
c=collections.Counter(i['cat'] for i in items); print(c)
print([i['weapon'] for i in items if i['cat']=='default'])
print(sum(1 for i in items if i.get('rarity')), 'with rarity')
