import UnityPy,numpy as np,pickle,os
from UnityPy.helpers.MeshHelper import MeshHandler
os.chdir('/data/so2/obb/assets/DLC/BuiltInCollections')
L={}
for f,n in (('builtincollections_shared_chameleon_models.bundle','LOD0_Classic_G'),('builtincollections_shared_wrap_gloves.bundle','LOD0_Wrap_G')):
    for o in UnityPy.load(f).objects:
        if o.type.name=='Mesh' and o.peek_name()==n:
            me=o.read(); h=MeshHandler(me); h.process(); V=np.array(h.m_Vertices,np.float32).reshape(-1,3); k=len(V)
            L[n]=dict(V=V,N=np.array(h.m_Normals,np.float32).reshape(k,-1)[:,:3],UV=np.array(h.m_UV0,np.float32).reshape(k,-1)[:,:2],T=[np.array(x,np.int64).reshape(-1,3) for x in h.get_triangles()])
pickle.dump(L,open('/data/inv/ag/lod0.pkl','wb')); print({k:len(v['V']) for k,v in L.items()})
