import pickle,numpy as np,json,os,io,re
from PIL import Image
m=pickle.load(open('/data/inv/w3d/meshes.pkl','rb'))
names=list(m.keys())
o=open('/data/build/w3d_data.h','w')
o.write('// Standoff 2 weapon / knife meshes + skin textures (from the game OBB: DefaultCollection + BuiltInCollections)\n#pragma once\n#include <cstdint>\n')
info=[]
for i,k in enumerate(names):
    V=m[k]['V'];N=m[k]['N'];UV=m[k]['UV'];T=m[k]['T']
    mn=V.min(0);mx=V.max(0);c=(mn+mx)/2;ext=mx-mn;h=ext.max()/2
    P=np.round((V-c)/h*32767).astype(np.int16)
    nn=N/np.maximum(np.linalg.norm(N,axis=1,keepdims=True),1e-6); Nq=np.round(nn*127).astype(np.int8)
    U=np.round(np.clip(UV,0,4)*16383).astype(np.uint16)
    ax=list(np.argsort(-ext))
    for nm,arr,ty in (('P',P,'int16_t'),('N',Nq,'int8_t'),('U',U,'uint16_t'),('I',T.astype(np.uint16),'uint16_t')):
        o.write('static const %s W3D_%s%d[] = {%s};\n'%(ty,nm,i,','.join(map(str,arr.ravel()))))
    info.append((len(V),len(T)*3,ext/ext.max(),ax))
tex=sorted(os.listdir('/data/inv/w3d/tex')); blob=bytearray(); toff=[]
for t in tex:
    im=Image.open('/data/inv/w3d/tex/'+t).convert('RGB')
    if im.width>1024 or im.height>1024: im=im.resize((min(1024,im.width),min(1024,im.height)),Image.LANCZOS)
    b=io.BytesIO(); im.save(b,'JPEG',quality=85); d=b.getvalue(); toff.append((len(blob),len(d))); blob+=d
o.write('struct W3DModel { int nv, ni; const int16_t* pos; const int8_t* nrm; const uint16_t* uv; const uint16_t* idx; float ext[3]; int ax[3]; };\nstatic const W3DModel W3D_MODELS[] = {\n')
for i,(nv,ni,e,ax) in enumerate(info): o.write('  { %d, %d, W3D_P%d, W3D_N%d, W3D_U%d, W3D_I%d, { %.4ff, %.4ff, %.4ff }, { %d, %d, %d } },   // %s\n'%(nv,ni,i,i,i,i,e[0],e[1],e[2],ax[0],ax[1],ax[2],names[i]))
o.write('};\nstruct W3DTex { unsigned int off, size; };\nstatic const W3DTex W3D_TEXS[] = {\n')
for a,b in toff: o.write('  { %d, %d },\n'%(a,b))
o.write('};\n// texture JPEGs: w3d_tex.bin, linked in with .incbin (w3d.cpp)\nextern "C" const unsigned char W3D_TEXBLOB[];\n')
open('/data/build/w3d_tex.bin','wb').write(bytes(blob))
# per model view fix: barrel left / grip down (flip of screen x, y) + roll in degrees (knives tilted like the game icons)
FLIP={'MP7':'-+','Butterfly':'-+','Karambit':'-+','Stiletto':'-+','Kunai':'-+'}
FLIP.update(json.load(open('/data/inv/w3d/flips_extra.json')) if os.path.exists('/data/inv/w3d/flips_extra.json') else {})
ROLL={k:-18 for k in ('Butterfly','M9 Bayonet','Kukri','Tanto','Sting','Fang','Dual Daggers','Stiletto','Kunai','Scorpion','jKommando','Default Knife')}
o.write('const char* W3D_FLIPS = "%s";\n'%','.join(FLIP.get(n,'++') for n in names))
o.write('const float W3D_ROLLS[] = { %s };\nconst int W3D_NROLLS = %d;\n'%(', '.join('%.1ff'%ROLL.get(n,0) for n in names),len(names)))
json.dump(dict(models=names,tex=[t[:-4] for t in tex]),open('/data/inv/w3d/index.json','w'))
print(len(names),len(tex),len(blob))
