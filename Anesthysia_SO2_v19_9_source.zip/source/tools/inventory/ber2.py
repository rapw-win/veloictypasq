import pickle,numpy as np,sys
m=pickle.load(open('w3d/meshes_orig.pkl','rb'))
b=m['Berettas'];V,N,UV,T=b['V'],b['N'],b['UV'],b['T'].reshape(-1,3)
h=len(V)//2
TA=T[(T<h).all(1)]; print(len(T),len(TA)*2)
dx,dy,dz=map(float,sys.argv[1:4])
VA=V[:h]; VB=VA+np.array([dx,dy,dz])
m['Berettas']=dict(V=np.vstack([VA,VB]).astype(np.float32),N=np.vstack([N[:h],N[:h]]),UV=np.vstack([UV[:h],UV[:h]]),T=np.vstack([TA,TA+h]))
pickle.dump(m,open('w3d/meshes.pkl','wb'))
