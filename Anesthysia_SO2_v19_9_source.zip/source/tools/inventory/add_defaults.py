import re
p='/data/build/inv_data.h'; s=open(p).read()
if 'Default Knife' in s.split('INV_BLOB')[0]: raise SystemExit('already')
items=re.findall(r'\{ (\d+), (\d+), "([^"]*)", "([^"]*)", "[^"]*", (\d+), (\d+),',s)
off=max(int(o)+int(z) for *_,o,z in items)
from PIL import Image
add=[];data=b''
for cat,wpn,f in ((1,'Default Knife','/tmp/tk.png'),(2,'Default Gloves','/tmp/tg.png')):
    b=open(f,'rb').read(); w,h=Image.open(f).size
    add.append('  { %d, 0, "%s", "Default", "Default", %d, %d, %d, %d, -1 },\n'%(cat,wpn,off+len(data),len(b),w,h)); data+=b
i=s.index('INV_ITEMS'); e=s.index('\n};',i)
s=s[:e+1]+''.join(add)+s[e+1:]
j=s.index('INV_BLOB'); e2=s.index('\n};',j)
s=s[:e2+1]+''.join(','.join(map(str,data[k:k+40]))+',\n' for k in range(0,len(data),40))+s[e2+1:]
open(p,'w').write(s); print('added',off,len(data))
