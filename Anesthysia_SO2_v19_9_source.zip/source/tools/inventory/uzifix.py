# Akimbo Uzi: split the V-shaped pair into its two guns (welded components, 2-means on centroids), keep one, align it with its principal axes, add a copy behind it
import pickle,numpy as np
m=pickle.load(open('/data/inv/w3d/meshes.pkl','rb')); o=pickle.load(open('/data/inv/w3d/meshes_orig.pkl','rb'))
b=o['Akimbo Uzi'];V,N,UV,T=b['V'],b['N'],b['UV'],b['T'].reshape(-1,3)
p=np.arange(len(V))
def f(x):
    while p[x]!=x: p[x]=p[p[x]]; x=p[x]
    return x
def u(a,c):
    ra,rc=f(a),f(c)
    if ra!=rc: p[ra]=rc
for a,bb,c in T: u(a,bb); u(a,c)
key={}
for i,v in enumerate(np.round(V,4)):
    k=tuple(v)
    if k in key: u(i,key[k])
    else: key[k]=i
r=np.array([f(i) for i in range(len(V))]); comps=np.unique(r)
cen=np.array([V[r==c].mean(0) for c in comps]); w=np.array([(r==c).sum() for c in comps])
# 2-means
c0,c1=cen[w.argmax()],cen[np.argsort(-w)[1]]
for _ in range(20):
    lab=(np.linalg.norm(cen-c1,axis=1)<np.linalg.norm(cen-c0,axis=1))
    c0=np.average(cen[~lab],axis=0,weights=w[~lab]); c1=np.average(cen[lab],axis=0,weights=w[lab])
print(len(comps),w[~lab].sum(),w[lab].sum())
keepc=set(comps[~lab]); keep=np.array([x in keepc for x in r])
idx=np.where(keep)[0]; rm=-np.ones(len(V),np.int64); rm[idx]=np.arange(len(idx))
VA=V[idx]-V[idx].mean(0); NA=N[idx]; TA=rm[T[keep[T].all(1)]]
# principal axes
_,_,Vt=np.linalg.svd(VA-VA.mean(0),full_matrices=False)
R=Vt; 
if np.linalg.det(R)<0: R[2]*=-1
VA=VA@R.T; NA=NA@R.T
# drop parts of the other gun that ended up in this cluster (long parts not parallel to the gun axes)
rk=r[idx]; good=np.ones(len(VA),bool)
for c in np.unique(rk):
    s_=rk==c; P=VA[s_]
    if len(P)<6: continue
    L=np.ptp(P,axis=0).max()
    _,_,vt=np.linalg.svd(P-P.mean(0),full_matrices=False); d0=np.abs(vt[0])
    if L>0.04 and d0.max()<0.93: good[s_]=False
big=max(np.unique(rk),key=lambda c:(rk==c).sum()); B=VA[rk==big]; lo=B.min(0)-0.012; hi=B.max(0)+0.012
for c in np.unique(rk):
    s_=rk==c; cc=VA[s_].mean(0)
    if (cc<lo).any() or (cc>hi).any(): good[s_]=False
gi=np.where(good)[0]; rm2=-np.ones(len(VA),np.int64); rm2[gi]=np.arange(len(gi))
TA=rm2[TA[good[TA].all(1)]]; VA=VA[gi]; NA=NA[gi]; idx=idx[gi]
VA-=(VA.min(0)+VA.max(0))/2
print('dropped',(~good).sum())
ext=VA.max(0)-VA.min(0); print('ext',ext)
d=np.array([0.04*ext[0]/0.3,0.03*ext[0]/0.3,-0.06*ext[0]/0.3])  # copy: up-right and behind (z = thin axis)
VB=VA+d
m['Akimbo Uzi']=dict(V=np.vstack([VA,VB]).astype(np.float32),N=np.vstack([NA,NA]).astype(np.float32),UV=np.vstack([UV[idx],UV[idx]]),T=np.vstack([TA,TA+len(idx)]))
pickle.dump(m,open('/data/inv/w3d/meshes.pkl','wb'))
