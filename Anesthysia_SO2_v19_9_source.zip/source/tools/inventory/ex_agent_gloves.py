# inventory agent: glove skin meshes (third-person "Inspect") + agent body/gloves meshes + glove skin textures -> /data/inv/ag
import UnityPy,numpy as np,pickle,os
from UnityPy.helpers.MeshHelper import MeshHandler
os.chdir('/data/so2/obb/assets/DLC/BuiltInCollections')
def mesh(o):
    me=o.read(); h=MeshHandler(me); h.process()
    V=np.array(h.m_Vertices,np.float32).reshape(-1,3); n=len(V)
    return dict(V=V,N=np.array(h.m_Normals,np.float32).reshape(n,-1)[:,:3],UV=np.array(h.m_UV0,np.float32).reshape(n,-1)[:,:2],
                T=[np.array(x,np.int64).reshape(-1,3) for x in h.get_triangles()])
want={'builtincollections_shared_chameleon_models.bundle':['Classic_G_Inspect'],'builtincollections_shared_wrap_gloves.bundle':['Wrap_G_Inspect'],
      'builtincollections_shared_so2_models.bundle':['CT_Michael_Inspect_Body','CT_Michael_Inspect_Gloves','T_Scrap_Inspect_Body','T_Scrap_Inspect_Gloves']}
M={}
for f,names in want.items():
    for o in UnityPy.load(f).objects:
        if o.type.name=='Mesh' and o.peek_name() in names: M[o.peek_name()]=mesh(o)
pickle.dump(M,open('/data/inv/ag/meshes.pkl','wb'))
for k,v in M.items(): print(k,len(v['V']),[len(t) for t in v['T']],v['V'].min(0).round(3),v['V'].max(0).round(3))
for sk in ['Artificer','DragonGlass','Feral','Flicker','Frond','Marble','Mimicry','Slash','Spray','Stream']:
    for o in UnityPy.load('builtincollections_content_gloves_%s.bundle'%sk.lower()).objects:
        if o.type.name=='Texture2D' and o.peek_name()=='Gloves_%s_D'%sk: o.read().image.convert('RGB').save('/data/inv/ag/%s.png'%sk)
print(sorted(os.listdir('/data/inv/ag')))
