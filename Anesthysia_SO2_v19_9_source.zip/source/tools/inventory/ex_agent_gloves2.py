# bone data (bind poses + name hashes + weights) for the glove meshes -> /data/inv/ag/skin.pkl
import UnityPy,numpy as np,pickle,os
from UnityPy.helpers.MeshHelper import MeshHandler
os.chdir('/data/so2/obb/assets/DLC/BuiltInCollections')
want={'builtincollections_shared_chameleon_models.bundle':['Classic_G_Inspect'],'builtincollections_shared_wrap_gloves.bundle':['Wrap_G_Inspect'],
      'builtincollections_shared_so2_models.bundle':['CT_Michael_Inspect_Gloves','T_Scrap_Inspect_Gloves']}
S={}
for f,names in want.items():
    for o in UnityPy.load(f).objects:
        if o.type.name=='Mesh' and o.peek_name() in names:
            me=o.read(); h=MeshHandler(me); h.process()
            bp=[np.array([[m.e00,m.e01,m.e02,m.e03],[m.e10,m.e11,m.e12,m.e13],[m.e20,m.e21,m.e22,m.e23],[m.e30,m.e31,m.e32,m.e33]]) for m in me.m_BindPose]
            S[o.peek_name()]=dict(bp=np.array(bp),hash=list(me.m_BoneNameHashes),bi=np.array(h.m_BoneIndices).reshape(-1,4),bw=np.array(h.m_BoneWeights,np.float32).reshape(-1,4))
pickle.dump(S,open('/data/inv/ag/skin.pkl','wb'))
for k,v in S.items(): print(k,len(v['bp']),len(v['hash']),v['bi'].shape)
