# adds every weapon / knife skin that exists in the game files but not in INV_ITEMS (T weapons, newer skins); no icon: drawn as 3D
import json,re,pickle,os
nz=lambda x:re.sub('[^a-z0-9]','',x.lower())
P=json.load(open('/data/inv/coll/pages.json'))
RAR={'common':1,'uncommon':2,'rare':3,'epic':4,'legendary':5,'arcane':6,'nameless':7}
cat={}
for t,v in P.items():
    rar=None
    for line in v['text'].split('\n'):
        h=re.match(r'^=+\s*([^=]+?)\s*=+\s*$',line)
        if h:
            k=h.group(1).strip().lower(); rar=RAR.get(k,rar if k not in('skins','knives','gloves','stickers','graffiti','charms') else rar); continue
        for m in re.finditer(r'([A-Za-z0-9/\- ]{2,20}?)\s*["“]([^"”\n]+)["”]',line):
            cat.setdefault((nz(m.group(1)),nz(m.group(2))),(rar,t))
D=pickle.load(open('/data/inv/defs.pkl','rb'))
pretty={};collp={}
for d in D:
    nm=d.get('m_Name','')
    if nm.endswith('_ContentMapping'):
        base=nm[:-15]; pretty[nz(base)]=base
        for mp in d.get('Mappings',[]):
            mm=re.search(r'Bundles/([A-Za-z0-9]+?)Collection/',mp['Path'])
            if mm: collp[nz(base)]=re.sub(r'(?<=[a-z])(?=[A-Z0-9])',' ',mm.group(1))+' Collection'
def camel(s): return re.sub(r'(?<=[a-z])(?=[A-Z])|(?<=[A-Za-z])(?=[0-9])|(?<=[0-9])(?=[A-Z][a-z])',' ',s).strip()
idx=json.load(open('/data/inv/w3d/index.json')); models=idx['models']; mk={nz(n):n for n in models}
s=open('/data/build/inv_data.h').read()
items=re.findall(r'\{ (\d+), (\d+), "([^"]*)", "([^"]*)", "([^"]*)", \d+, \d+, \d+, \d+, (-?\d+) \}',s.split('INV_BLOB')[0])
have={(nz(w),nz(sk)) for c,r,w,sk,co,ci in items}
collci={}
for c,r,w,sk,co,ci in items: collci.setdefault(co,int(ci))
KN={'Butterfly','M9 Bayonet','Karambit','Kukri','Mantis','Tanto','Sting','Fang','Dual Daggers','Stiletto','Kunai','Scorpion','jKommando','Flip'}
WK={'deserteagle':['deagle','deserteagle'],'fs':['fiveseven'],'fnfal':['fnfal','fnfal'],'tec9':['tec9'],'m9bayonet':['m9bayonet','knifem9bayonet']}
add=[]
for t in idx['tex']:
    key,sk=t.split('__')
    if sk=='default' or key not in mk: continue
    w=mk[key]
    if (key,sk) in have: continue
    if (key,sk) in (('deserteagle','captainmorgan'),('awm','hoheitaisho')): continue
    # pretty skin name from the game definitions
    nm=None
    for pre in [key]+WK.get(key,[])+[nz(w)]:
        for k2,v2 in pretty.items():
            if k2==pre+sk or k2=='knife'+pre+sk: nm=v2.split('_',1)[-1]; break
        if nm: break
    skin=camel(nm) if nm else sk.title()
    rar,col=cat.get((key,sk),(None,None))
    if rar is None:
        for (a,b),v in cat.items():
            if b==sk and (a==key or a in WK.get(key,[]) or a.endswith(key)): rar,col=v; break
    if col is None: col=collp.get(key+sk) or next((v for k2,v in collp.items() if k2.endswith(sk) and key[:3] in k2),'Standoff 2')
    if rar is None: rar=3
    c=1 if w in KN else 0
    if (key,sk) in (('usp','test0'),('usp','test1'),('p90','tester')): continue
    ci=collci.get(col,0)
    add.append('  { %d, %d, "%s", "%s", "%s", 0, 0, 0, 0, %d },\n'%(c,rar,w,skin,col,ci))
for w in ('G22','Tec-9','MAC10','Akimbo Uzi','SPAS','AKR','AKR12','FN FAL','VAL'):
    if (nz(w),'default') not in have: add.insert(0,'  { 0, 0, "%s", "Default", "Default", 0, 0, 0, 0, 0 },\n'%w)
i=s.index('INV_ITEMS'); e=s.index('\n};',i)
s=s[:e+1]+''.join(add)+s[e+1:]
open('/data/build/inv_data.h','w').write(s)
print(len(add)); print(''.join(add[:40]))
