import json,re
W=json.load(open('colls.json'))
imgs={x['name'].replace(' ','_').lower():x for x in json.load(open('allimages.json'))}
RAR=['common','uncommon','rare','epic','legendary','arcane','nameless']
WEAP={'g22':'G22','usp':'USP','p350':'P350','desert eagle':'Desert Eagle','deagle':'Desert Eagle','tec-9':'TEC-9','tec9':'TEC-9','f/s':'F/S','fiveseven':'F/S','five-seven':'F/S','berettas':'Berettas',
 'ump45':'UMP45','ump-45':'UMP45','mp7':'MP7','mp5':'MP5','p90':'P90','akimbo uzi':'Akimbo Uzi','mac10':'MAC10','mac-10':'MAC10','spas':'SPAS','spas-12':'SPAS','fabm':'FabM','sm1014':'SM1014','m60':'M60',
 'akr':'AKR','akr12':'AKR12','m4':'M4','m4a1':'M4A1','m16':'M16','famas':'FAMAS','val':'VAL','fn fal':'FN FAL','fnfal':'FN FAL','awm':'AWM','m40':'M40','m110':'M110'}
out=[];bad=[]
for coll,t in W.items():
    rar=None; kind='weapon'
    lines=t.split('\n'); last=''
    for i,l in enumerate(lines):
        m=re.match(r'^\s*=+\s*(.*?)\s*=+\s*$',l)
        if m:
            h=m.group(1).lower()
            r=[x for x in RAR if x==h or h.startswith(x)]
            if r: rar=r[0]; kind='weapon'
            elif h in('skins','case content','box content'): rar=None if h!='skins' else rar
            else: rar=h; kind='special'
            last=''; continue
        for fm in re.finditer(r'\[\[File:([^|\]]+)',l):
            fn=fm.group(1).strip()
            if rar is None: continue
            if 'proof' in fn.lower() or 'code' in fn.lower() or fn.lower().endswith('.gif') or 'old' in fn.lower(): continue
            cap=last.strip()
            mm=re.match(r'^(.*?)\s*["“”«]+(.+?)["“”»]+',cap)
            if mm:
                w=mm.group(1).strip(" *'\t"); s=mm.group(2).strip()
            else:
                base=re.sub(r'\.(png|jpg|jpeg)$','',fn,flags=re.I).replace('_',' ').strip()
                k=[x for x in sorted(WEAP,key=len,reverse=True) if base.lower().startswith(x+' ')]
                if not k: bad.append((coll,cap,fn)); continue
                w=k[0]; s=base[len(k[0]):].strip()
                s=re.sub(r'\b(4Y|4 years)\b','4 Years',s)
            key=fn.replace(' ','_').lower()
            if key not in imgs: bad.append((coll,cap,fn,'noimg')); continue
            out.append(dict(coll=coll.replace('Colllection','Collection'),rarity=rar,weapon=WEAP.get(w.lower().replace('akr 12','akr12').replace('akr-12','akr12'),w),skin=s,file=imgs[key]['name'],url=imgs[key]['url'],w=imgs[key]['width'],h=imgs[key]['height']))
        if l.strip() and not l.strip().startswith('[[') : last=l
seen=set();o2=[]
for o in out:
    k=(o['weapon'].lower(),o['skin'].lower())
    if k in seen: continue
    seen.add(k);o2.append(o)
out=o2
json.dump(out,open('skins.json','w'),indent=0)
import collections
print(len(out),len(bad))
print(collections.Counter(o['weapon'] for o in out).most_common())
print(collections.Counter(o['rarity'] for o in out).most_common())
for b in bad[:25]: print(b)
