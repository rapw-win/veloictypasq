import pickle,numpy as np
m=pickle.load(open('w3d/meshes.pkl','rb'))
b=m['Berettas'];V,T=b['V'],b['T'].reshape(-1,3)
p=np.arange(len(V))
def f(x):
    while p[x]!=x: p[x]=p[p[x]]; x=p[x]
    return x
for a,bb,c in T:
    for u,v in ((a,bb),(a,c)):
        ru,rv=f(u),f(v)
        if ru!=rv: p[ru]=rv
# also merge identical positions
r=np.array([f(i) for i in range(len(V))])
comps=np.unique(r); print(len(V),len(comps))
cen=np.array([V[r==c].mean(0) for c in comps]); sz=np.array([(r==c).sum() for c in comps])
print(V.min(0),V.max(0))
for c,s in sorted(zip(cen.round(3).tolist(),sz),key=lambda x:-x[1])[:20]: print(c,s)
# weld by position
key={};
for i,v in enumerate(np.round(V,4)):
    k=tuple(v)
    if k in key:
        ru,rv=f(i),f(key[k])
        if ru!=rv: p[ru]=rv
    else: key[k]=i
r=np.array([f(i) for i in range(len(V))]); comps=np.unique(r); print('welded',len(comps))
for c in comps:
    s=(r==c); print(s.sum(), V[s].mean(0).round(3), V[s].min(0).round(3), V[s].max(0).round(3))
