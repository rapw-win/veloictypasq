# default gloves: both CT hands from the game, fingers up, side by side (like the glove skin icons) -> appended to meshes.pkl
import pickle,numpy as np,sys
g=pickle.load(open('/data/inv/w3d/gloves.pkl','rb'))['CT_FP_Gloves']
V,N,UV,T=g['V'],g['N'],g['UV'],g['T']
gap=float(sys.argv[1]) if len(sys.argv)>1 else 0.11
VV=[];NN=[];UU=[];TT=[];off=0
for side in (1,-1):
    keep=(V[:,0]*side)>0; idx=np.where(keep)[0]; rm=-np.ones(len(V),np.int64); rm[idx]=np.arange(len(idx))
    v=V[idx].copy(); n=N[idx].copy(); v-=(v.min(0)+v.max(0))/2
    v[:,0]+=side*gap/2
    VV.append(v);NN.append(n);UU.append(UV[idx]);TT.append(rm[T[keep[T].all(1)]]+off);off+=len(v)
m=pickle.load(open('/data/inv/w3d/meshes.pkl','rb'))
m['Default Gloves']=dict(V=np.vstack(VV).astype(np.float32),N=np.vstack(NN).astype(np.float32),UV=np.vstack(UU).astype(np.float32),T=np.vstack(TT))
pickle.dump(m,open('/data/inv/w3d/meshes.pkl','wb'))
print(np.vstack(VV).min(0),np.vstack(VV).max(0))
