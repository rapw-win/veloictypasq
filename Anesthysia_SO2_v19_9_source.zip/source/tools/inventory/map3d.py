import re,json
s=open('/data/build/inv_data.h').read()
d=json.load(open('w3d/index.json'));tex=d['tex'];models=[re.sub('[^a-z0-9]','',n.lower()) for n in d['models']]
nz=lambda x:re.sub('[^a-z0-9]','',x.lower())
items=re.findall(r'\{ (\d+), (\d+), "([^"]*)", "([^"]*)",',s.split('INV_ITEMS')[1])
used=set();res=[];miss={}
for c,r,w,sk in items:
    mk=nz(w); 
    if c=='1' and w in('Default','Knife','Default Knife'): mk='defaultknife'
    m=models.index(mk) if mk in models else -1
    t=-1
    if m>=0:
        al={'honeitaisho':'hoheitaisho','cmorgan':'captainmorgan'}
        cand=mk+'__'+al.get(nz(sk),nz(sk))
        if sk=='Default' or nz(sk)in('default',''): cand=mk+'__default'
        if cand in tex: t=tex.index(cand); used.add(cand)
        else: miss.setdefault(w,[]).append(sk)
    res.append((m,t))
print(len(items),sum(1 for m,t in res if m>=0),sum(1 for m,t in res if t>=0))
print(sorted(set(nz(i[2]) for i in items if nz(i[2]) not in models)))
for w in miss: print(w,'MISS',miss[w])
print('UNUSED',[t for t in tex if t not in used])
json.dump(res,open('w3d/map.json','w'))
