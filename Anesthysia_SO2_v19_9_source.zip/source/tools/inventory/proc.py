import json,os,sys,glob,re
import numpy as np
from PIL import Image
from rembg import new_session, remove
from scipy import ndimage
it=json.load(open('items.json'))
part=int(sys.argv[1]); nparts=int(sys.argv[2])
sess=new_session('isnet-general-use')
ocr=None
meta={}
mp='proc/meta_%d_%d.json'%(part,nparts)
if os.path.exists(mp): meta=json.load(open(mp))
allm={}
for f in glob.glob('proc/meta_*.json'): allm.update(json.load(open(f)))
for x in it[part::nparts]:
    out='proc/%d.png'%x['id']
    if os.path.exists(out) and (str(x['id']) in meta or str(x['id']) in allm): continue
    f=glob.glob('raw/%d.*'%x['id'])[0]
    try: im=Image.open(f).convert('RGB')
    except Exception as e: print('bad',f,e); continue
    w,h=im.size; m={}
    shot = x['cat']!='medal' and x['cat']!='default' and w/h>1.5
    if shot:
        if ocr is None:
            from rapidocr_onnxruntime import RapidOCR; ocr=RapidOCR()
        t=im.crop((0,0,int(w*0.55),int(h*0.15)))
        t.save('/tmp/o%d.png'%part); r,_=ocr('/tmp/o%d.png'%part)
        m['ocr']=[q[1] for q in r] if r else []
        c=im.crop((int(w*0.06),int(h*0.15),int(w*0.94),int(h*0.87)))
    elif x['cat']=='default':
        a=np.asarray(im).astype(float).mean(axis=2).mean(axis=1)
        y1=int(h*0.5)
        for y in range(int(h*0.08),int(h*0.5)):
            if a[y]>150: y1=y; break
        c=im.crop((0,0,w,y1))
    else: c=im
    if max(c.size)>900: c=c.resize((900,int(900*c.size[1]/c.size[0])) if c.size[0]>=c.size[1] else (int(900*c.size[0]/c.size[1]),900),Image.LANCZOS)
    o=remove(c,session=sess)
    al=np.asarray(o)[:,:,3]
    lab,n=ndimage.label(al>40)
    if n>0:
        sz=ndimage.sum(np.ones_like(al),lab,range(1,n+1)); keep=[i+1 for i,s in enumerate(sz) if s>=0.06*sz.max()]
        mask=np.isin(lab,keep); mask=ndimage.binary_dilation(mask,iterations=2)
        arr=np.asarray(o).copy(); arr[:,:,3]=np.where(mask,arr[:,:,3],0); o=Image.fromarray(arr)
    bb=o.getbbox()
    if bb: o=o.crop(bb)
    o.save(out); meta[str(x['id'])]=m
    json.dump(meta,open(mp,'w'))
print('done',part)
