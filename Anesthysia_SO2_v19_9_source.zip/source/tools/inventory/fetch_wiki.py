# standoff-2.fandom.com collection pages (wikitext + page image) -> coll/pages.json
import json,urllib.request,urllib.parse
API='https://standoff-2.fandom.com/api.php?'
def q(**k):
    k['format']='json'; return json.load(urllib.request.urlopen(urllib.request.Request(API+urllib.parse.urlencode(k),headers={'User-Agent':'Mozilla/5.0'}),timeout=60))
T=[];c=None
while True:
    a=dict(action='query',list='allpages',aplimit=500)
    if c: a['apcontinue']=c
    d=q(**a); T+=[p['title'] for p in d['query']['allpages']]; c=d.get('continue',{}).get('apcontinue')
    if not c: break
json.dump(T,open('/data/inv/coll/titles.json','w'))
cols=[t for t in T if 'ollection' in t or 'Medal' in t or t=='Gift Box']
out={}
for i in range(0,len(cols),20):
    d=q(action='query',prop='revisions|pageimages',rvprop='content',rvslots='main',piprop='original',titles='|'.join(cols[i:i+20]))
    for p in d['query']['pages'].values():
        out[p['title']]=dict(text=p['revisions'][0]['slots']['main']['*'] if 'revisions' in p else '',img=p.get('original',{}).get('source'))
json.dump(out,open('/data/inv/coll/pages.json','w')); print(len(out))
