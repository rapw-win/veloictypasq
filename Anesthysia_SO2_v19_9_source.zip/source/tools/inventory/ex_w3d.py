import UnityPy,pickle,numpy as np,os,re,json
from UnityPy.helpers.MeshHelper import MeshHandler
env=UnityPy.load('so2/obb/assets/CustomDLC/DefaultCollection/defaultcollection_content_mesh.bundle')
L={}
for o in env.objects:
    if o.type.name=='MonoBehaviour':
        try: d=o.read_typetree()
        except Exception: continue
        if 'm_Name' in d and '<Mono>k__BackingField' in d: L[d['m_Name']]=d['<Mono>k__BackingField']['m_PathID']
M={'USP':('USP','USP_D',['usp']),'P350':('P350','P350_D',['p350']),'F/S':('FiveSeven','FiveSeven_D',['fiveseven']),'Berettas':('Berettas','Berettas_D',['berettas']),
 'Desert Eagle':('Deagle','Deagle_D',['deagle','deserteagle']),'MP7':('MP7','MP7_D',['mp7']),'P90':('P90','P90_D',['p90']),'UMP45':('UMP45','UMP45_D',['ump45']),
 'MP5':('MP5','MP5_D',['mp5']),'SM1014':('SM1014','M1014_D',['sm1014']),'FAMAS':('FAMAS','Famas_d',['famas']),'M4':('M4','M4_D',['m4']),'M4A1':('M4A1','M4A1_D',['m4a1']),
 'M16':('M16','M16_D',['m16']),'AWM':('AWM','AWMF_DS',['awm']),
 'Butterfly':('KnifeButterfly','KnifeButterfly_D',['butterfly']),'M9 Bayonet':('KnifeBayonet','m9_D',['m9bayonet']),'Karambit':('KnifeKarambit','Karambit_D',['karambit']),
 'Kukri':('KnifeKukri','Kukri_D',['kukri']),'Mantis':('KnifeMantis','Mantis_D',['knifemantis']),'Tanto':('KnifeTanto','Tanto_D',['knifetanto']),'Sting':('KnifeSting','Sting_D',['knifesting']),
 'Fang':('KnifeFang','Fang_D',['fang']),'Dual Daggers':('DaggerKnife','Dagger_D',['daggerknife']),'Stiletto':('KnifeStilet','Stilet_D',['knifestilet','stiletto']),
 'Kunai':('KunaiKnife','Kunai_D',['knifekunai','kunai']),'Scorpion':('ScorpionKnife','Scorpion_D',['scorpion','knifescorpion']),'jKommando':('jKommando','jagdkommando_Albedo',['jkommando']),
 'Flip':('FlipKnife','',['flipknife','flip']),'Default Knife':('Knife','ka_bar_D',[])}
byid={o.path_id:o for o in env.objects}
meshes={}
for k,(m,t,_) in M.items():
    for lod in (0,1):
        pid=L.get('%s_LOD_%d'%(m,lod))
        if not pid or pid not in byid: continue
        me=byid[pid].read(); h=MeshHandler(me); h.process()
        V=np.array(h.m_Vertices,np.float32).reshape(-1,3); n=len(V)
        N=np.array(h.m_Normals,np.float32).reshape(n,-1)[:,:3] if h.m_Normals else np.zeros((n,3),np.float32)
        UV=np.array(h.m_UV0,np.float32).reshape(n,-1)[:,:2]
        tris=np.concatenate([np.array(x,np.int64).reshape(-1,3) for x in h.get_triangles()])
        if len(tris)<14000 or lod==1: meshes[k]=dict(V=V,N=N,UV=UV,T=tris); break
pickle.dump(meshes,open('/data/inv/w3d/meshes.pkl','wb'))
envm=UnityPy.load('so2/obb/assets/CustomDLC/DefaultCollection/defaultcollection_content_materials.bundle')
for o in envm.objects:
    if o.type.name=='Texture2D':
        nm=o.peek_name()
        for k,(m,t,_) in M.items():
            fn='/data/inv/w3d/tex/%s__default.jpg'%re.sub('[^a-z0-9]','',k.lower())
            if t and nm==t and not os.path.exists(fn): o.read().image.convert('RGB').resize((512,512)).save(fn,quality=85)
D='so2/obb/assets/DLC/BuiltInCollections/'
idx={}
for f in sorted(os.listdir(D)):
    if not f.startswith('builtincollections_content_'): continue
    key=f[len('builtincollections_content_'):-7]
    for k,(m,t,pres) in M.items():
        for p in pres:
            if key.startswith(p+'_'):
                skin=key[len(p)+1:]; kk=re.sub('[^a-z0-9]','',k.lower())
                out='/data/inv/w3d/tex/%s__%s.jpg'%(kk,skin)
                if not os.path.exists(out):
                    e=UnityPy.load(D+f); tx=[o for o in e.objects if o.type.name=='Texture2D' and o.peek_name().endswith('_D')] or [o for o in e.objects if o.type.name=='Texture2D' and o.peek_name().endswith('_A')]
                    if not tx: continue
                    tx[0].read().image.convert('RGB').resize((512,512)).save(out,quality=85)
                idx.setdefault(k,[]).append(skin)
json.dump(idx,open('/data/inv/w3d/skins.json','w'))
print(len(meshes),{k:len(v) for k,v in idx.items()})
