import json,os,re,io,glob
from PIL import Image
it=json.load(open('items.json'))
meta={}
for f in glob.glob('proc/meta_*.json'): meta.update(json.load(open(f)))
RAR=['common','uncommon','rare','epic','legendary','arcane','nameless']
out=[];blob=bytearray()
for x in it:
    p='proc/%d.png'%x['id']
    if not os.path.exists(p): continue
    im=Image.open(p).convert('RGBA')
    cat=x['cat']
    if cat=='medal':
        import numpy as np
        from scipy import ndimage
        al=np.asarray(im)[:,:,3]>40
        lab,n=ndimage.label(ndimage.binary_dilation(al,iterations=3))
        if n>1:
            sz=ndimage.sum(np.ones_like(al),lab,range(1,n+1)); big=int(np.argmax(sz))+1
            ys,xs=np.where(lab==big); im=im.crop((xs.min(),ys.min(),xs.max()+1,ys.max()+1))
    ocr=[s.upper() for s in meta.get(str(x['id']),{}).get('ocr',[])]
    r=(x.get('rarity') or '').lower()
    if r not in RAR:
        r=''
        for s in ocr:
            for k in RAR[::-1]:
                if k.upper() in s.replace(' ',''): r=k;break
            if r: break
    if not r:
        r={'knife':'arcane','gloves':'arcane','default':'default','medal':'legendary','graffiti':'uncommon'}.get(cat,'rare')
    coll=x.get('coll') or ''
    if not coll and ocr:
        j=[i for i,s in enumerate(ocr) if any(k.upper() in s for k in RAR)]
        if j: coll=' '.join(s.title() for s in ocr[j[0]+1:]).strip()
    if cat=='medal' and coll and 'Collection' not in coll: coll=coll+' Medals'
    if coll and not coll.endswith('Collection') and cat not in('medal',): coll=coll if 'Collection' in coll else coll+' Collection'
    if cat=='default': coll='Default'
    if cat in('knife',) and im.height>im.width*1.4: im=im.rotate(90,expand=True)
    # thumbnails
    mw,mh=(320,150) if cat in('weapon','default','knife') else ((220,150) if cat=='gloves' else (150,150))
    s=min(mw/im.width,mh/im.height,1.0)
    im=im.resize((max(1,round(im.width*s)),max(1,round(im.height*s))),Image.LANCZOS)
    q=im.quantize(256,method=Image.Quantize.FASTOCTREE,dither=Image.Dither.NONE)
    b=io.BytesIO(); q.save(b,'PNG',optimize=True); d=b.getvalue()
    skin=x['skin']
    if cat=='default': skin='Default'
    out.append(dict(cat=cat,weapon=x['weapon'],skin=skin,coll=coll,rar=r,off=len(blob),size=len(d),w=im.width,h=im.height))
    blob+=d
CATS={'weapon':0,'default':0,'knife':1,'gloves':2,'medal':3,'graffiti':4,'charm':5}
RI={'default':0,'common':1,'uncommon':2,'rare':3,'epic':4,'legendary':5,'arcane':6,'nameless':7}
import urllib.request,hashlib
UA={'User-Agent':'Mozilla/5.0'}
cimg=json.load(open('coll_img.json'))
def norm(c): return c.lower().replace('colllection','collection').replace(' collection','').replace('collection','').strip()
cmap={norm(k):v for k,v in cimg.items() if v}
clist=[];cidx={};cblob=bytearray()
for e in out:
    n=norm(e['coll']) if e['coll'] else ''
    u=cmap.get(n)
    if not u: e['ci']=-1; continue
    if n not in cidx:
        f='coll/'+hashlib.md5(u.encode()).hexdigest()+'.img'
        if not os.path.exists(f): open(f,'wb').write(urllib.request.urlopen(urllib.request.Request(u,headers=UA),timeout=30).read())
        im=Image.open(f); im.seek(0); im=im.convert('RGBA'); w,h=im.size; m=min(w,h)
        im=im.crop(((w-m)//2,(h-m)//2,(w-m)//2+m,(h-m)//2+m)).resize((72,72),Image.LANCZOS)
        b=io.BytesIO(); im.convert('RGB').save(b,'PNG',optimize=True); d=b.getvalue()
        cidx[n]=len(clist); clist.append((off:=len(cblob),len(d))); cblob+=d
    e['ci']=cidx[n]
out.sort(key=lambda e:(CATS[e['cat']],e['weapon'],e['cat']!='default',-RI[e['rar']],e['skin']))
def cs(s): return '"'+s.replace('\\','\\\\').replace('"','\\"')+'"'
with open('/data/build/inv_data.h','w') as f:
    f.write('// Standoff 2 inventory items (images: standoff-2.fandom.com)\n#pragma once\nstruct InvItem { unsigned char cat; unsigned char rar; const char* weapon; const char* skin; const char* coll; unsigned int off, size; unsigned short w, h; short ci; };\n')
    f.write('static const InvItem INV_ITEMS[] = {\n')
    for e in out: f.write('  { %d, %d, %s, %s, %s, %d, %d, %d, %d, %d },\n'%(CATS[e['cat']],RI[e['rar']],cs(e['weapon']),cs(e['skin']),cs(e['coll']),e['off'],e['size'],e['w'],e['h'],e['ci']))
    f.write('};\nstatic const unsigned char INV_BLOB[] = {\n')
    for i in range(0,len(blob),40): f.write(','.join(str(c) for c in blob[i:i+40])+',\n')
    f.write('};\nstruct InvColl { unsigned int off, size; };\nstatic const InvColl INV_COLLS[] = {\n')
    for o,z in clist: f.write('  { %d, %d },\n'%(o,z))
    f.write('};\nstatic const unsigned char INV_CBLOB[] = {\n')
    for i in range(0,len(cblob),40): f.write(','.join(str(c) for c in cblob[i:i+40])+',\n')
    f.write('};\n')
print(len(out),len(blob))
import collections;print(collections.Counter(e['rar'] for e in out))
