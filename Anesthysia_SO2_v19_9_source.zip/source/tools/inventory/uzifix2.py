# Akimbo Uzi: the game mesh holds two identical guns in a V. Pair up identical parts (same UVs), find the rigid transform gun B -> gun A
# from the biggest part, keep gun A, align it with its principal axes and put a copy right behind it.
import pickle,numpy as np
m=pickle.load(open('/data/inv/w3d/meshes.pkl','rb')); o=pickle.load(open('/data/inv/w3d/meshes_orig.pkl','rb'))
b=o['Akimbo Uzi'];V,N,UV,T=b['V'],b['N'],b['UV'],b['T'].reshape(-1,3)
p=np.arange(len(V))
def f(x):
    while p[x]!=x: p[x]=p[p[x]]; x=p[x]
    return x
for a,bb,c in T:
    for u in (bb,c):
        ra,rc=f(a),f(u)
        if ra!=rc: p[ra]=rc
r=np.array([f(i) for i in range(len(V))]); comps=list(np.unique(r))
sig={}
for c in comps:
    ii=np.where(r==c)[0]; k=(len(ii),tuple(np.round(UV[ii[:4]].ravel(),4)))
    sig.setdefault(k,[]).append(ii)
pairs=[v for v in sig.values() if len(v)==2]; single=[v for v in sig.values() if len(v)!=2]
print(len(comps),'pairs',len(pairs),'unpaired',sum(len(v) for v in single))
pairs.sort(key=lambda v:-len(v[0]))
def kabsch(P,Q):
    pc,qc=P.mean(0),Q.mean(0); H=(P-pc).T@(Q-qc); U,S,Wt=np.linalg.svd(H); d=np.sign(np.linalg.det(Wt.T@U.T))
    R=Wt.T@np.diag([1,1,d])@U.T; return R,qc-R@pc
X,Y=pairs[0]; R,t=kabsch(V[X],V[Y])   # Y = R X + t  (X in gun A)
A=[];
for X,Y in pairs:
    e1=np.abs(V[X]@R.T+t-V[Y]).max(); e2=np.abs(V[Y]@R.T+t-V[X]).max()
    A.append(X if e1<=e2 else Y)
keep=np.zeros(len(V),bool)
for ii in A: keep[ii]=True
idx=np.where(keep)[0]; rm=-np.ones(len(V),np.int64); rm[idx]=np.arange(len(idx))
VA=V[idx]-V[idx].mean(0); NA=N[idx]; TA=rm[T[keep[T].all(1)]]
_,_,Rt=np.linalg.svd(VA,full_matrices=False)
if np.linalg.det(Rt)<0: Rt[2]*=-1
VA=VA@Rt.T; NA=NA@Rt.T; VA-=(VA.min(0)+VA.max(0))/2
ext=np.ptp(VA,axis=0); print('ext',ext)
d=np.array([0.10,0.07,-0.6])*ext[[0,0,2]]*np.array([1,1,1])
VB=VA+np.array([0.08*ext[0],0.06*ext[0],-0.9*ext[2]])
m['Akimbo Uzi']=dict(V=np.vstack([VA,VB]).astype(np.float32),N=np.vstack([NA,NA]).astype(np.float32),UV=np.vstack([UV[idx],UV[idx]]),T=np.vstack([TA,TA+len(idx)]))
pickle.dump(m,open('/data/inv/w3d/meshes.pkl','wb'))
