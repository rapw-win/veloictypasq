# collection name + logo for every inventory item (standoff-2.fandom.com collection pages); rewrites coll / ci and INV_COLLS / INV_CBLOB in inv_data.h
import json,re,difflib,urllib.request,urllib.parse,os,io,hashlib
from PIL import Image
os.chdir('/data/inv/coll')
P=json.load(open('pages.json'))
nz=lambda x:re.sub('[^a-z0-9]','',x.lower())
cap={};byw={}
for t,v in P.items():
    for m in re.finditer(r'^\s*([^\n\[\]="|]{1,40}?)\s*["“”«]([^"\n“”»]+)["“”»]',v['text'],re.M):
        a,b=nz(m.group(1)),nz(m.group(2))
        cap.setdefault((a,b),t); cap.setdefault(('*',b),t); byw.setdefault(a,{}).setdefault(b,t)
titles=list(P)
def page_for(name):
    n=nz(name.replace('Colllection','Collection'))
    for t in titles:
        if nz(t)==n: return t
    for t in titles:
        if nz(t)==n+'collection' or nz(t)+'collection'==n: return t
    m=difflib.get_close_matches(n,[nz(t) for t in titles],1,0.8)
    return titles[[nz(t) for t in titles].index(m[0])] if m else None
KW=[(nz(t.replace(' Collection','').replace(' Medals','')),t) for t in titles]
KW+= [('4y','4 Years Collection'),('so2','SO2 Collection'),('hotwinterparty','Hot Winter Party Medals'),('frostychaous','Frosty Chaos Collection')]
KW.sort(key=lambda x:-len(x[0]))
s=open('/data/build/inv_data.h').read()
head,rest=s.split('static const InvItem INV_ITEMS[] = {\n',1)
body,tail=rest.split('\n};',1)
lines=body.split('\n')
WN={'4':'graffiti','5':'charm','2':'gloves','3':'medal'}
res=[];stat={}
for L in lines:
    m=re.match(r'  \{ (\d+), (\d+), "([^"]*)", "([^"]*)", "([^"]*)", (\d+), (\d+), (\d+), (\d+), (-?\d+) \},',L)
    c,r,w,sk,co=m.group(1),m.group(2),m.group(3),m.group(4),m.group(5)
    page=None; how=''
    if r=='0': page='__so2'; how='stock'
    elif co and co!='Default': page=page_for(co); how='name'
    if not page:
        w2=nz(WN.get(c,w)); k=nz(sk)
        page=cap.get((w2,k)) or cap.get(('*',k)); how='caption'
        if not page and w2 in byw:
            mm=difflib.get_close_matches(k,list(byw[w2]),1,0.75)
            if mm: page=byw[w2][mm[0]]; how='fuzzy'
        if not page:
            for kw,t in KW:
                if kw and len(kw)>=3 and kw in k: page=t; how='keyword'; break
    if not page: page='__so2'; how='fallback'
    stat[how]=stat.get(how,0)+1
    res.append((m,page))
print(stat)
# logo per page
def logo_url(t):
    if t=='__so2': return None
    v=P[t]; files=re.findall(r'\[\[File:([^|\]]+)',v['text'])
    lg=[f for f in files if re.search('logo',f,re.I)]
    if t.endswith(' Medals'):
        base=t.replace(' Medals',' Collection'); bp=page_for(base)
        if bp and bp!=t: return logo_url(bp)
    if lg: return ('file',lg[0].strip())
    if t=='Nameless Collection': return None
    if t=='Halloween Collection 2020': return ('file','Halloween_Collection_2020_PUB.jpg')
    return ('url',v['img']) if v['img'] else None
API='https://standoff-2.fandom.com/api.php?'
def fetch(u):
    fn='img_'+hashlib.md5(u.encode()).hexdigest()
    if not os.path.exists(fn):
        open(fn,'wb').write(urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0'}),timeout=60).read())
    return open(fn,'rb').read()
def file_url(f):
    d=json.load(urllib.request.urlopen(urllib.request.Request(API+urllib.parse.urlencode(dict(action='query',titles='File:'+f,prop='imageinfo',iiprop='url',format='json')),headers={'User-Agent':'Mozilla/5.0'}),timeout=60))
    for p in d['query']['pages'].values():
        if 'imageinfo' in p: return p['imageinfo'][0]['url']
SO2='__so2'
urls={}
for m,page in res:
    if page in urls: continue
    lu=logo_url(page) if page!=SO2 else None
    if page!=SO2 and lu is None: page2=SO2
    u=None
    if lu: u=lu[1] if lu[0]=='url' else file_url(lu[1])
    urls[page]=u
# Standoff 2 logo (wiki wordmark / site logo) as the fallback
so2=None
for f in ('Site-logo.png','Wiki-wordmark.png','Standoff 2 Logo.png','Standoff2 logo.png','SO2 Collection.jpg'):
    try: so2=file_url(f)
    except Exception: so2=None
    if so2: print('so2 logo',f); break
urls[SO2]=so2
for k,u in list(urls.items()):
    if u is None: urls[k]=so2
order=[];blob=bytearray();offs=[];idx={}
for k,u in urls.items():
    if u in idx: continue
    im=Image.open(io.BytesIO(fetch(u))).convert('RGBA')
    w,h=im.size
    if max(w,h)/min(w,h)>1.25:   # wide wordmark / screenshot: fit on a dark plate instead of cropping
        im.thumbnail((64,64),Image.LANCZOS); bg=Image.new('RGBA',(72,72),(22,24,32,255)); bg.alpha_composite(im,((72-im.width)//2,(72-im.height)//2)); im=bg
    else:
        sq=min(w,h); im=im.crop(((w-sq)//2,(h-sq)//2,(w-sq)//2+sq,(h-sq)//2+sq)).resize((72,72),Image.LANCZOS)
    if im.getextrema()[3][0]<255:   # transparent logo -> dark plate
        bg=Image.new('RGBA',(72,72),(22,24,32,255)); bg.alpha_composite(im); im=bg
    b=io.BytesIO(); im.convert('RGB').save(b,'PNG',optimize=True); d=b.getvalue()
    idx[u]=len(offs); offs.append((len(blob),len(d))); blob+=d
out=[]
for m,page in res:
    g=list(m.groups()); co=g[4]
    if page!=SO2: co=page.replace('Colllection','Collection')
    elif g[1]!='0' and not co: co='Standoff 2'
    ci=idx[urls[page]]
    out.append('  { %s, %s, "%s", "%s", "%s", %s, %s, %s, %s, %d },'%(g[0],g[1],g[2],g[3],co,g[5],g[6],g[7],g[8],ci))
s2=head+'static const InvItem INV_ITEMS[] = {\n'+'\n'.join(out)+'\n};'+tail
a=s2.index('static const InvColl INV_COLLS[] = {'); b=s2.index('};',s2.index('INV_CBLOB'))+2
s2=s2[:a]+'static const InvColl INV_COLLS[] = {\n'+''.join('  { %d, %d },\n'%o for o in offs)+'};\nstatic const unsigned char INV_CBLOB[] = {\n'+''.join(','.join(map(str,blob[i:i+40]))+',\n' for i in range(0,len(blob),40))+'};'+s2[b:]
open('/data/build/inv_data.h','w').write(s2)
print(len(offs),'logos',len(blob))
