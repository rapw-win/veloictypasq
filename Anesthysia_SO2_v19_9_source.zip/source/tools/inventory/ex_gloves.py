# default gloves: CT first-person gloves mesh + texture from the game -> w3d/gloves.pkl (used by gloves_pair.py)
import UnityPy,numpy as np,pickle
from UnityPy.helpers.MeshHelper import MeshHandler
e=UnityPy.load('/data/so2/obb/assets/DLC/BuiltInCollections/builtincollections_shared_agents_generic_fp.bundle')
out={}
for o in e.objects:
    if o.type.name=='Mesh' and o.peek_name()=='CT_FP_Gloves':
        me=o.read(); h=MeshHandler(me); h.process()
        V=np.array(h.m_Vertices,np.float32).reshape(-1,3); n=len(V)
        out['CT_FP_Gloves']=dict(V=V,N=np.array(h.m_Normals,np.float32).reshape(n,-1)[:,:3],UV=np.array(h.m_UV0,np.float32).reshape(n,-1)[:,:2],T=np.concatenate([np.array(x,np.int64).reshape(-1,3) for x in h.get_triangles()]))
    if o.type.name=='Texture2D' and o.peek_name()=='CT_FP_D':
        im=o.read().image.convert('RGB')
        if im.width>1024: im=im.resize((1024,1024))
        im.save('/data/inv/w3d/tex/defaultgloves__default.jpg',quality=93)
pickle.dump(out,open('/data/inv/w3d/gloves.pkl','wb'))
