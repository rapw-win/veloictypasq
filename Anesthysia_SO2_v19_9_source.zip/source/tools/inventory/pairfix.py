# dual weapons (Berettas, Akimbo Uzi): the game mesh holds both guns in a V; keep one and put a copy right behind it
import pickle,numpy as np
m=pickle.load(open('/data/inv/w3d/meshes.pkl','rb')); o=pickle.load(open('/data/inv/w3d/meshes_orig.pkl','rb'))
for name,(dx,dy,dz) in {'Berettas':(-0.035,0.025,0.018),'Akimbo Uzi':(-0.045,0.03,0.022)}.items():
    b=o[name];V,N,UV,T=b['V'],b['N'],b['UV'],b['T'].reshape(-1,3)
    h=len(V)//2; TA=T[(T<h).all(1)]
    print(name,len(V),len(T),len(TA), V[:h].min(0).round(3),V[:h].max(0).round(3))
    VA=V[:h]; VB=VA+np.array([dx,dy,dz])
    m[name]=dict(V=np.vstack([VA,VB]).astype(np.float32),N=np.vstack([N[:h],N[:h]]),UV=np.vstack([UV[:h],UV[:h]]),T=np.vstack([TA,TA+h]))
pickle.dump(m,open('/data/inv/w3d/meshes.pkl','wb'))
