import UnityPy, numpy as np, json, io
from UnityPy.helpers.MeshHelper import MeshHandler
env=UnityPy.load('so2/obb/assets/DLC/BuiltInCollections/builtincollections_shared_so2_models.bundle')
def tpath(tr):
    names=[]; t=tr
    while True:
        names.append(t.m_GameObject.read().m_Name)
        if not t.m_Father.path_id: break
        t=t.m_Father.read()
    return "/".join(reversed(names))
out={}
for o in env.objects:
    if o.type.name!="SkinnedMeshRenderer": continue
    r=o.read(); go=r.m_GameObject.read()
    if go.m_Name not in("CT_Michael_Inspect_Body","CT_Michael_Inspect_Gloves"): continue
    mesh=r.m_Mesh.read(); h=MeshHandler(mesh); h.process()
    bones=[tpath(b.read()) for b in r.m_Bones]
    V=np.array(h.m_Vertices,np.float32).reshape(-1,3); N=np.array(h.m_Normals,np.float32).reshape(-1,3)
    UV=np.array(h.m_UV0,np.float32).reshape(-1,2)
    BW=h.m_BoneWeights
    wi=np.array(h.m_BoneIndices); ww=np.array(h.m_BoneWeights)
    idx=[]
    for si in range(len(mesh.m_SubMeshes)): idx+=h.get_triangles()[si] if callable(getattr(h,'get_triangles',None)) else []
    tris=np.array(h.get_triangles(),dtype=object) if False else None
    bp=np.array([[ [m.e00,m.e01,m.e02,m.e03],[m.e10,m.e11,m.e12,m.e13],[m.e20,m.e21,m.e22,m.e23],[m.e30,m.e31,m.e32,m.e33]] for m in mesh.m_BindPose],np.float32)
    mat=r.m_Materials[0].read()
    tex=None
    for k,v in mat.m_SavedProperties.m_TexEnvs:
        print(go.m_Name,'tex',k, v.m_Texture.path_id)
        if k in('_MainTex','_BaseMap','_Albedo') and v.m_Texture.path_id:
            t=v.m_Texture.read(); tex=t.m_Name; t.image.save(f'ex/{go.m_Name}_{k}.png')
    out[go.m_Name]=dict(V=V,N=N,UV=UV,wi=wi,ww=ww,bp=bp,bones=bones,tris=h.get_triangles())
    print(go.m_Name,V.shape,N.shape,UV.shape,wi.shape,len(bones),bp.shape,[len(t) for t in h.get_triangles()], mesh.m_SubMeshes.__len__())
    print(bones[:5])
import pickle; pickle.dump(out,open('ex/mesh.pkl','wb'))
# full hierarchy of CT_Michael_TP
T={}
for o in env.objects:
    if o.type.name=="Transform":
        t=o.read()
        try: p=tpath(t)
        except Exception: continue
        if p.startswith("CT_Michael_TP"):
            T[p]=dict(q=[t.m_LocalRotation.x,t.m_LocalRotation.y,t.m_LocalRotation.z,t.m_LocalRotation.w],t=[t.m_LocalPosition.x,t.m_LocalPosition.y,t.m_LocalPosition.z],s=[t.m_LocalScale.x,t.m_LocalScale.y,t.m_LocalScale.z])
pickle.dump(T,open('ex/hier.pkl','wb')); print(len(T)); print([k for k in T if k.count('/')<=2])
