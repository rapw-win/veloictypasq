import numpy as np, human as h, os
from fp_gen import pose,nm
def cam_of(AG, back=0.30, side=0.16, upo=0.12, yaw=0.10, pitch=0.0):
    q=AG[nm('Tool')][0]; bar=h.qrot(q,[0,-1,0]); bar=bar/np.linalg.norm(bar)
    up=np.array([0,1.0,0]); f=bar-up*(bar@up); f/=np.linalg.norm(f)
    r=np.cross(up,f)
    c,s=np.cos(yaw),np.sin(yaw); f2=f*c+r*s; r2=np.cross(up,f2)
    cp,sp=np.cos(pitch),np.sin(pitch); f3=f2*cp+up*sp; u3=np.cross(f3,r2)
    grip=AG[nm('RightHand')][1]
    pos=grip-f3*back-r2*side+u3*upo
    return pos,r2,u3,f3
