import numpy as np, pickle, os
import human as h
from clipdec import decode
CLIP=os.environ.get('CLIP','ex/akr_fp_idle.pkl')
value,bind,info=decode(pickle.load(open(CLIP,'rb')))
LEN=info['stop']; print('len',LEN)
ap={p:i for i,p in enumerate(h.apath)}
PAR=[n['m_ParentId'] for n in h.ASK['m_Node']]
def nm(s): return [j for j,p in enumerate(h.apath) if p.endswith('/'+s)][0]
def recompute_subtree(AG,root,locs):
    for j in range(root+1,len(AG)):
        k=PAR[j]; anc=False
        while k>=0:
            if k==root: anc=True; break
            k=PAR[k]
        if anc:
            p=PAR[j]; lq,lt=locs[j]; pq,pt=AG[p]; AG[j]=(h.qmul(pq,lq),pt+h.qrot(pq,lt))
def locals_of(AG):
    L=[]
    for j in range(len(AG)):
        p=PAR[j]
        if p<0: L.append(AG[j]); continue
        pq,pt=AG[p]; iq=h.qconj(pq); L.append((h.qmul(iq,AG[j][0]), h.qrot(iq,AG[j][1]-pt)))
    return L
def rot_between(a,b):
    a=a/np.linalg.norm(a); b=b/np.linalg.norm(b); c=np.cross(a,b); d=a@b
    if d<-0.9999: return np.array([1.0,0,0,0])
    return h.qn(np.array([*c,1+d]))
def ik_arm(AG,side):
    A=nm(f'{side}Arm'); F=nm(f'{side}ForeArm'); Hn=nm(f'{side}Hand'); T=nm(f'{side}HandIK'); P=nm(f'{side}ElbowIK')
    L=locals_of(AG)
    a=AG[A][1]; f=AG[F][1]; hh=AG[Hn][1]; t=AG[T][1]; pole=AG[P][1]
    l1=np.linalg.norm(f-a); l2=np.linalg.norm(hh-f)
    d=t-a; dist=min(np.linalg.norm(d),l1+l2-1e-4); dn=d/np.linalg.norm(d)
    x=(l1*l1-l2*l2+dist*dist)/(2*dist); y=np.sqrt(max(0,l1*l1-x*x))
    pv=pole-a; pv=pv-dn*(pv@dn); pv/=np.linalg.norm(pv)
    e=a+dn*x+pv*y
    r1=rot_between(f-a,e-a); AG[A]=(h.qmul(r1,AG[A][0]),a); recompute_subtree(AG,A,L)
    f=AG[F][1]; hh=AG[Hn][1]
    r2=rot_between(hh-f,a+dn*dist-f); AG[F]=(h.qmul(r2,AG[F][0]),f); recompute_subtree(AG,F,L)
    return AG
def pose(t):
    AG=h.human_pose(*h.sample(value,bind,t))
    for s in ('Left','Right'):
        AG=ik_arm(AG,s)
        L=locals_of(AG); Hn=nm(f'{s}Hand'); AG[Hn]=(AG[nm(f'{s}HandIK')][0],AG[Hn][1]); recompute_subtree(AG,Hn,L)
    return AG
if __name__=='__main__':
    AG=pose(0.0)
    for s in ('Head','LeftHand','RightHand','LeftHandIK','RightHandIK','Tool','ToolPivot','Spine2','LeftArm'):
        print(s,np.round(AG[nm(s)][1],3))
