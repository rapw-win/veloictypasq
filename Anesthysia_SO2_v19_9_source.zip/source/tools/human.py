import numpy as np, json
from clipdec import load_clip, decode
def Q(d): return np.array([d['x'],d['y'],d['z'],d['w']],float)
def V(d): return np.array([d['x'],d['y'],d['z']],float)
def qmul(a,b):
    ax,ay,az,aw=a; bx,by,bz,bw=b
    return np.array([aw*bx+ax*bw+ay*bz-az*by, aw*by-ax*bz+ay*bw+az*bx, aw*bz+ax*by-ay*bx+az*bw, aw*bw-ax*bx-ay*by-az*bz])
def qconj(a): return np.array([-a[0],-a[1],-a[2],a[3]])
def qrot(q,v): return qmul(qmul(q,np.array([v[0],v[1],v[2],0.0])),qconj(q))[:3]
def qn(q): return q/np.linalg.norm(q)
AV=json.load(open('/data/avatar.json'))['m_Avatar']
H=AV['m_Human']['data']; HS=H['m_Skeleton']['data']; HP=H['m_SkeletonPose']['data']['m_X']
ASK=AV['m_AvatarSkeleton']['data']; ADP=AV['m_DefaultPose']['data']['m_X']
TOS=dict(json.load(open('/data/avatar.json'))['m_TOS'])
apath=[TOS.get(i,'?') for i in ASK['m_ID']]
hnode=HS['m_Node']; axes=HS['m_AxesArray']
H2A=AV['m_HumanSkeletonIndexArray']
HBI=H['m_HumanBoneIndex']
# bone enum -> (x,y,z) muscle idx
DOF={7:(2,1,0),8:(5,4,3),9:(8,7,6),10:(11,10,9),11:(14,13,12),
 1:(23,22,21),3:(25,-1,24),5:(-1,27,26),20:(-1,-1,28),
 2:(31,30,29),4:(33,-1,32),6:(-1,35,34),21:(-1,-1,36),
 12:(-1,38,37),14:(41,40,39),16:(43,-1,42),18:(-1,45,44),
 13:(-1,47,46),15:(50,49,48),17:(52,-1,51),19:(-1,54,53)}
node2bone={HBI[b]:b for b in range(25) if HBI[b]>=0}
def axes_to_quat(ax,uvw,mode):
    mn=V(ax['m_Limit']['m_Min']); mx=V(ax['m_Limit']['m_Max']); sg=V(ax['m_Sgn'])
    ang=np.where(uvw<0,-uvw*mn,uvw*mx)*sg
    q=swing_twist(ang)
    return qn(qmul(qmul(Q(ax['m_PreQ']),q),qconj(Q(ax['m_PostQ']))))
def aa(axis,a):
    n=np.linalg.norm(axis)
    if n<1e-9 or abs(a)<1e-12: return np.array([0,0,0,1.0])
    axis=axis/n; return np.array([*(axis*np.sin(a/2)),np.cos(a/2)])
def swing_twist(r):
    yz=np.array([0,r[1],r[2]]); return qmul(aa(yz,np.linalg.norm(yz)),aa(np.array([1.0,0,0]),r[0]))
SPREAD=[(7,(20,-30,-30)),(8,(20,-20,-20)),(9,(10,-10,-10))]
TQ=None
def spread_q(mus):
    q=np.array([0,0,0,1.0])
    for b,sc in SPREAD:
        d=DOF[b]; q=qmul(q,swing_twist(np.radians([mus[d[k]]*sc[k] for k in range(3)])))
    # t = LookRotation(right, forward): maps +z->+x, +y->+z
    m=np.array([[0,0,1],[1,0,0],[0,1,0]],float).T  # columns: images of x,y,z
    # rotation matrix with columns R*x,R*y,R*z where R*z=+x, R*y=+z, R*x = y cross z
    Rz=np.array([1.0,0,0]); Ry=np.array([0,0,1.0]); Rx=np.cross(Ry,Rz)
    R=np.stack([Rx,Ry,Rz],1); t=mat2q(R)
    return qmul(qmul(t,q),qconj(t))
def mat2q(m):
    tr=np.trace(m)
    if tr>0: s=np.sqrt(tr+1)*2; return np.array([(m[2,1]-m[1,2])/s,(m[0,2]-m[2,0])/s,(m[1,0]-m[0,1])/s,0.25*s])
    i=int(np.argmax(np.diag(m))); j,k=(i+1)%3,(i+2)%3
    s=np.sqrt(1+m[i,i]-m[j,j]-m[k,k])*2; q=np.zeros(4)
    q[i]=0.25*s; q[j]=(m[j,i]+m[i,j])/s; q[k]=(m[k,i]+m[i,k])/s; q[3]=(m[k,j]-m[j,k])/s; return q
USE_SPREAD=True
# defaults
def chain_globals(nodes,X):
    G=[]
    for i,n in enumerate(nodes):
        q=Q(X[i]['q']); t=V(X[i]['t'])
        p=n['m_ParentId']
        if p<0: G.append((q,t))
        else: pq,pt=G[p]; G.append((qmul(pq,q),pt+qrot(pq,t)))
    return G
AG_def=chain_globals(ASK['m_Node'],ADP)
HG_def=chain_globals(hnode,HP)
RX=H['m_RootX']; RXq=Q(RX['q']); RXt=V(RX['t']); SCALE=H['m_Scale']
def human_pose(mus,rootT,rootQ,generic,mode=0):
    """returns avatar globals list of (q,t)"""
    # human locals
    HG=[None]*len(hnode)
    hips_node=HBI[0]
    for i,n in enumerate(hnode):
        p=n['m_ParentId']
        if i==hips_node:
            # hipsG = RootPose * inv(RootX) * hipsDef
            hq,ht=HG_def[i]
            rel_q=qmul(qconj(RXq),hq); rel_t=qrot(qconj(RXq),ht-RXt)
            rq=qmul(rootQ,qconj(spread_q(mus))) if USE_SPREAD else rootQ
            HG[i]=(qmul(rq,rel_q), rootT*SCALE+qrot(rq,rel_t)); continue
        if p<0: HG[i]=HG_def[i]; continue
        if n['m_AxesId']>=0 and i in node2bone and node2bone[i] in DOF:
            d=DOF[node2bone[i]]; uvw=np.array([mus[k] if k>=0 else 0.0 for k in d])
            lq=axes_to_quat(axes[n['m_AxesId']],uvw,mode)
        else: lq=Q(HP[i]['q'])
        pq,pt=HG[p]
        HG[i]=(qmul(pq,lq), pt+qrot(pq,V(HP[i]['t'])))
    rev={H2A[h]:h for h in range(len(hnode))}
    AG=[]
    for j,n in enumerate(ASK['m_Node']):
        p=n['m_ParentId']
        lq=Q(ADP[j]['q']); lt=V(ADP[j]['t'])
        g=generic.get(apath[j])
        if g is not None:
            if 'q' in g: lq=g['q']
            if 't' in g: lt=g['t']
        if p<0: base=(np.array([0,0,0,1.0]),np.zeros(3))
        else: base=AG[p]
        pos=base[1]+qrot(base[0],lt)
        if j in rev and rev[j]!=0 and (hnode[rev[j]]['m_AxesId']>=0 or rev[j]==hips_node):
            q=HG[rev[j]][0]
            if rev[j]==hips_node: pos=HG[rev[j]][1]
        else: q=qmul(base[0],lq)
        AG.append((q,pos))
    return AG
def sample(value,bind,t):
    mus=np.zeros(95); rT=np.array([0,1.0,0]); rQ=np.array([0,0,0,1.0]); gen={}
    for tid,at,path,ci,n in bind:
        if tid==95:
            v=value(ci,t)
            if 42<=at<137: mus[at-42]=v
            elif 7<=at<=9: rT[at-7]=v
            elif 10<=at<=13: rQ[at-10]=v
        elif tid==4:
            p=TOS.get(path)
            if p is None: continue
            vals=np.array([value(ci+k,t) for k in range(n)])
            g=gen.setdefault(p,{})
            if at==2: g['q']=qn(vals)
            elif at==1: g['t']=vals
    return mus,rT,qn(rQ),gen
