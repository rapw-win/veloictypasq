import numpy as np, human as h
from clipdec import load_clip, decode
D='so2/obb/assets/bin/Data/data.unity3d'
import os
W=os.environ.get('ARMCLIP','M4_Idle').replace('_Idle','')      # M4 / AKR
_C={}
def clip(n):
    if n not in _C: _C[n]=decode(load_clip(D,n))
    return _C[n]
# lobby: idle loop with the idle breaks (raise the weapon, look at it) like the game lobby
SEQ=[('Rifle_Base_Idle',W+'_Idle'),('Rifle_Base_Idle_Break_Type_1',W+'_Idle_Break_Type_1'),
     ('Rifle_Base_Idle',W+'_Idle'),('Rifle_Base_Idle_Break_Type_2',W+'_Idle_Break_Type_2')]
SEG=[]; _t=0.0
for b,a in SEQ:
    L=min(clip(b)[2]['stop'],clip(a)[2]['stop']); SEG.append((b,a,_t,L)); _t+=L
LEN=_t; XF=0.30
def _raw(b,a,t):
    B=clip(b); A=clip(a)
    mb,rT,rQ,_=h.sample(B[0],B[1],t)
    ma,_,_,gen=h.sample(A[0],A[1],t)
    mus=mb.copy(); mus[37:55]=ma[37:55]
    return mus,rT,rQ,gen
def _blend(x,y,w):
    mus=x[0]*(1-w)+y[0]*w; rT=x[1]*(1-w)+y[1]*w
    q2=y[2] if x[2]@y[2]>=0 else -y[2]; rQ=h.qn(x[2]*(1-w)+q2*w)
    gen={}
    for p in set(x[3])|set(y[3]):
        g1=x[3].get(p,{}); g2=y[3].get(p,{}); g={}
        for k in set(g1)|set(g2):
            if k in g1 and k in g2:
                if k=='q': b2=g2[k] if g1[k]@g2[k]>=0 else -g2[k]; g[k]=h.qn(g1[k]*(1-w)+b2*w)
                else: g[k]=g1[k]*(1-w)+g2[k]*w
            else: g[k]=g1.get(k,g2.get(k))
        gen[p]=g
    return mus,rT,rQ,gen
def lobby(t):
    t=t%LEN
    for i,(b,a,t0,L) in enumerate(SEG):
        if t<t0+L or i==len(SEG)-1: break
    lt=min(t-t0,L-1e-4); cur=_raw(b,a,lt)
    if lt<XF:   # crossfade from the end of the previous segment
        pb,pa,_,pL=SEG[i-1]; prev=_raw(pb,pa,pL-1e-4)
        w=lt/XF; w=w*w*(3-2*w); cur=_blend(prev,cur,w)
    return h.human_pose(*cur)
idx={p:j for j,p in enumerate(h.apath)}
def nm(s): return [j for j,p in enumerate(h.apath) if p.endswith('/'+s)][0]
PAR=[n['m_ParentId'] for n in h.ASK['m_Node']]
def children_fix(AG,local_def):
    pass
def recompute_subtree(AG,root,locs):
    # recompute globals of descendants of root using local transforms locs
    for j in range(root+1,len(AG)):
        p=PAR[j]; k=p
        # check ancestry
        anc=False
        while k>=0:
            if k==root: anc=True; break
            k=PAR[k]
        if anc:
            lq,lt=locs[j]; pq,pt=AG[p]; AG[j]=(h.qmul(pq,lq),pt+h.qrot(pq,lt))
def locals_of(AG):
    L=[]
    for j in range(len(AG)):
        p=PAR[j]
        if p<0: L.append(AG[j]); continue
        pq,pt=AG[p]; iq=h.qconj(pq)
        L.append((h.qmul(iq,AG[j][0]), h.qrot(iq,AG[j][1]-pt)))
    return L
def rot_between(a,b):
    a=a/np.linalg.norm(a); b=b/np.linalg.norm(b); c=np.cross(a,b); d=a@b
    if d<-0.9999: return np.array([1.0,0,0,0])
    return h.qn(np.array([*c,1+d]))
def ik_arm(AG,side):
    A=nm(f'{side}Arm'); F=nm(f'{side}ForeArm'); Hn=nm(f'{side}Hand')
    T=nm(f'{side}HandIK'); P=nm(f'{side}ElbowIK')
    L=locals_of(AG)
    a=AG[A][1]; f=AG[F][1]; hh=AG[Hn][1]; t=AG[T][1]; pole=AG[P][1]
    l1=np.linalg.norm(f-a); l2=np.linalg.norm(hh-f)
    d=t-a; dist=min(np.linalg.norm(d),l1+l2-1e-4); dn=d/np.linalg.norm(d)
    x=(l1*l1-l2*l2+dist*dist)/(2*dist); y=np.sqrt(max(0,l1*l1-x*x))
    pv=pole-a; pv=pv-dn*(pv@dn); pv/=np.linalg.norm(pv)
    e=a+dn*x+pv*y
    # upper arm
    r1=rot_between(f-a,e-a); AG[A]=(h.qmul(r1,AG[A][0]),a); recompute_subtree(AG,A,L)
    f=AG[F][1]; hh=AG[Hn][1]
    r2=rot_between(hh-f,a+dn*dist-f); AG[F]=(h.qmul(r2,AG[F][0]),f); L=locals_of(AG) if False else L
    L2=locals_of(AG); L2[F]=L[F] if False else L2[F]
    recompute_subtree(AG,F,L)
    return AG
def lobby_ik(t,use_hand_q=True):
    AG=lobby(t)
    for s in ('Left','Right'):
        hq_fk=AG[nm(f'{s}Hand')][0]
        AG=ik_arm(AG,s)
        if use_hand_q:
            L=locals_of(AG); Hn=nm(f'{s}Hand'); AG[Hn]=(AG[nm(f'{s}HandIK')][0],AG[Hn][1]); recompute_subtree(AG,Hn,L)
    return AG
