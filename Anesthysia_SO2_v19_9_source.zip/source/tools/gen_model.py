import numpy as np, pickle, io, human as h, lobby
from PIL import Image
import os
AGENT=os.environ.get('AGENT','CT_Michael'); SYM=os.environ.get('SYM','CT'); OUT=os.environ.get('OUT','model_ct_new.h')
M=pickle.load(open(f'ex/mesh_{AGENT}.pkl' if AGENT!='CT_Michael' else 'ex/mesh.pkl','rb')); HI=pickle.load(open(f'ex/hier_{AGENT}.pkl' if AGENT!='CT_Michael' else 'ex/hier.pkl','rb'))
WEAPON=os.environ.get('WEAPON','M4')
W4=pickle.load(open('ex/w0.pkl','rb'))
if WEAPON=='M4': WMESH=[('LOD0_M4_Mono','TOOL')]; WTEX='ex/M4_D.png'
else: WMESH=[('AKR_Mono','TOOL')]; WTEX='ex/AKR_D.png'
ap={p:i for i,p in enumerate(h.apath)}
PFX=AGENT+'_TP/'
def strip(p): return p[len(PFX):] if p.startswith(PFX) else p
def fullG(AG):
    G={}
    def g(sp):
        if sp in G: return G[sp]
        if sp in ap: G[sp]=AG[ap[sp]]; return G[sp]
        par=sp.rsplit('/',1)[0]; pq,pt=g(par); L=HI[PFX+sp]
        G[sp]=(h.qmul(pq,np.array(L['q'])), pt+h.qrot(pq,np.array(L['t']))); return G[sp]
    return g
ESP=['Root/Hips','Root/Hips/Spine','Root/Hips/Spine/Spine1','Root/Hips/Spine/Spine1/Spine2','Root/Hips/Spine/Spine1/Spine2/Neck','Root/Hips/Spine/Spine1/Spine2/Neck/Head']
S2='Root/Hips/Spine/Spine1/Spine2/'
for s in ('Left','Right'):
    ESP+= [S2+f'{s}Shoulder',S2+f'{s}Shoulder/{s}Arm',S2+f'{s}Shoulder/{s}Arm/{s}ForeArm',S2+f'{s}Shoulder/{s}Arm/{s}ForeArm/{s}Hand']
for s in ('Left','Right'):
    b=f'Root/Hips/{s}UpLeg'; ESP+=[b,b+f'/{s}Leg',b+f'/{s}Leg/{s}Foot',b+f'/{s}Leg/{s}Foot/{s}ToeBase']
TOOL=S2+'ToolPivot/Tool'; PART_CH=TOOL+'/Part1'; PART_MAG=TOOL+'/Part2'
parts=[AGENT+'_Inspect_Body',AGENT+'_Inspect_Gloves']
bones=list(ESP)
for p in parts:
    for b in M[p]['bones']:
        b=strip(b)
        if b not in bones: bones.append(b)
for b in (TOOL,PART_CH,PART_MAG):
    if b not in bones: bones.append(b)
NB=len(bones); print('bones',NB)
BI={b:i for i,b in enumerate(bones)}
# bind globals
def inv_rt(m): R=m[:3,:3]; t=m[:3,3]; return R.T, -R.T@t
bind={}
for p in parts:
    for k,b in enumerate(M[p]['bones']):
        R,t=inv_rt(M[p]['bp'][k]); bind.setdefault(strip(b),(h.mat2q(R),t))
FPS=30; LEN=lobby.LEN; NF=int(round(LEN*FPS))
frames=[]
for f in range(NF):
    g=fullG(lobby.lobby_ik(f/FPS)); frames.append([g(b) for b in bones])
    if f==0:
        g0=[g(b) for b in bones]
        for i,b in enumerate(bones):
            if b not in bind:
                bind[b]=g0[i] if b in (TOOL,PART_CH,PART_MAG) else h.AG_def[ap[b]] if b in ap else g0[i]
print('frames',NF)
# geometry (Unity space, bind pose)
P=[];N=[];UV=[];WI=[];WW=[];IDX=[];prims=[]
for p in parts:
    d=M[p]; off=len(P); loc=[BI[strip(b)] for b in d['bones']]
    P+=list(d['V']); N+=list(d['N']); UV+=list(d['UV'])
    WI+=[[loc[i] for i in r] for r in d['wi']]; WW+=list(d['ww'])
    for sub in d['tris']:
        for tr in sub: IDX+=[i+off for i in tr]
prims.append([0,len(IDX),0])
def rigid(mesh,bone):
    d=W4[mesh]; off=len(P); q,t=bind[bone]
    for v in d['V']: P.append(h.qrot(q,v)+t)
    for n in d['N']: N.append(h.qrot(q,n))
    UV.extend(list(d['UV'])); WI.extend([[BI[bone],0,0,0]]*len(d['V'])); WW.extend([[1,0,0,0]]*len(d['V']))
    for sub in d['tris']:
        for tr in sub: IDX.extend([i+off for i in tr])
s0=len(IDX)
for mn,bn in WMESH: rigid(mn,{'TOOL':TOOL,'MAG':PART_MAG,'CH':PART_CH}[bn])
prims.append([s0,len(IDX)-s0,1])
P=np.array(P,float); N=np.array(N,float); UV=np.array(UV,float); WI=np.array(WI); WW=np.array(WW,float)
# mirror x (Unity LH -> menu)
P[:,0]*=-1; N[:,0]*=-1
IDX=np.array(IDX).reshape(-1,3)[:,[0,2,1]].reshape(-1)
def mq(q): return np.array([q[0],-q[1],-q[2],q[3]])
def mp(t): return np.array([-t[0],t[1],t[2]])
REST=np.array([mp(bind[b][1]) for b in bones])
FR=np.zeros((NF,NB,7))
for f in range(NF):
    for i,b in enumerate(bones):
        qt,tt=frames[f][i]; qb,tb=bind[b]
        R=h.qn(h.qmul(mq(qt),h.qconj(mq(qb))))
        if R[3]<0: R=-R
        FR[f,i,:4]=R; FR[f,i,4:]=mp(tt)
# ground: keep lowest toe at original height
# weights to uint8
WW=WW/np.maximum(WW.sum(1,keepdims=True),1e-9); W8=np.floor(WW*255+0.5).astype(int)
for r in W8:
    d=255-r.sum(); r[np.argmax(r)]+=d
WI[W8==0]=0
# wire: weld by position
key=np.round(P*1000).astype(int); uniq={}; remap=np.zeros(len(P),int); wv=[]
for i,k in enumerate(map(tuple,key)):
    if k not in uniq: uniq[k]=len(wv); wv.append(i)
    remap[i]=uniq[k]
E=set()
T=IDX.reshape(-1,3)
for a,b,c in remap[T]:
    for x,y in ((a,b),(b,c),(c,a)):
        if x!=y: E.add((min(x,y),max(x,y)))
E=np.array(sorted(E)); wv=np.array(wv)
print('nv',len(P),'ni',len(IDX),'wnv',len(wv),'wne',len(E))
head=REST[5]+np.array([0,0.105,0])
tops=P[(WI[:,0]==5)&(W8[:,0]>200)]
head=REST[5]+np.array([0,0.098,0])
print('head',head,'hips',REST[0],'minY',P[:,1].min())
def jpg(path,size,q=93):
    im=Image.open(path).convert('RGB').resize((size,size),Image.LANCZOS); b=io.BytesIO(); im.save(b,'JPEG',quality=q); return b.getvalue()
TEX=[jpg(f'ex/{AGENT}_TP_D.png',2048),jpg(WTEX,1024)]
def arr(name,typ,vals,per=24):
    vals=list(vals); s=f"static const {typ} {name}[{len(vals)}] = {{\n"
    for i in range(0,len(vals),per): s+=",".join(str(v) for v in vals[i:i+per])+",\n"
    return s+"};\n"
q16=lambda a: np.clip(np.round(a),-32767,32767).astype(int)
out=f"// generated by tools/gen_model.py: Standoff 2 agent {AGENT} (lobby/inspect mesh) holding the {WEAPON}, game build 1.0.0 (203964)\n"
out+=f"// animation: lobby idle = Rifle_Base_Idle (body layer) + {WEAPON} idle (arms layer), humanoid muscles -> bones, hand IK to the weapon\n#pragma once\n#include <cstdint>\n"
out+=f"static const int {SYM}_NV = {len(P)}, {SYM}_NI = {len(IDX)}, {SYM}_NPRIM = {len(prims)}, {SYM}_WNV = {len(wv)}, {SYM}_WNE = {len(E)}, {SYM}_NTEX = {len(TEX)};\n"
out+=f"static const int {SYM}_PRIMS[][3] = "+"{"+",".join("{%d,%d,%d}"%tuple(p) for p in prims)+"};\n"
out+=arr(SYM+'_POS','int16_t',q16(P.reshape(-1)*16000))
out+=arr(SYM+'_NRM','int8_t',np.clip(np.round(N/np.maximum(np.linalg.norm(N,axis=1,keepdims=True),1e-9)*127),-127,127).astype(int).reshape(-1))
uv=UV.copy(); uv[:,1]=1-uv[:,1]; uv=uv-np.floor(uv.min(0)) if False else uv
out+=arr(SYM+'_UV','uint16_t',np.clip(np.round((uv%1.0)*65535),0,65535).astype(int).reshape(-1))
out+=arr(SYM+'_IDX','uint16_t',IDX)
out+=arr(SYM+'_WPOS','int16_t',q16(P[wv].reshape(-1)*16000))
out+=arr(SYM+'_WEDGE','uint16_t',E.reshape(-1))
out+=f"static const int {SYM}_NB = {NB}, {SYM}_NF = {NF}, {SYM}_FPS = {FPS};\n"
out+=f"static const float {SYM}_REST[] = "+"{"+",".join("%.4ff"%v for v in REST.reshape(-1))+"};\n"
F=FR.copy(); F[...,:4]*=32767; F[...,4:]*=16000
out+=arr(SYM+'_FRAMES','int16_t',q16(F.reshape(-1)))
out+=arr(SYM+'_WIDX','uint8_t',WI.reshape(-1)); out+=arr(SYM+'_WW','uint8_t',W8.reshape(-1))
out+=arr(SYM+'_WWIDX','uint8_t',WI[wv].reshape(-1)); out+=arr(SYM+'_WWW','uint8_t',W8[wv].reshape(-1))
out+=f"static const float {SYM}_HEADPT[3] = "+"{%.4ff,%.4ff,%.4ff};\n"%tuple(head)
for k,t in enumerate(TEX): out+=arr(f'{SYM}_TEX{k}','unsigned char',t,40)
out+=f"static const unsigned char* {SYM}_TEX[] = "+"{"+",".join(f"{SYM}_TEX{k}" for k in range(len(TEX)))+"};\n"
out+=f"static const int {SYM}_TEXSZ[] = "+"{"+",".join(str(len(t)) for t in TEX)+"};\n"
open(OUT,'w').write(out); print('written',len(out))
