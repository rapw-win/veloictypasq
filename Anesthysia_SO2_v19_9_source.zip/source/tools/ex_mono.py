import UnityPy, numpy as np, pickle
from UnityPy.helpers.MeshHelper import MeshHandler
e=UnityPy.load('so2/obb/assets/CustomDLC/DefaultCollection/defaultcollection_content_mesh.bundle')
want={-827989642105154651:'AKR_Mono',3703098204474741669:'LOD0_AKM'}
out={}
for o in e.objects:
  if o.type.name=='Mesh' and (o.path_id in want or o.peek_name() in('LOD0_M4_Mono','LOD0_M4','LOD0_M4_Magazine','LOD0_M4_ChargingHandle')):
    m=o.read(); hd=MeshHandler(m); hd.process()
    V=np.array(hd.m_Vertices).reshape(-1,3); n=len(V)
    N=np.array(hd.m_Normals).reshape(n,-1)[:,:3]; UV=np.array(hd.m_UV0).reshape(n,-1)[:,:2]
    k=want.get(o.path_id,m.m_Name); out[k]=dict(V=V,N=N,UV=UV,tris=hd.get_triangles())
    print(k,n,len(hd.get_triangles()),UV.min(0).round(2),UV.max(0).round(2),V.min(0).round(3),V.max(0).round(3))
pickle.dump(out,open('ex/w0.pkl','wb'))
from scipy.spatial import cKDTree
