import numpy as np, pickle
import human as h
from fp_gen import pose, nm, ap
M=pickle.load(open('ex/fp.pkl','rb'))
def q2m(q):
    x,y,z,w=q
    return np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])
def G4(qt):
    m=np.eye(4); m[:3,:3]=q2m(qt[0]); m[:3,3]=qt[1]; return m
def skin(AG,d):
    Ms=np.array([G4(AG[ap[b]])@d['bp'][k] for k,b in enumerate(d['bones'])])
    V=np.c_[d['V'],np.ones(len(d['V']))]
    out=np.zeros((len(V),3))
    for j in range(d['wi'].shape[1]):
        out+=d['ww'][:,j:j+1]*np.einsum('nij,nj->ni',Ms[d['wi'][:,j]],V)[:,:3]
    return out
if __name__=='__main__':
    AG=pose(0.0)
    A=skin(AG,M['T_FP_Arms']); Gl=skin(AG,M['T_FP_Gloves'])
    W=np.array([G4(AG[nm('Tool')])@np.r_[v,1] for v in M['AKR']['V']])[:,:3]
    print('arms',A.min(0).round(3),A.max(0).round(3)); print('gloves',Gl.min(0).round(3),Gl.max(0).round(3)); print('akr',W.min(0).round(3),W.max(0).round(3))
    import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
    cam=np.array(AG[nm('Head')][1])+np.array([0,0.07,0.08])
    fig,ax=plt.subplots(1,2,figsize=(14,6))
    for P,c in ((A,'r'),(Gl,'g'),(W,'k')):
        d=P-cam; z=d[:,2]; m=z>0.03
        ax[0].scatter(d[m,0]/z[m],d[m,1]/z[m],s=0.3,c=c); ax[1].scatter(P[:,0],P[:,1],s=0.3,c=c)
    ax[0].set_xlim(-1.2,1.2); ax[0].set_ylim(-0.7,0.7); ax[0].set_aspect('equal'); ax[1].set_aspect('equal')
    plt.savefig('fp_dbg.png',dpi=70)
