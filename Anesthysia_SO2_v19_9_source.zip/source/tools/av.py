import UnityPy, json
env=UnityPy.load('so2/obb/assets/CustomDLC/Inspect/inspect_content_main.bundle')
for o in env.objects:
    if o.type.name=="Avatar":
        json.dump(o.read_typetree(),open('avatar.json','w')); print(o.peek_name()); break
