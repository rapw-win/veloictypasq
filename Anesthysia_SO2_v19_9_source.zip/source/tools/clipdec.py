import UnityPy, numpy as np, struct
def load_clip(bundle, name):
    env=UnityPy.load(bundle)
    for o in env.objects:
        if o.type.name=="AnimationClip" and o.peek_name()==name:
            return o.read_typetree()
def decode(tt):
    mc=tt['m_MuscleClip']; c=mc['m_Clip']['data'] if 'data' in mc['m_Clip'] else mc['m_Clip']
    sc=c['m_StreamedClip']; dc=c['m_DenseClip']; cc=c['m_ConstantClip']
    raw=struct.pack('<%dI'%len(sc['data']),*sc['data'])
    # streamed: frames of (time float, count uint, count*(idx uint, 4 floats))
    keys={}  # curve -> list of (time, coeffs)
    off=0
    while off < len(raw):
        t,n=struct.unpack_from('<fI',raw,off); off+=8
        for _ in range(n):
            ci,a,b,cc_,d=struct.unpack_from('<I4f',raw,off); off+=20
            keys.setdefault(ci,[]).append((t,(a,b,cc_,d)))
    nS=sc['curveCount']; nD=dc['m_CurveCount']; consts=cc['data']
    dense=np.array(dc['m_SampleArray'],np.float32).reshape(-1,nD) if nD else None
    info=dict(nS=nS,nD=nD,nC=len(consts),dfps=dc['m_SampleRate'],dbegin=dc['m_BeginTime'],start=mc['m_StartTime'],stop=mc['m_StopTime'])
    def value(ci,t):
        if ci<nS:
            ks=keys.get(ci)
            if not ks: return 0.0
            best=ks[0]
            for k in ks:
                if k[0]<=t: best=k
                else: break
            dx=t-best[0]; a,b,c_,d=best[1]
            return ((a*dx+b)*dx+c_)*dx+d
        ci-=nS
        if ci<nD:
            f=(t-info['dbegin'])*info['dfps']; f=min(max(f,0),dense.shape[0]-1)
            i=int(np.floor(f)); j=min(i+1,dense.shape[0]-1); u=f-i
            return float(dense[i,ci]*(1-u)+dense[j,ci]*u)
        ci-=nD
        return consts[ci]
    # bindings -> curve ranges
    B=tt['m_ClipBindingConstant']['genericBindings']
    bind=[]; ci=0
    for b in B:
        tid=b['typeID']; at=b['attribute']
        if tid==4: n={1:3,2:4,3:3,4:3}.get(at,1)
        else: n=1
        bind.append((tid,at,b['path'],ci,n)); ci+=n
    info['ncurves']=ci
    return value,bind,info
if __name__=="__main__":
    import sys
    tt=load_clip(sys.argv[1],sys.argv[2]); v,b,i=decode(tt); print(i, len(b), b[:3], b[-3:])
    print([round(v(k,0.5),3) for k in range(0,20)])
