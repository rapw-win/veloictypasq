#include <math.h>
// Overlay host: transparent topmost click-through window + D3D11 + Dear ImGui + acrylic blur
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <dwmapi.h>
#include <d3d11.h>
#include <d3dcompiler.h>
#include "imgui.h"
#include "backends/imgui_impl_dx11.h"
#include "menu.h"
#include "res.h"
#include <vector>
#include <stdint.h>
#include <wchar.h>

static ID3D11Device*           g_dev = nullptr;
static ID3D11DeviceContext*    g_ctx = nullptr;
static IDXGISwapChain*         g_swap = nullptr;
static ID3D11RenderTargetView* g_rtv = nullptr;
static ID3D11Texture2D*        g_backbuf = nullptr;
static UINT g_w = 0, g_h = 0;

// blur resources
static ID3D11Texture2D* g_copyTex = nullptr; static ID3D11ShaderResourceView* g_copySRV = nullptr;
static ID3D11Texture2D* g_bt[2] = {}; static ID3D11RenderTargetView* g_brtv[2] = {}; static ID3D11ShaderResourceView* g_bsrv[2] = {};
static ID3D11VertexShader* g_vs = nullptr; static ID3D11PixelShader* g_psDown = nullptr; static ID3D11PixelShader* g_psBlur = nullptr; static ID3D11PixelShader* g_psMix = nullptr; static ID3D11RasterizerState* g_rsScissor = nullptr;
static ID3D11Buffer* g_cb = nullptr; static ID3D11SamplerState* g_samp = nullptr;
static UINT g_bw = 0, g_bh = 0;
static ID3D11ShaderResourceView* g_avatarSRV = nullptr;
static ID3D11ShaderResourceView* g_logoSRV = nullptr;
static ID3D11ShaderResourceView* g_soldierSRV = nullptr;

static const char* kShader = R"(
cbuffer CB : register(b0) { float2 texel; float2 dir; float4 mixv; };
Texture2D tex0 : register(t0); Texture2D tex1 : register(t1); SamplerState smp : register(s0);
struct VO { float4 pos : SV_POSITION; float2 uv : TEXCOORD0; };
VO VS(uint id : SV_VertexID) {
    VO o; float2 uv = float2((id << 1) & 2, id & 2);
    o.uv = uv; o.pos = float4(uv * float2(2, -2) + float2(-1, 1), 0, 1); return o; }
float4 PSDown(VO i) : SV_Target {
    // 4-tap box downsample (13-tap like quality via bilinear)
    float2 t = texel * 0.5;
    float4 c = tex0.Sample(smp, i.uv + float2(-t.x, -t.y)) + tex0.Sample(smp, i.uv + float2(t.x, -t.y))
             + tex0.Sample(smp, i.uv + float2(-t.x, t.y)) + tex0.Sample(smp, i.uv + float2(t.x, t.y));
    return c * 0.25; }
float4 PSBlur(VO i) : SV_Target {
    // 9-tap gaussian using linear sampling (equivalent to 17 taps)
    const float w[5] = { 0.1964825501511404, 0.2969069646728344, 0.09447039785044732, 0.010381362401148057, 0.0 };
    const float o[5] = { 0.0, 1.411764705882353, 3.2941176470588234, 5.176470588235294, 0.0 };
    float4 c = tex0.Sample(smp, i.uv) * w[0];
    [unroll] for (int k = 1; k < 4; ++k) {
        c += tex0.Sample(smp, i.uv + dir * texel * o[k]) * w[k];
        c += tex0.Sample(smp, i.uv - dir * texel * o[k]) * w[k]; }
    return c; }
float4 PSMix(VO i) : SV_Target {
    // open/close animation: cross-fade sharp menu -> blurred menu
    return lerp(tex0.Sample(smp, i.uv), tex1.Sample(smp, i.uv), mixv.x); }
)";

static void ReleaseBlurTargets()
{
    if (g_copySRV) g_copySRV->Release(), g_copySRV = nullptr; if (g_copyTex) g_copyTex->Release(), g_copyTex = nullptr;
    for (int i = 0; i < 2; ++i) { if (g_bsrv[i]) g_bsrv[i]->Release(), g_bsrv[i] = nullptr; if (g_brtv[i]) g_brtv[i]->Release(), g_brtv[i] = nullptr; if (g_bt[i]) g_bt[i]->Release(), g_bt[i] = nullptr; }
}
static bool CreateBlurTargets()
{
    D3D11_TEXTURE2D_DESC bd; g_backbuf->GetDesc(&bd);
    D3D11_TEXTURE2D_DESC d = bd; d.BindFlags = D3D11_BIND_SHADER_RESOURCE; d.Usage = D3D11_USAGE_DEFAULT; d.CPUAccessFlags = 0; d.MiscFlags = 0;
    if (FAILED(g_dev->CreateTexture2D(&d, nullptr, &g_copyTex))) return false;
    g_dev->CreateShaderResourceView(g_copyTex, nullptr, &g_copySRV);
    g_bw = bd.Width / 2 ? bd.Width / 2 : 1; g_bh = bd.Height / 2 ? bd.Height / 2 : 1;
    for (int i = 0; i < 2; ++i) {
        D3D11_TEXTURE2D_DESC t = {}; t.Width = g_bw; t.Height = g_bh; t.MipLevels = 1; t.ArraySize = 1; t.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
        t.SampleDesc.Count = 1; t.Usage = D3D11_USAGE_DEFAULT; t.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;
        if (FAILED(g_dev->CreateTexture2D(&t, nullptr, &g_bt[i]))) return false;
        g_dev->CreateRenderTargetView(g_bt[i], nullptr, &g_brtv[i]);
        g_dev->CreateShaderResourceView(g_bt[i], nullptr, &g_bsrv[i]);
    }
    return true;
}
static bool CreateBlurPipeline()
{
    ID3DBlob *vsb = nullptr, *p1 = nullptr, *p2 = nullptr, *err = nullptr;
    if (FAILED(D3DCompile(kShader, strlen(kShader), nullptr, nullptr, nullptr, "VS", "vs_4_0", 0, 0, &vsb, &err))) return false;
    if (FAILED(D3DCompile(kShader, strlen(kShader), nullptr, nullptr, nullptr, "PSDown", "ps_4_0", 0, 0, &p1, &err))) return false;
    if (FAILED(D3DCompile(kShader, strlen(kShader), nullptr, nullptr, nullptr, "PSBlur", "ps_4_0", 0, 0, &p2, &err))) return false;
    g_dev->CreateVertexShader(vsb->GetBufferPointer(), vsb->GetBufferSize(), nullptr, &g_vs);
    g_dev->CreatePixelShader(p1->GetBufferPointer(), p1->GetBufferSize(), nullptr, &g_psDown);
    g_dev->CreatePixelShader(p2->GetBufferPointer(), p2->GetBufferSize(), nullptr, &g_psBlur);
    ID3DBlob* p3 = nullptr;
    if (SUCCEEDED(D3DCompile(kShader, strlen(kShader), nullptr, nullptr, nullptr, "PSMix", "ps_4_0", 0, 0, &p3, &err))) {
        g_dev->CreatePixelShader(p3->GetBufferPointer(), p3->GetBufferSize(), nullptr, &g_psMix); p3->Release(); }
    D3D11_RASTERIZER_DESC rd = {}; rd.FillMode = D3D11_FILL_SOLID; rd.CullMode = D3D11_CULL_NONE; rd.ScissorEnable = TRUE; rd.DepthClipEnable = TRUE;
    g_dev->CreateRasterizerState(&rd, &g_rsScissor);
    vsb->Release(); p1->Release(); p2->Release();
    D3D11_BUFFER_DESC cb = {}; cb.ByteWidth = 32; cb.Usage = D3D11_USAGE_DYNAMIC; cb.BindFlags = D3D11_BIND_CONSTANT_BUFFER; cb.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
    g_dev->CreateBuffer(&cb, nullptr, &g_cb);
    D3D11_SAMPLER_DESC sd = {}; sd.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR; sd.AddressU = sd.AddressV = sd.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP; sd.MaxLOD = D3D11_FLOAT32_MAX;
    g_dev->CreateSamplerState(&sd, &g_samp);
    return true;
}
static float g_mixT = 0.0f;
static void SetCB(float tx, float ty, float dx, float dy)
{
    D3D11_MAPPED_SUBRESOURCE m; if (SUCCEEDED(g_ctx->Map(g_cb, 0, D3D11_MAP_WRITE_DISCARD, 0, &m))) { float* f = (float*)m.pData; f[0] = tx; f[1] = ty; f[2] = dx; f[3] = dy; f[4] = g_mixT; f[5] = f[6] = f[7] = 0; g_ctx->Unmap(g_cb, 0); }
}
static void Pass(ID3D11PixelShader* ps, ID3D11ShaderResourceView* src, ID3D11RenderTargetView* dst, float tx, float ty, float dx, float dy)
{
    ID3D11ShaderResourceView* nullSRV = nullptr;
    g_ctx->PSSetShaderResources(0, 1, &nullSRV);
    g_ctx->OMSetRenderTargets(1, &dst, nullptr);
    SetCB(tx, ty, dx, dy);
    g_ctx->PSSetShader(ps, nullptr, 0);
    g_ctx->PSSetShaderResources(0, 1, &src);
    g_ctx->Draw(3, 0);
}
// ImDrawCallback: blur whatever has been drawn into the back buffer so far
static void BlurCallback(const ImDrawList*, const ImDrawCmd*)
{
    if (!g_copyTex) return;
    g_ctx->CopyResource(g_copyTex, g_backbuf);
    D3D11_VIEWPORT vp = {}; vp.Width = (float)g_bw; vp.Height = (float)g_bh; vp.MaxDepth = 1.0f;
    g_ctx->RSSetViewports(1, &vp);
    g_ctx->RSSetState(nullptr);
    g_ctx->OMSetBlendState(nullptr, nullptr, 0xFFFFFFFF);
    g_ctx->OMSetDepthStencilState(nullptr, 0);
    g_ctx->IASetInputLayout(nullptr);
    g_ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    g_ctx->VSSetShader(g_vs, nullptr, 0);
    g_ctx->GSSetShader(nullptr, nullptr, 0);
    g_ctx->PSSetConstantBuffers(0, 1, &g_cb);
    g_ctx->PSSetSamplers(0, 1, &g_samp);
    Pass(g_psDown, g_copySRV, g_brtv[0], 1.0f / g_w, 1.0f / g_h, 0, 0);
    const float tx = 1.0f / g_bw, ty = 1.0f / g_bh;
    for (int it = 0; it < 2; ++it) {
        float s = it == 0 ? 1.0f : 1.75f;
        Pass(g_psBlur, g_bsrv[0], g_brtv[1], tx, ty, s, 0);
        Pass(g_psBlur, g_bsrv[1], g_brtv[0], tx, ty, 0, s);
    }
    ID3D11ShaderResourceView* nullSRV = nullptr;
    g_ctx->PSSetShaderResources(0, 1, &nullSRV);
    g_ctx->OMSetRenderTargets(1, &g_rtv, nullptr);
}

// Post-process after the UI is rendered: blur the menu itself during the open/close animation.
static void AnimBlurMenu(float t, float x0, float y0, float x1, float y1)
{
    if (!g_copyTex || !g_psMix || !g_rsScissor) return;
    t = t * t * (3.0f - 2.0f * t);                         // smoothstep
    g_ctx->CopyResource(g_copyTex, g_backbuf);
    D3D11_VIEWPORT vp = {}; vp.Width = (float)g_bw; vp.Height = (float)g_bh; vp.MaxDepth = 1.0f;
    g_ctx->RSSetViewports(1, &vp);
    g_ctx->RSSetState(nullptr);
    g_ctx->OMSetBlendState(nullptr, nullptr, 0xFFFFFFFF);
    g_ctx->OMSetDepthStencilState(nullptr, 0);
    g_ctx->IASetInputLayout(nullptr);
    g_ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    g_ctx->VSSetShader(g_vs, nullptr, 0);
    g_ctx->GSSetShader(nullptr, nullptr, 0);
    g_ctx->PSSetConstantBuffers(0, 1, &g_cb);
    g_ctx->PSSetSamplers(0, 1, &g_samp);
    g_mixT = 0.0f;
    Pass(g_psDown, g_copySRV, g_brtv[0], 1.0f / g_w, 1.0f / g_h, 0, 0);
    const float tx = 1.0f / g_bw, ty = 1.0f / g_bh;
    for (int it = 0; it < 3; ++it) {
        float s = t * (1.0f + it * 1.25f);                  // radius grows with t (up to ~40 px)
        Pass(g_psBlur, g_bsrv[0], g_brtv[1], tx, ty, s, 0);
        Pass(g_psBlur, g_bsrv[1], g_brtv[0], tx, ty, 0, s);
    }
    // composite back into the back buffer, only inside the menu area
    ID3D11ShaderResourceView* nullSRV[2] = { nullptr, nullptr };
    g_ctx->PSSetShaderResources(0, 2, nullSRV);
    g_ctx->OMSetRenderTargets(1, &g_rtv, nullptr);
    D3D11_VIEWPORT fv = {}; fv.Width = (float)g_w; fv.Height = (float)g_h; fv.MaxDepth = 1.0f;
    g_ctx->RSSetViewports(1, &fv);
    D3D11_RECT sc = { (LONG)(x0 < 0 ? 0 : x0), (LONG)(y0 < 0 ? 0 : y0), (LONG)x1 + 1, (LONG)y1 + 1 };
    g_ctx->RSSetState(g_rsScissor);
    g_ctx->RSSetScissorRects(1, &sc);
    g_mixT = t < 1.0f ? (t * 4.0f > 1.0f ? 1.0f : t * 4.0f) : 1.0f;   // quickly switch to the blurred image, radius does the rest
    SetCB(0, 0, 0, 0);
    g_ctx->PSSetShader(g_psMix, nullptr, 0);
    ID3D11ShaderResourceView* srvs[2] = { g_copySRV, g_bsrv[0] };
    g_ctx->PSSetShaderResources(0, 2, srvs);
    g_ctx->Draw(3, 0);
    g_ctx->PSSetShaderResources(0, 2, nullSRV);
    g_ctx->RSSetState(nullptr);
}


// Keyboard for ImGui text fields. The overlay never takes focus (WS_EX_NOACTIVATE), so poll the keyboard.
static void FeedKeyboard(ImGuiIO& io, float dt)
{
    static bool prevKey[256] = {}; static float repT[256] = {};
    bool want = io.WantTextInput;
    bool ctrl = (GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0, shift = (GetAsyncKeyState(VK_SHIFT) & 0x8000) != 0;
    io.AddKeyEvent(ImGuiMod_Ctrl, want && ctrl); io.AddKeyEvent(ImGuiMod_Shift, want && shift);
    struct KM { int vk; ImGuiKey k; };
    static const KM map[] = { { VK_BACK, ImGuiKey_Backspace }, { VK_DELETE, ImGuiKey_Delete }, { VK_LEFT, ImGuiKey_LeftArrow }, { VK_RIGHT, ImGuiKey_RightArrow },
        { VK_HOME, ImGuiKey_Home }, { VK_END, ImGuiKey_End }, { VK_RETURN, ImGuiKey_Enter }, { VK_ESCAPE, ImGuiKey_Escape }, { VK_UP, ImGuiKey_UpArrow }, { VK_DOWN, ImGuiKey_DownArrow },
        { 'A', ImGuiKey_A }, { 'C', ImGuiKey_C }, { 'V', ImGuiKey_V }, { 'X', ImGuiKey_X }, { 'Z', ImGuiKey_Z }, { 'Y', ImGuiKey_Y } };
    static bool prevMap[IM_ARRAYSIZE(map)] = {};
    for (int i = 0; i < IM_ARRAYSIZE(map); ++i) {
        bool d = want && (GetAsyncKeyState(map[i].vk) & 0x8000) != 0;
        if (d != prevMap[i]) { io.AddKeyEvent(map[i].k, d); prevMap[i] = d; }
    }
    if (!want || ctrl) { for (int vk = 0; vk < 256; ++vk) prevKey[vk] = (GetAsyncKeyState(vk) & 0x8000) != 0; return; }
    HKL hkl = GetKeyboardLayout(GetWindowThreadProcessId(GetForegroundWindow(), nullptr));
    BYTE ks[256] = {};
    if (shift) ks[VK_SHIFT] = 0x80;
    if (GetKeyState(VK_CAPITAL) & 1) ks[VK_CAPITAL] = 0x01;
    if ((GetAsyncKeyState(VK_RMENU) & 0x8000)) { ks[VK_CONTROL] = 0x80; ks[VK_MENU] = 0x80; }   // AltGr
    for (int vk = 0x20; vk < 0xFF; ++vk) {
        if ((vk >= VK_PRIOR && vk <= VK_HELP) || (vk >= VK_LWIN && vk <= VK_SLEEP) || (vk >= VK_F1 && vk <= 0x87) || vk == VK_NUMLOCK || vk == VK_SCROLL || (vk >= VK_LSHIFT && vk <= VK_RMENU)) continue;
        if (vk == VK_NUMPAD0) continue;   // menu hotkey
        bool d = (GetAsyncKeyState(vk) & 0x8000) != 0;
        bool fire = false;
        if (d && !prevKey[vk]) { fire = true; repT[vk] = 0.40f; }
        else if (d) { repT[vk] -= dt; if (repT[vk] <= 0.0f) { fire = true; repT[vk] = 0.035f; } }
        prevKey[vk] = d;
        if (!fire) continue;
        WCHAR buf[8]; int n = ToUnicodeEx((UINT)vk, MapVirtualKeyExW((UINT)vk, MAPVK_VK_TO_VSC, hkl), ks, buf, 8, 4, hkl);
        for (int i = 0; i < n; ++i) if (buf[i] >= 0x20) io.AddInputCharacterUTF16(buf[i]);
    }
}

#ifdef INAPP
static void InappCreate(UINT w, UINT h); static void InappRelease();
static UINT g_reqW = 16, g_reqH = 16;
#endif
static void CreateRT()
{
#ifdef INAPP
    InappCreate(g_reqW, g_reqH); CreateBlurTargets(); return;
#endif
    g_swap->GetBuffer(0, IID_PPV_ARGS(&g_backbuf));
    g_dev->CreateRenderTargetView(g_backbuf, nullptr, &g_rtv);
    D3D11_TEXTURE2D_DESC bd; g_backbuf->GetDesc(&bd); g_w = bd.Width; g_h = bd.Height;
    CreateBlurTargets();
}
static void CleanupRT()
{
    ReleaseBlurTargets();
    if (g_rtv) g_rtv->Release(), g_rtv = nullptr;
    if (g_backbuf) g_backbuf->Release(), g_backbuf = nullptr;
#ifdef INAPP
    InappRelease();
#endif
}

// ---- DWM blur-behind window placed under the menu (blurs the game behind the transparent menu)
struct ACCENTPOLICY { int AccentState; int AccentFlags; unsigned int GradientColor; int AnimationId; };
struct WINCOMPATTRDATA { int Attribute; PVOID Data; SIZE_T SizeOfData; };
typedef BOOL(WINAPI* pSetWindowCompositionAttribute)(HWND, WINCOMPATTRDATA*);
static HWND g_backdropWnd = nullptr;
static const BYTE BLUR_STRENGTH = 255; // background blur strength: 255 = full Windows blur, 0 = no blur
static HWND g_wmBlurWnd = nullptr, g_wmBlurWnd2 = nullptr;
static HWND g_barBlurWnd = nullptr;    // blur behind the bottom bar
static HWND g_popBlurWnd = nullptr;    // blur behind the profile popup     // blur behind the watermark
static HWND g_subBlurWnd = nullptr;    // blur behind the profile popup value list
static LRESULT WINAPI BackdropProc(HWND h, UINT m, WPARAM w, LPARAM l)
{
    switch (m) {
    case WM_MOUSEACTIVATE: return MA_NOACTIVATE;
    case WM_ERASEBKGND: return 1;
    case WM_PAINT: { PAINTSTRUCT ps; BeginPaint(h, &ps); EndPaint(h, &ps); return 0; }
    case WM_NCHITTEST: return HTTRANSPARENT;
    }
    return DefWindowProcW(h, m, w, l);
}
static void CreateBackdrop(HINSTANCE hInst)
{
    WNDCLASSEXW wc = { sizeof(wc), 0, BackdropProc, 0, 0, hInst, nullptr, LoadCursor(nullptr, IDC_ARROW), (HBRUSH)GetStockObject(BLACK_BRUSH), nullptr, L"AnesthysiaBackdrop", nullptr };
    RegisterClassExW(&wc);
    auto make = [&]() -> HWND {
        HWND w = CreateWindowExW(WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE, wc.lpszClassName, L"", WS_POPUP, 0, 0, 10, 10, nullptr, nullptr, hInst, nullptr);
        auto fn = (pSetWindowCompositionAttribute)GetProcAddress(GetModuleHandleW(L"user32.dll"), "SetWindowCompositionAttribute");
        if (fn) {
            ACCENTPOLICY ap = { 3 /*ACCENT_ENABLE_BLURBEHIND*/, 0, 0, 0 };
            WINCOMPATTRDATA d = { 19 /*WCA_ACCENT_POLICY*/, &ap, sizeof(ap) };
            fn(w, &d);
        }
        if (BLUR_STRENGTH < 255) {   // Windows blur radius is fixed, so weaken it by making the blur window see-through
            SetWindowLongPtrW(w, GWL_EXSTYLE, GetWindowLongPtrW(w, GWL_EXSTYLE) | WS_EX_LAYERED);
            SetLayeredWindowAttributes(w, 0, BLUR_STRENGTH, LWA_ALPHA);
        }
        int pref = 1; /*DWMWCP_DONOTROUND*/ DwmSetWindowAttribute(w, 33 /*DWMWA_WINDOW_CORNER_PREFERENCE*/, &pref, sizeof(pref));
        return w;
    };
    g_backdropWnd = make();
    g_wmBlurWnd = make();
    g_wmBlurWnd2 = make();
    g_popBlurWnd = make();
    g_subBlurWnd = make();
    g_barBlurWnd = make();
}
static void UpdateBackdrop(HWND overlay)
{
    static bool shown = false; static int lx = -1, ly = -1, lw = -1, lh = -1, la = -1;
    float x, y, w, h, r;
    if (!g_backdropWnd) return;
    if (Menu_GetBackdrop(&x, &y, &w, &h, &r)) {
        // Inset the blur window so that even its square corners lie inside the menu's rounded corners
        // (corner point of a rect inset by k is inside an arc of radius r when k >= r*(1-1/sqrt2) ~ 0.3r).
        int k = (int)ceilf(r * 0.33f) + 1;
        int ix = (int)floorf(x + 0.5f) + k, iy = (int)floorf(y + 0.5f) + k, iw = (int)(w + 0.5f) - 2 * k, ih = (int)(h + 0.5f) - 2 * k;
        if (iw < 1) iw = 1; if (ih < 1) ih = 1;
        if (iw != lw || ih != lh) {
            int d = (int)((r - k) * 2.0f); if (d < 0) d = 0;
            SetWindowRgn(g_backdropWnd, CreateRoundRectRgn(0, 0, iw + 1, ih + 1, d, d), TRUE);
        }
        int a = (int)(Menu_GetBackdropAlpha() * 255.0f + 0.5f);
        (void)a;
        if (!shown || ix != lx || iy != ly || iw != lw || ih != lh)
            SetWindowPos(g_backdropWnd, overlay, ix, iy, iw, ih, SWP_NOACTIVATE | SWP_SHOWWINDOW | SWP_NOREDRAW);
        lx = ix; ly = iy; lw = iw; lh = ih; shown = true;
    } else if (shown) { ShowWindow(g_backdropWnd, SW_HIDE); shown = false; la = -1; }
}

// Background blur behind the watermark pill (Figma: background blur 21.1).
// DWM accent blur ignores window regions on recent Windows builds (it showed up as square corners),
// so the pill is covered by two plain rectangles that both lie completely inside the pill:
//   A = full height, between the two end-cap centres;  B = wider, but inset vertically so its corners stay inside the caps.
static void UpdateWmBlur(HWND overlay)
{
    static bool shown = false; static RECT last[2] = {};
    float x, y, w, h;
    if (!g_wmBlurWnd || !g_wmBlurWnd2) return;
    HWND wnds[2] = { g_wmBlurWnd, g_wmBlurWnd2 };
    if (Menu_GetWmBackdrop(&x, &y, &w, &h)) {
        float R = h * 0.5f;
        float kx = R * 0.30f, ky = R - sqrtf(R * R - (R - kx) * (R - kx));   // corner of B on the cap circle
        RECT rc[2];
        rc[0] = { (LONG)ceilf(x + R), (LONG)ceilf(y + 1), (LONG)floorf(x + w - R), (LONG)floorf(y + h - 1) };
        rc[1] = { (LONG)ceilf(x + kx + 1), (LONG)ceilf(y + ky + 1), (LONG)floorf(x + w - kx - 1), (LONG)floorf(y + h - ky - 1) };
        for (int i = 0; i < 2; ++i) {
            RECT r = rc[i];
            if (r.right - r.left < 1 || r.bottom - r.top < 1) { ShowWindow(wnds[i], SW_HIDE); continue; }
            if (!shown || memcmp(&r, &last[i], sizeof(RECT)) != 0)
                SetWindowPos(wnds[i], overlay, r.left, r.top, r.right - r.left, r.bottom - r.top, SWP_NOACTIVATE | SWP_SHOWWINDOW | SWP_NOREDRAW);
            last[i] = r;
        }
        shown = true;
    } else if (shown) { ShowWindow(wnds[0], SW_HIDE); ShowWindow(wnds[1], SW_HIDE); shown = false; }
}

// blur behind the profile popup (inset so the square blur never shows outside the rounded corners)
// rounded blur window behind a rect (profile popup / bottom bar)
struct RoundBlur { bool shown = false; int lx = -1, ly = -1, lw = -1, lh = -1; };
static void UpdateRoundBlur(HWND wnd, HWND overlay, RoundBlur& st, bool (*get)(float*, float*, float*, float*, float*))
{
    float x, y, w, h, r;
    if (!wnd) return;
    if (get(&x, &y, &w, &h, &r)) {
        int k = 1;   // the window region is rounded, so no corner inset is needed
        int ix = (int)floorf(x + 0.5f) + k, iy = (int)floorf(y + 0.5f) + k, iw = (int)(w + 0.5f) - 2 * k, ih = (int)(h + 0.5f) - 2 * k;
        if (iw < 1) iw = 1; if (ih < 1) ih = 1;
        if (iw != st.lw || ih != st.lh) { int d = (int)((r - k) * 2.0f); if (d < 0) d = 0; SetWindowRgn(wnd, CreateRoundRectRgn(0, 0, iw + 1, ih + 1, d, d), TRUE); }
        if (!st.shown || ix != st.lx || iy != st.ly || iw != st.lw || ih != st.lh)
            SetWindowPos(wnd, overlay, ix, iy, iw, ih, SWP_NOACTIVATE | SWP_SHOWWINDOW | SWP_NOREDRAW);
        st.lx = ix; st.ly = iy; st.lw = iw; st.lh = ih; st.shown = true;
    } else if (st.shown) { ShowWindow(wnd, SW_HIDE); st.shown = false; }
}
static void UpdatePopBlur(HWND overlay) { static RoundBlur st; UpdateRoundBlur(g_popBlurWnd, overlay, st, Menu_GetPopupBackdrop); }
static void UpdateBarBlur(HWND overlay) { static RoundBlur st; UpdateRoundBlur(g_barBlurWnd, overlay, st, Menu_GetBarBackdrop); }
static void UpdateSubBlur(HWND overlay) { static RoundBlur st; UpdateRoundBlur(g_subBlurWnd, overlay, st, Menu_GetSubBackdrop); }

static volatile float g_wheel = 0.0f; static volatile bool g_menuMouse = false;
#ifdef INAPP
// ---- "In app" build: the overlay is a layered CHILD window of the chosen application, so window capture of that app records it
static HWND g_target = nullptr;
static ID3D11Texture2D* g_stage = nullptr;
static ID3D11Texture2D* g_stage2 = nullptr;
static int g_stageN = 0;
static HDC g_memDC = nullptr; static HBITMAP g_dib = nullptr; static void* g_dibBits = nullptr;
struct PickItem { HWND h; };
static std::vector<HWND>* g_pickList = nullptr;
static BOOL CALLBACK PickEnum(HWND h, LPARAM)
{
    if (!IsWindowVisible(h) || GetWindow(h, GW_OWNER)) return TRUE;
    if (GetWindowLongPtrW(h, GWL_EXSTYLE) & WS_EX_TOOLWINDOW) return TRUE;
    int cloaked = 0; DwmGetWindowAttribute(h, 14 /*DWMWA_CLOAKED*/, &cloaked, sizeof(cloaked)); if (cloaked) return TRUE;
    if (GetWindowTextLengthW(h) <= 0) return TRUE;
    DWORD pid = 0; GetWindowThreadProcessId(h, &pid); if (pid == GetCurrentProcessId()) return TRUE;
    RECT r; GetClientRect(h, &r); if (r.right - r.left < 64 || r.bottom - r.top < 64) return TRUE;
    g_pickList->push_back(h); return TRUE;
}
static HWND g_pickLB = nullptr, g_pickDone = nullptr; static bool g_pickClosed = false;
static std::vector<HWND> g_pickWnds;
static void PickFill()
{
    g_pickWnds.clear(); g_pickList = &g_pickWnds; EnumWindows(PickEnum, 0);
    SendMessageW(g_pickLB, LB_RESETCONTENT, 0, 0);
    for (HWND h : g_pickWnds) {
        wchar_t t[256] = {}, exe[MAX_PATH] = {}, line[400];
        GetWindowTextW(h, t, 256);
        DWORD pid = 0; GetWindowThreadProcessId(h, &pid);
        HANDLE pr = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
        if (pr) { DWORD n = MAX_PATH; QueryFullProcessImageNameW(pr, 0, exe, &n); CloseHandle(pr); }
        const wchar_t* base = wcsrchr(exe, L'\\'); base = base ? base + 1 : exe;
        swprintf(line, 400, L"%ls    [%ls]", t, base[0] ? base : L"?");
        SendMessageW(g_pickLB, LB_ADDSTRING, 0, (LPARAM)line);
    }
    if (!g_pickWnds.empty()) SendMessageW(g_pickLB, LB_SETCURSEL, 0, 0);
}
static LRESULT WINAPI PickProc(HWND h, UINT m, WPARAM w, LPARAM l)
{
    switch (m) {
    case WM_COMMAND:
        if (LOWORD(w) == 1 || (LOWORD(w) == 3 && HIWORD(w) == LBN_DBLCLK)) {
            int i = (int)SendMessageW(g_pickLB, LB_GETCURSEL, 0, 0);
            if (i >= 0 && i < (int)g_pickWnds.size()) { g_target = g_pickWnds[i]; DestroyWindow(h); }
        } else if (LOWORD(w) == 2) PickFill();
        return 0;
    case WM_CTLCOLORLISTBOX: case WM_CTLCOLORSTATIC: case WM_CTLCOLORBTN: {
        static HBRUSH br = CreateSolidBrush(RGB(0x16, 0x17, 0x1D));
        SetTextColor((HDC)w, RGB(0xE6, 0xE7, 0xEB)); SetBkColor((HDC)w, RGB(0x16, 0x17, 0x1D)); return (LRESULT)br; }
    case WM_CLOSE: g_pickClosed = true; DestroyWindow(h); return 0;
    case WM_DESTROY: g_pickDone = h; return 0;
    }
    return DefWindowProcW(h, m, w, l);
}
static HWND PickWindow(HINSTANCE hInst)
{
    WNDCLASSEXW wc = { sizeof(wc), 0, PickProc, 0, 0, hInst, nullptr, LoadCursor(nullptr, IDC_ARROW), CreateSolidBrush(RGB(0x0F, 0x10, 0x15)), nullptr, L"AnesthysiaPick", nullptr };
    RegisterClassExW(&wc);
    const int W = 560, H = 420;
    int sx = (GetSystemMetrics(SM_CXSCREEN) - W) / 2, sy = (GetSystemMetrics(SM_CYSCREEN) - H) / 2;
    HWND d = CreateWindowExW(0, wc.lpszClassName, L"Anesthysia - select application", WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU, sx, sy, W, H, nullptr, nullptr, hInst, nullptr);
    BOOL dark = TRUE; DwmSetWindowAttribute(d, 20 /*DWMWA_USE_IMMERSIVE_DARK_MODE*/, &dark, sizeof(dark));
    HFONT f = CreateFontW(-15, 0, 0, 0, FW_NORMAL, 0, 0, 0, DEFAULT_CHARSET, 0, 0, CLEARTYPE_QUALITY, 0, L"Segoe UI");
    RECT cr; GetClientRect(d, &cr); int cw = cr.right, ch = cr.bottom;
    HWND lab = CreateWindowExW(0, L"STATIC", L"Choose the window the overlay will be drawn inside:", WS_CHILD | WS_VISIBLE, 14, 12, cw - 28, 20, d, nullptr, hInst, nullptr);
    g_pickLB = CreateWindowExW(0, L"LISTBOX", L"", WS_CHILD | WS_VISIBLE | WS_VSCROLL | LBS_NOTIFY | LBS_NOINTEGRALHEIGHT, 14, 38, cw - 28, ch - 98, d, (HMENU)3, hInst, nullptr);
    HWND bR = CreateWindowExW(0, L"BUTTON", L"Refresh", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, cw - 14 - 230, ch - 48, 110, 34, d, (HMENU)2, hInst, nullptr);
    HWND bO = CreateWindowExW(0, L"BUTTON", L"Select", WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON, cw - 14 - 110, ch - 48, 110, 34, d, (HMENU)1, hInst, nullptr);
    for (HWND c : { lab, g_pickLB, bR, bO }) SendMessageW(c, WM_SETFONT, (WPARAM)f, TRUE);
    PickFill();
    ShowWindow(d, SW_SHOW); SetForegroundWindow(d);
    MSG msg;
    while (!g_pickDone && GetMessageW(&msg, nullptr, 0, 0)) {
        if (msg.message == WM_KEYDOWN && msg.wParam == VK_RETURN) { SendMessageW(d, WM_COMMAND, 1, 0); continue; }
        TranslateMessage(&msg); DispatchMessageW(&msg);
    }
    return g_pickClosed ? nullptr : g_target;
}
static void InappRelease()
{
    if (g_stage) g_stage->Release(), g_stage = nullptr;
    if (g_stage2) g_stage2->Release(), g_stage2 = nullptr;
    g_stageN = 0;
    if (g_dib) DeleteObject(g_dib), g_dib = nullptr, g_dibBits = nullptr;
}
static void InappCreate(UINT w, UINT h)
{
    g_w = w; g_h = h;
    D3D11_TEXTURE2D_DESC t = {}; t.Width = w; t.Height = h; t.MipLevels = 1; t.ArraySize = 1; t.Format = DXGI_FORMAT_R8G8B8A8_UNORM; t.SampleDesc.Count = 1;
    t.Usage = D3D11_USAGE_DEFAULT; t.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;
    g_dev->CreateTexture2D(&t, nullptr, &g_backbuf);
    g_dev->CreateRenderTargetView(g_backbuf, nullptr, &g_rtv);
    t.Usage = D3D11_USAGE_STAGING; t.BindFlags = 0; t.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
    g_dev->CreateTexture2D(&t, nullptr, &g_stage);
    g_dev->CreateTexture2D(&t, nullptr, &g_stage2);
    BITMAPINFO bi = {}; bi.bmiHeader.biSize = sizeof(bi.bmiHeader); bi.bmiHeader.biWidth = (LONG)w; bi.bmiHeader.biHeight = -(LONG)h; bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32; bi.bmiHeader.biCompression = BI_RGB;
    if (!g_memDC) g_memDC = CreateCompatibleDC(nullptr);
    g_dib = CreateDIBSection(g_memDC, &bi, DIB_RGB_COLORS, &g_dibBits, nullptr, 0);
    SelectObject(g_memDC, g_dib);
}
static void InappPresent(HWND hwnd)
{
    // double-buffered readback: copy this frame, read the previous one (no GPU stall)
    ID3D11Texture2D* cur = (g_stageN & 1) ? g_stage2 : g_stage;
    ID3D11Texture2D* prv = (g_stageN & 1) ? g_stage : g_stage2;
    g_ctx->CopyResource(cur, g_backbuf);
    if (g_stageN++ == 0) { g_ctx->Flush(); return; }
    D3D11_MAPPED_SUBRESOURCE m;
    if (FAILED(g_ctx->Map(prv, 0, D3D11_MAP_READ, 0, &m))) return;
    for (UINT y = 0; y < g_h; ++y) {   // RGBA (premultiplied) -> BGRA
        const uint32_t* s = (const uint32_t*)((const uint8_t*)m.pData + (size_t)y * m.RowPitch);
        uint32_t* d = (uint32_t*)g_dibBits + (size_t)y * g_w;
        for (UINT x = 0; x < g_w; ++x) { uint32_t v = s[x]; d[x] = (v & 0xFF00FF00u) | ((v & 0xFFu) << 16) | ((v >> 16) & 0xFFu); }
    }
    g_ctx->Unmap(prv, 0);
    SIZE sz = { (LONG)g_w, (LONG)g_h }; POINT src = { 0, 0 };
    BLENDFUNCTION bf = { AC_SRC_OVER, 0, 255, AC_SRC_ALPHA };
    UpdateLayeredWindow(hwnd, nullptr, nullptr, &sz, g_memDC, &src, 0, &bf, ULW_ALPHA);
}
#endif
static LRESULT CALLBACK MouseHook(int code, WPARAM wp, LPARAM lp);
#ifdef INAPP
static DWORD WINAPI HookThread(LPVOID)   // LL hook on its own thread: render stalls never delay system mouse input
{
    HHOOK h = SetWindowsHookExW(WH_MOUSE_LL, MouseHook, GetModuleHandleW(nullptr), 0);
    MSG m; while (GetMessageW(&m, nullptr, 0, 0) > 0) { TranslateMessage(&m); DispatchMessageW(&m); }
    if (h) UnhookWindowsHookEx(h);
    return 0;
}
#endif
static LRESULT CALLBACK MouseHook(int code, WPARAM wp, LPARAM lp)   // wheel for the menu (overlay never has focus)
{
    if (code == HC_ACTION && wp == WM_MOUSEWHEEL) {
        g_wheel += (short)HIWORD(((MSLLHOOKSTRUCT*)lp)->mouseData) / (float)WHEEL_DELTA;
        if (g_menuMouse) return 1;   // menu under the cursor: don't scroll the game / window below
    }
    return CallNextHookEx(nullptr, code, wp, lp);
}
static LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg) {
    case WM_MOUSEACTIVATE: return MA_NOACTIVATE;
    case WM_SIZE:
        if (g_dev && g_swap && wParam != SIZE_MINIMIZED) { CleanupRT(); g_swap->ResizeBuffers(0, (UINT)LOWORD(lParam), (UINT)HIWORD(lParam), DXGI_FORMAT_UNKNOWN, 0); CreateRT(); }
        return 0;
    case WM_DESTROY: PostQuitMessage(0); return 0;
    }
    return DefWindowProcW(hWnd, msg, wParam, lParam);
}

int WINAPI wWinMain(HINSTANCE hInst, HINSTANCE, PWSTR, int)
{
    SetProcessDPIAware();
    int sw = GetSystemMetrics(SM_CXSCREEN), sh = GetSystemMetrics(SM_CYSCREEN);
    WNDCLASSEXW wc = { sizeof(wc), CS_CLASSDC, WndProc, 0, 0, hInst, nullptr, LoadCursor(nullptr, IDC_ARROW), nullptr, nullptr, L"NLMenuOverlay", nullptr };
    RegisterClassExW(&wc);
#ifdef INAPP
    if (!PickWindow(hInst)) return 0;
    RECT tcr; GetClientRect(g_target, &tcr);
    g_reqW = (UINT)(tcr.right > 16 ? tcr.right : 16); g_reqH = (UINT)(tcr.bottom > 16 ? tcr.bottom : 16);
    HWND hwnd = CreateWindowExW(WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_NOACTIVATE, wc.lpszClassName, L"Anesthysia", WS_CHILD | WS_CLIPSIBLINGS, 0, 0, (int)g_reqW, (int)g_reqH, g_target, nullptr, hInst, nullptr);
    if (!hwnd) { MessageBoxW(nullptr, L"Failed to attach to the selected window", L"Anesthysia", MB_ICONERROR); return 1; }
    SetWindowPos(hwnd, HWND_TOP, 0, 0, (int)g_reqW, (int)g_reqH, SWP_NOACTIVATE | SWP_SHOWWINDOW);
    DWORD g_tgtTid = GetWindowThreadProcessId(g_target, nullptr);
    AttachThreadInput(GetCurrentThreadId(), g_tgtTid, FALSE);   // cross-process child shares the input queue -> detach so the game's mouse isn't throttled by our frame loop
    (void)sw; (void)sh;
#else
    DWORD ex = WS_EX_TOPMOST | WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE;
    HWND hwnd = CreateWindowExW(ex, wc.lpszClassName, L"Anesthysia", WS_POPUP, 0, 0, sw, sh, nullptr, nullptr, hInst, nullptr);
    SetLayeredWindowAttributes(hwnd, RGB(0, 0, 0), 255, LWA_ALPHA);
    CreateBackdrop(hInst);
    MARGINS margins = { -1, -1, -1, -1 };
    DwmExtendFrameIntoClientArea(hwnd, &margins);
#endif

    DXGI_SWAP_CHAIN_DESC sd = {};
    sd.BufferCount = 2; sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM; sd.BufferDesc.RefreshRate.Numerator = 0; sd.BufferDesc.RefreshRate.Denominator = 1;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT; sd.OutputWindow = hwnd; sd.SampleDesc.Count = 1; sd.Windowed = TRUE; sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
    sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
    const D3D_FEATURE_LEVEL fls[2] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0 }; D3D_FEATURE_LEVEL fl;
#ifdef INAPP
    HRESULT hr = D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, fls, 2, D3D11_SDK_VERSION, &g_dev, &fl, &g_ctx);
    if (FAILED(hr)) hr = D3D11CreateDevice(nullptr, D3D_DRIVER_TYPE_WARP, nullptr, 0, fls, 2, D3D11_SDK_VERSION, &g_dev, &fl, &g_ctx);
    (void)sd;
#else
    HRESULT hr = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, fls, 2, D3D11_SDK_VERSION, &sd, &g_swap, &g_dev, &fl, &g_ctx);
    if (hr == DXGI_ERROR_UNSUPPORTED) hr = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_WARP, nullptr, 0, fls, 2, D3D11_SDK_VERSION, &sd, &g_swap, &g_dev, &fl, &g_ctx);
#endif
    if (FAILED(hr)) { MessageBoxW(nullptr, L"Failed to create D3D11 device", L"Anesthysia", MB_ICONERROR); return 1; }
    CreateRT();
    CreateBlurPipeline();
    ShowWindow(hwnd, SW_SHOWNOACTIVATE);
    UpdateWindow(hwnd);

    // logo texture
    {
        D3D11_TEXTURE2D_DESC t = {}; t.Width = logo_w; t.Height = logo_h; t.MipLevels = 1; t.ArraySize = 1; t.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
        t.SampleDesc.Count = 1; t.Usage = D3D11_USAGE_DEFAULT; t.BindFlags = D3D11_BIND_SHADER_RESOURCE;
        D3D11_SUBRESOURCE_DATA sub = { logo_rgba, (UINT)logo_w * 4, 0 }; ID3D11Texture2D* tex = nullptr;
        if (SUCCEEDED(g_dev->CreateTexture2D(&t, &sub, &tex))) { g_dev->CreateShaderResourceView(tex, nullptr, &g_logoSRV); tex->Release(); }
    }
    // player preview model texture
    {
        D3D11_TEXTURE2D_DESC t = {}; t.Width = soldier_w; t.Height = soldier_h; t.MipLevels = 1; t.ArraySize = 1; t.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
        t.SampleDesc.Count = 1; t.Usage = D3D11_USAGE_DEFAULT; t.BindFlags = D3D11_BIND_SHADER_RESOURCE;
        D3D11_SUBRESOURCE_DATA sub = { soldier_rgba, (UINT)soldier_w * 4, 0 }; ID3D11Texture2D* tex = nullptr;
        if (SUCCEEDED(g_dev->CreateTexture2D(&t, &sub, &tex))) { g_dev->CreateShaderResourceView(tex, nullptr, &g_soldierSRV); tex->Release(); }
    }
    // avatar texture
    {
        D3D11_TEXTURE2D_DESC t = {}; t.Width = avatar_w; t.Height = avatar_h; t.MipLevels = 1; t.ArraySize = 1; t.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
        t.SampleDesc.Count = 1; t.Usage = D3D11_USAGE_DEFAULT; t.BindFlags = D3D11_BIND_SHADER_RESOURCE;
        D3D11_SUBRESOURCE_DATA sub = { avatar_rgba, (UINT)avatar_w * 4, 0 }; ID3D11Texture2D* tex = nullptr;
        if (SUCCEEDED(g_dev->CreateTexture2D(&t, &sub, &tex))) { g_dev->CreateShaderResourceView(tex, nullptr, &g_avatarSRV); tex->Release(); }
    }

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr; io.LogFilename = nullptr;
    io.ConfigFlags |= ImGuiConfigFlags_NoMouseCursorChange;
    ImGui_ImplDX11_Init(g_dev, g_ctx);
    Menu_LoadFonts();

    LARGE_INTEGER freq, last; QueryPerformanceFrequency(&freq); QueryPerformanceCounter(&last);
    bool clickThrough = true, prevNum1 = false, running = true;
#ifdef INAPP
    HHOOK mhook = nullptr; CreateThread(nullptr, 0, HookThread, nullptr, 0, nullptr);
#else
    HHOOK mhook = SetWindowsHookExW(WH_MOUSE_LL, MouseHook, hInst, 0);
#endif
    Menu_RequireLoader();
    while (running) {
        MSG msg;
        while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) { TranslateMessage(&msg); DispatchMessageW(&msg); if (msg.message == WM_QUIT) running = false; }
        if (!running) break;
#ifdef INAPP
        if (!IsWindow(g_target)) break;
        if (IsIconic(g_target)) { Sleep(50); continue; }
        {
            RECT r; GetClientRect(g_target, &r);
            UINT nw = (UINT)(r.right > 16 ? r.right : 16), nh = (UINT)(r.bottom > 16 ? r.bottom : 16);
            static int zt = 0;
            if (nw != g_w || nh != g_h) { CleanupRT(); g_reqW = nw; g_reqH = nh; CreateRT(); SetWindowPos(hwnd, HWND_TOP, 0, 0, (int)nw, (int)nh, SWP_NOACTIVATE | SWP_SHOWWINDOW); }
            else if (++zt >= 30) { zt = 0; SetWindowPos(hwnd, HWND_TOP, 0, 0, 0, 0, SWP_NOACTIVATE | SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW); AttachThreadInput(GetCurrentThreadId(), g_tgtTid, FALSE); }   // stay above the game's own child windows
        }
#endif

        // hotkeys (global): DELETE = open/close, F10 = exit
        bool num1 = (GetAsyncKeyState(VK_DELETE) & 0x8000) != 0;
        if (num1 && !prevNum1 && !Menu_WantsUnload()) Menu_Toggle();
        prevNum1 = num1;
        { static bool prevTick = false; bool t = (GetAsyncKeyState(VK_OEM_3) & 0x8000) != 0; if (t && !prevTick) Menu_ToggleTextWm(); prevTick = t; }   // ` toggles the text watermark
        if (GetAsyncKeyState(VK_HOME) & 0x8000) Menu_StartLoader(false);
        else if (GetAsyncKeyState(VK_END) & 0x8000) Menu_StartLoader(true);
        if (GetAsyncKeyState(VK_MENU) & 0x8000) Menu_SkipLoader();   // ALT: instant load (no-op once the menu is loaded)
        if (GetAsyncKeyState(VK_F10) & 1) break;
        if (Menu_UnloadReady()) break;   // Unload: wait for the close animation, then exit

        LARGE_INTEGER now; QueryPerformanceCounter(&now);
        float dt = (float)(now.QuadPart - last.QuadPart) / (float)freq.QuadPart; last = now;

        MenuPlatform mp; mp.avatarTex = (ImTextureID)(intptr_t)g_avatarSRV; mp.logoTex = (ImTextureID)(intptr_t)g_logoSRV; mp.soldierTex = (ImTextureID)(intptr_t)g_soldierSRV; mp.blurTex = (ImTextureID)(intptr_t)g_bsrv[0]; mp.blurCallback = BlurCallback;
        Menu_SetPlatform(mp);

        io.DisplaySize = ImVec2((float)g_w, (float)g_h);
        io.DeltaTime = dt > 0 ? dt : 1.0f / 60.0f;
        POINT pt; GetCursorPos(&pt); ScreenToClient(hwnd, &pt);
        io.AddMousePosEvent((float)pt.x, (float)pt.y);
        FeedKeyboard(io, io.DeltaTime);
        io.AddMouseButtonEvent(0, (GetAsyncKeyState(GetSystemMetrics(SM_SWAPBUTTON) ? VK_RBUTTON : VK_LBUTTON) & 0x8000) != 0);
        io.AddMouseButtonEvent(1, (GetAsyncKeyState(GetSystemMetrics(SM_SWAPBUTTON) ? VK_LBUTTON : VK_RBUTTON) & 0x8000) != 0);
        if (g_wheel != 0.0f) { io.AddMouseWheelEvent(0.0f, g_wheel); g_wheel = 0.0f; }

        ImGui_ImplDX11_NewFrame();
        ImGui::NewFrame();
        {   // game keys for the crosshair watermark (global polling, works while the game has focus)
            auto K = [](int vk) { return (GetAsyncKeyState(vk) & 0x8000) != 0; };
            Menu_SetGameKeys(K(GetSystemMetrics(SM_SWAPBUTTON) ? VK_RBUTTON : VK_LBUTTON), K(GetSystemMetrics(SM_SWAPBUTTON) ? VK_LBUTTON : VK_RBUTTON), K('W'), K('A'), K('S'), K('D'), K(VK_SPACE));
        }
        Menu_Frame(io.DeltaTime);
        ImGui::Render();

        // click-through unless the cursor is over the menu
        bool wantClickThrough = !Menu_WantsMouse(); g_menuMouse = !wantClickThrough;
        if (wantClickThrough != clickThrough) {
            clickThrough = wantClickThrough;
            LONG_PTR st = GetWindowLongPtrW(hwnd, GWL_EXSTYLE);
            st = clickThrough ? (st | WS_EX_TRANSPARENT) : (st & ~WS_EX_TRANSPARENT);
            SetWindowLongPtrW(hwnd, GWL_EXSTYLE, st);
        }

        const float clear[4] = { 0, 0, 0, 0 };
        g_ctx->OMSetRenderTargets(1, &g_rtv, nullptr);
        g_ctx->ClearRenderTargetView(g_rtv, clear);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        { float t, x0, y0, x1, y1; if (Menu_GetAnimBlur(&t, &x0, &y0, &x1, &y1)) AnimBlurMenu(t, x0, y0, x1, y1); }
#ifdef INAPP
        InappPresent(hwnd);
        DwmFlush();
#else
        g_swap->Present(1, 0);
#endif
        UpdateBackdrop(hwnd);
        UpdateWmBlur(hwnd);
        UpdatePopBlur(hwnd);
        UpdateSubBlur(hwnd);
        UpdateBarBlur(hwnd);
        if (!Menu_IsVisible()) Sleep(8);
    }

    ImGui_ImplDX11_Shutdown();
    ImGui::DestroyContext();
    CleanupRT();
    if (g_avatarSRV) g_avatarSRV->Release();
    if (g_swap) g_swap->Release(); if (g_ctx) g_ctx->Release(); if (g_dev) g_dev->Release();
    DestroyWindow(hwnd);
    if (g_backdropWnd) DestroyWindow(g_backdropWnd);
    if (g_wmBlurWnd) DestroyWindow(g_wmBlurWnd);
    if (g_wmBlurWnd2) DestroyWindow(g_wmBlurWnd2);
    if (g_popBlurWnd) DestroyWindow(g_popBlurWnd);
    if (g_subBlurWnd) DestroyWindow(g_subBlurWnd);
    if (g_barBlurWnd) DestroyWindow(g_barBlurWnd);
    UnregisterClassW(wc.lpszClassName, wc.hInstance);
    if (mhook) UnhookWindowsHookEx(mhook);
    return 0;
}
