#pragma once
#include "imgui.h"

struct MenuPlatform {
    ImTextureID   avatarTex  = 0;
    ImTextureID   soldierTex = 0;      // player preview model (Visuals > Players)
    ImTextureID   logoTex    = 0;      // sidebar logo image      // avatar texture (36x36)
    ImTextureID   blurTex    = 0;      // blurred copy of the backbuffer (full screen UV space)
    ImDrawCallback blurCallback = nullptr; // copies + blurs backbuffer into blurTex
};

void Menu_LoadFonts();                  // call after ImGui::CreateContext
void Menu_SetPlatform(const MenuPlatform& p);
void Menu_RequireLoader();               // exe start: nothing is shown until HOME / END
void Menu_StartLoader(bool debug);      // HOME: 14 s load, no debug UI; END: 3 s load with Debug + ESP Preview
bool Menu_LoaderActive();
void Menu_SkipLoader();                 // ALT: instant load (also starts it if it is still waiting for HOME / END)
void Menu_ToggleTextWm();               // ` : text watermark on/off
bool Menu_GetBarBackdrop(float* x, float* y, float* w, float* h, float* r);   // blur behind the bottom bar
void Menu_Toggle();                     // NUM1
bool Menu_IsVisible();                  // open or animating
bool Menu_WantsMouse();
bool Menu_GetBackdrop(float* x, float* y, float* w, float* h, float* rounding); // screen rect to blur behind                 // cursor over menu / popups / dragging
float Menu_GetBackdropAlpha();          // 0..1, follows the open/close animation
bool  Menu_GetAnimBlur(float* t, float* x0, float* y0, float* x1, float* y1); // open/close blur of the menu itself (t: 0..1)
bool  Menu_WantsUnload();               // Unload pressed in the profile popup (exit after the close animation)
bool  Menu_UnloadReady();               // close animation + watermark fade finished
bool  Menu_GetWmBackdrop(float* x, float* y, float* w, float* h);   // watermark rect for the background blur
bool  Menu_GetPopupBackdrop(float* x, float* y, float* w, float* h, float* r); // open popup rect for background blur
bool  Menu_GetPopup2Backdrop(float* x, float* y, float* w, float* h, float* r); // its parent popup (when a list / colour picker is open over it)
void Menu_SetGameKeys(bool lmb, bool rmb, bool w, bool a, bool s, bool d, bool space);   // for the crosshair watermark
void Menu_Frame(float dt);              // call between ImGui::NewFrame and ImGui::Render
// for preview/testing
void Menu_DebugOpenLimiters();
void Menu_SetDpiScale(float s);
void Menu_SetPos(float x, float y);
void Menu_SetHostBlur(bool on);        // false: no blur of the game behind (Android) -> denser panels
void Menu_SetAutoScale(float s);       // profile > Menu Scale "Auto" value chosen by the host
void Menu_DebugSetTab(int tab, int group);
void Menu_Debug3DSync(bool on);        // render the 3D preview synchronously (offline preview)
void Menu_DebugModel(int mat, float yaw, bool skeleton);
